﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    static class Inventory
    {
        #region Fields
        private static SortedDictionary<string, GameText> inventoryList;
        private static Dictionary<int,InventoryItem> inventoryContents; // item's UniqueID used for key
        private static float weight = 0;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GraphicsDevice graphicsDevice;
        private static GameText currentText;
        private static Color selectedFontColor = Color.GreenYellow;
        private static Color normalFontColor = Color.White;
        private static Color instructionFontColor = Color.Gold;
        private static Color headerFontColor = Color.MintCream;
        private static int selectedIndex;
        private static List<InventoryItem> dropList = new List<InventoryItem>();
        private static List<InventoryItem> nothingToDrop = new List<InventoryItem>();
        private static int viewableListItems;
        private static Dictionary<GameConstants.itemClasses, Texture2D> inventorySprites;
        private static bool usingInputWindow = false;
        private static string response;
        private static int elapsedTime = 0;
        private static int currentDelay = 0;
        private static bool firstLoop = true;
        private static Keys lastKey = Keys.None;
        private static bool resetInputWindow = false;


        #endregion



        #region Properties

        internal static float Weight
        {
            get { return weight; }
        }

        internal static Dictionary<GameConstants.itemClasses, Texture2D> InventorySprites
        {
            get { return inventorySprites; }
        }


        #endregion



        #region Methods

        internal static void LoadContent(ContentManager contentManager)
        {
            inventorySprites = new Dictionary<GameConstants.itemClasses, Texture2D>();
            
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Chain,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "chain_armor_30x34"));
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Leather,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "leather_armor_25x26"));
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Plate,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "plate_armor_17x34"));
            inventorySprites.Add(
                GameConstants.itemClasses.Ring,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_MAGICAL + "ring_30x25"));
            inventorySprites.Add(
                GameConstants.itemClasses.Scroll,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_MAGICAL + "scroll_31x31"));

        }

        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            
            inventoryList = new SortedDictionary<string, GameText>();
            inventoryContents = new Dictionary<int, InventoryItem>();
            selectedIndex = -1;

        }

        




        internal static void Add(InventoryItem item)
        {
            if (graphicsDevice == null)
                throw new InvalidOperationException("Inventory not Initialized.");

            weight += item.InventoryWeight;
            inventoryContents.Add(item.UniqueID, item);
            inventoryList.Add(item.SortingValue, new GameText(item.InventoryTitle, graphicsDevice));
        }

        private static bool Drop(InventoryItem item)
        {
            if (inventoryContents.Remove(item.UniqueID))
            {
                inventoryList.Remove(item.SortingValue);
                weight -= item.InventoryWeight;
                dropList.Add(item);
                return true;
            }
            else return false;
        }

        private static void Drop()
        {
            if (selectedIndex < 0 || selectedIndex > inventoryList.Count-1) return;
            string searchString = inventoryList.ElementAt(selectedIndex).Key;
            InventoryItem item = GetItem(searchString);
            if(item != null) Drop(item);
        }

        private static InventoryItem GetItem(string searchString)
        {
            foreach (var item in inventoryContents)
                if (item.Value.SortingValue == searchString)
                    return item.Value;

            return null;
        }

        internal static int CalculateArmorRating()
        {
            int rating = 0;
            foreach (var kvPair in inventoryContents)
            {
                var item = kvPair.Value;
                if (item.IsEquipped &&
                    (item.Class == GameConstants.itemClasses.Armor_Chain ||
                    item.Class == GameConstants.itemClasses.Armor_Leather ||
                    item.Class == GameConstants.itemClasses.Armor_Plate))
                    // TODO: Update after armor class is created
                    rating += 0;
            }
            return rating;
        }

        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {

            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            if (selectedIndex < 0 && inventoryList.Count > 0) selectedIndex = 0;

            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN; 
            
            // Show header text with underline
            currentText = new GameText("Inventory:", new Point(0, nextTextTop), graphicsDevice);
            currentText.ForeColor = headerFontColor;
            currentText.Scale = new Vector2(1.5f, 1.25f);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(currentText.Height * currentText.Scale.Y);
            currentText.Draw(spriteBatch);

            underline.X = currentText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(currentText.Width * currentText.Scale.X);
            underline.Height = (int)(currentText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height+ GameConstants.LINE_SPACING;
           

            // Count how many items will fit in the current view, leaving room at the bottom for instructions
            viewableListItems = (int)Math.Floor((decimal)(viewPortBounds.Height - nextTextTop) / (currentText.Height + GameConstants.LINE_SPACING)) - 3;

            int startingPoint = selectedIndex >= viewableListItems ? selectedIndex - viewableListItems+1 : 0;
            for (int i= startingPoint; i < inventoryList.Count && i < startingPoint+viewableListItems; i++)
            {
                fontColor = (i == selectedIndex ? selectedFontColor : normalFontColor);
                currentText = new GameText(graphicsDevice);
                FitTextToWindow(inventoryList.ElementAt(i).Value);
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }

            // Display current screen instructions
            currentText = new GameText(
                "Up/Down - Change selection     Enter - Activate/Use     Delete - Drop" +
                "    R - Rename    Esc - Exit",
                new Point(),
                graphicsDevice);
            currentText.Width = blackCanvas.Width - (GameConstants.HEAD_FOOT_LEFT * 2);
            currentText.Y = (int)(blackCanvas.Top + blackCanvas.Height - currentText.Height - GameConstants.LINE_SPACING);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            
            currentText.ForeColor = instructionFontColor;
            currentText.Draw(spriteBatch);

            spriteBatch.End();
        }

        /// <summary>
        /// Reduces length of text to fit within window. This should only be necessary for magical
        /// names produced in excess of the limits as user name changes will be guarded against over
        /// run.
        /// </summary>
        /// <param name="textToFit"></param>
        private static void FitTextToWindow (GameText textToFit)
        {
            StringBuilder modifiedText = new StringBuilder(textToFit.Text);
            currentText.Text = modifiedText.ToString();

            // If text is too wide to fit window, append elipses and keep reducing it
            // until it fits
            if(currentText.Width > GameConstants.INV_MAX_TITLE_LENGTH)
            {
                modifiedText.Append("...");
                currentText.Text = modifiedText.ToString();

                while (currentText.Width > GameConstants.INV_MAX_TITLE_LENGTH)
                {
                    modifiedText.Remove(modifiedText.Length - 4, 1);
                    currentText.Text = modifiedText.ToString();
                }
            }
        }

        internal static bool ProcessPlayerInputs(Keys key, GameTime gameTime, out List<InventoryItem> dropped, out bool showInputWindow)
        {
            dropped = nothingToDrop; // Prevents creating a new list with every loop
            showInputWindow = usingInputWindow;
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            if (firstLoop && key != Keys.None) return false; // Forces keys to be released upon entry of first loop
            firstLoop = false;

            // If no key pressed, there should be no more delay
            if (key == Keys.None || key != lastKey) currentDelay = 0;

            if (usingInputWindow)
            {
                string reservedText = GetItem(inventoryList.ElementAt(selectedIndex).Key).ReservedTextForTitle;
                if (InputScreen.ProcessPlayerInputs(key, gameTime, resetInputWindow, reservedText, out response))
                {
                    usingInputWindow = false;
                    firstLoop = true;
                    elapsedTime = 0;
                }

                resetInputWindow = false;
                if (response != string.Empty)
                    RenameItem(true);

                return false; // The inventory window stays open
            } else if (key != Keys.None && elapsedTime > currentDelay)
            {

                elapsedTime = 0;

                // When a key is first pressed, the initial delay should be set
                if (key != lastKey) currentDelay = GameConstants.INITIAL_KEY_DELAY;

                // Once the initial delay is over, if the key is still held down, then repeating is allowed
                else currentDelay = GameConstants.HOLD_KEY_DELAY;

                switch (key)
                {
                    case Keys.Up: selectedIndex--; break;
                    case Keys.Down: selectedIndex++; break;
                    case Keys.Enter: ActivateItem(); break;
                    case Keys.Delete: Drop(); break;
                    case Keys.R: RenameItem(); break;
                    case Keys.Escape:
                        {
                            selectedIndex = -1;
                            dropped = dropList.ToList();
                            dropList.Clear();
                            return true;
                        }
                }
                if (selectedIndex < 0) selectedIndex = 0;
                if (selectedIndex > inventoryList.Count - 1) selectedIndex = inventoryList.Count - 1;
            }

            lastKey = key;
            return false; // Does not allow inventory menu to exit yet
        }

        private static void ActivateItem()
        {
            // Uses selectedIndex to pick the item from the list
            // Must not allow two sets of armor to be eqipped, or other such violations

        }

        private static void RenameItem(bool receivedResponse = false)
        {
            if (!receivedResponse)
            {
                usingInputWindow = true;
                resetInputWindow = true;
                InputScreen.Prompt = "What would you call it?";
                InputScreen.Value = string.Empty;
            }
            else
            {
                string itemKey = inventoryList.ElementAt(selectedIndex).Key;
                InventoryItem item = GetItem(itemKey);
                GameText gameText = inventoryList[itemKey];
                inventoryList.Remove(itemKey);
                item.Rename(response);
                gameText.Text = item.InventoryTitle;
                inventoryList.Add(item.SortingValue, gameText);
                usingInputWindow = false;
            }
        }


        #endregion


    }
}
