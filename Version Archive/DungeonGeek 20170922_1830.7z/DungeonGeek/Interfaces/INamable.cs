﻿namespace DungeonGeek
{
    interface INamable
    {
        void Rename(string newName);
    }
}
