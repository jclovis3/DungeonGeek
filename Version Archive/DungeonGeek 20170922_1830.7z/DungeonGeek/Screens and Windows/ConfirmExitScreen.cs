﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace DungeonGeek
{
    static class ConfirmExitScreen
    {



        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string prompt = "Are you sure you want to leave?";


        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);

            

        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {
            
            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();


            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Display prompt
            
            fontColor = normalFontColor;
            currentText = new GameText(prompt, graphicsDevice);
            currentText.X = GameConstants.LIST_LEFT;
            currentText.Y = nextTextTop;
            nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
            currentText.ForeColor = fontColor;
            currentText.Draw(spriteBatch);
            

            // Display current screen instructions
            currentText = new GameText("Y - Exit      N - Return to game", new Point(), graphicsDevice);
            currentText.Y = (blackCanvas.Top + blackCanvas.Height - currentText.Height - GameConstants.LINE_SPACING);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            currentText.ForeColor = screenInstructionFontColor;
            currentText.Draw(spriteBatch);

            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key, out bool ConfirmQuit)
        {
            ConfirmQuit = false;
            if (key == Keys.Y)
            {
                ConfirmQuit = true;
                return true; // Screen closes
            }
            else if(key == Keys.N)
            { return true; }

            return false; // Does not allow screen to exit yet
        }

    }
}
