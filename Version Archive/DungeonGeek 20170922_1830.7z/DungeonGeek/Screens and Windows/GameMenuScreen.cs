﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DungeonGeek
{
    static class GameMenuScreen
    {
        
        public enum ReturnActions { None, Load, Save, Instructions, Quit}
        
        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static Color selectedFontColor = Color.GreenYellow;
        private static string[] menuList;
        private static string headerText = "Options:";
        private static int selectedIndex = 0;
        private static int elapsedTime = 0;
        private static int currentDelay = 0;
        private static bool firstLoop = true;
        private static Keys lastKey = Keys.None;



        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            menuList = new string[]
            {"Save game", "Load game", "Keyboard commands","Hall of Records","Quit"};
        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {

            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();


            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            currentText = new GameText(headerText, new Point(0, nextTextTop), graphicsDevice);
            currentText.ForeColor = headerFontColor;
            currentText.Scale = new Vector2(1.5f, 1.25f);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(currentText.Height * currentText.Scale.Y);
            currentText.Draw(spriteBatch);

            underline.X = currentText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(currentText.Width * currentText.Scale.X);
            underline.Height = (int)(currentText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(currentText.Height * 0.25f) + GameConstants.LINE_SPACING;

            // Display list of menu options
            for (int i = 0; i < menuList.Length; i++)
            {
                fontColor = (i == selectedIndex ? selectedFontColor : normalFontColor);
                currentText = new GameText(menuList[i], graphicsDevice);
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }


            // Display current screen instructions
            currentText = new GameText("Up/Down - Change selection     Enter - Select\nEsc - Return to game", new Point(), graphicsDevice);
            currentText.Y = (blackCanvas.Top + blackCanvas.Height - currentText.Height - GameConstants.LINE_SPACING);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            currentText.ForeColor = screenInstructionFontColor;
            currentText.Draw(spriteBatch);

            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key, GameTime gameTime, out ReturnActions action)
        {
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            action = ReturnActions.None;

            if (firstLoop && key != Keys.None) return false; // Forces keys to be released upon entry of first loop
            firstLoop = false;

            // If no key pressed, there should be no more delay in this class
            if (key == Keys.None || key != lastKey) currentDelay = GameConstants.NO_DELAY;


            if (key != Keys.None && elapsedTime > currentDelay)
            {

                elapsedTime = 0;
                

                // When a key is first pressed, the initial delay should be set
                if (key != lastKey) currentDelay = GameConstants.INITIAL_KEY_DELAY;

                // Once the initial delay is over, if the key is still held down, then repeating is allowed
                else currentDelay = GameConstants.HOLD_KEY_DELAY;




                if (key == Keys.Escape)
                {
                    action = ReturnActions.None;
                    firstLoop = true;
                    return true; // Screen closes
                }

                // Up and down keys allow selection to roll from end to end
                else if (key == Keys.Down)
                {
                    if (++selectedIndex > menuList.Length - 1) selectedIndex = 0;
                }
                else if (key == Keys.Up)
                {
                    if (--selectedIndex < 0) selectedIndex = menuList.Length - 1;
                }
                else if (key == Keys.Enter)
                {
                    // {"Save game", "Load game", "Keyboard commands","Quit"};

                    switch (menuList[selectedIndex])
                    {
                        case "Save game":
                            // TODO: Implement save game option
                            break;
                        case "Load game":
                            // TODO: Implement load game option
                            break;
                        case "Keyboard commands":
                            action = ReturnActions.Instructions;
                            firstLoop = true;
                            return true;
                        case "Hall of Records":
                            // TODO: Implement hall of records option
                            break;
                        case "Quit":
                            action = ReturnActions.Quit;
                            firstLoop = true;
                            return true;
                        default:
                            break;
                    }
                }
            }
            lastKey = key;
            return false; // Does not allow screen to exit yet
        }

    }
}
