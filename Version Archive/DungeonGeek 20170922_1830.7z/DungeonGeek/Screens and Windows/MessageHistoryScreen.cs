﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace DungeonGeek
{
    static class MessageHistoryScreen
    {
        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string headerText = "Message History (New to old):";
        

        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);

        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds, List<string> messageHistory)
        {
            Color fontColor;

            // The count is reduced when the message history is shown and also when a new map is generated
            // to keep the list size under control.
            if (messageHistory.Count>GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH)
                messageHistory.RemoveRange(0, messageHistory.Count - GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH);

            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            
            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            currentText = new GameText(headerText, new Point(0, nextTextTop), graphicsDevice);
            currentText.ForeColor = headerFontColor;
            currentText.Scale = new Vector2(1.5f, 1.25f);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(currentText.Height * currentText.Scale.Y);
            currentText.Draw(spriteBatch);

            underline.X = currentText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(currentText.Width * currentText.Scale.X);
            underline.Height = (int)(currentText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(currentText.Height * 0.25f) + GameConstants.LINE_SPACING;


            for (int i = messageHistory.Count - 1; i >= 0; i--)
            {
                fontColor = normalFontColor;
                currentText = new GameText(messageHistory[i], graphicsDevice);
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }





            // Display current screen instructions
            currentText = new GameText("Esc - Exit", new Point(), graphicsDevice);
            currentText.Y = (int)(blackCanvas.Top + blackCanvas.Height - currentText.Height - GameConstants.LINE_SPACING);
            currentText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            currentText.ForeColor = screenInstructionFontColor;
            currentText.Draw(spriteBatch);


            spriteBatch.End();

        }

        internal static bool ProcessPlayerInputs(Keys key)
        {
            if (key == Keys.Escape)
            {
                return true;
            }

            return false; // Does not allow history screen to close yet
        }




    }
}
