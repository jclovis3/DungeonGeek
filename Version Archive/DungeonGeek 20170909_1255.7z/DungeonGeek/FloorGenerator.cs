﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace DungeonGeek
{
    /// <summary>
    /// Generates new levels randomly. Rooms are created with random number of rooms, and sizes.
    /// Loot is scattered randomly within them. Tunnels are drawn to ensure every room is connected
    /// to ensure a path always exists to the stairs. Monsters are also generated and placed randomly.
    /// </summary>
    static class FloorGenerator
    {
        /* PLANNING: Alternative map algorithm to be implemented when time permits:
         * This algorithm was tried once and found to be a bit problematic. For starters, each room
         * would have only one path to any other connected room. Somehow there spawned clusters of
         * rooms in their own connected networks that you couldn't get to from any other room outside
         * that network. Due to the single path problem, this algorithm has been abandoned.
         * Description was as follows:
           Pick center most room first (of disconnected rooms). Detect closest neighbor (center point
           to center point). Run first tunnel to this neighbor. Move both rooms to connected list.
           With each room in connected list, calculate distance to every disconnected room. With the
           room having the lowest distance, run a tunnel from it to the closer disconnected room. Move
           the new room to the connected list, and repeat until all rooms are connected. The benifit
           of this algorithm is that tunnels will not try to run across the map and work their way
           around other disconnected rooms to reach the target. This should prevent any chance of
           tunnel congestion. Should still look for tunnel intersection though.
        */

        /* Current map algoritm:
           Pick a disconnected room, tunnel to another random disconnected room. Move both to connected
           list. Pick a new disconnected room to be source, and a connected room to be target (both random)
           Tunnel from source to target, accepting any existing tunnel link or connected room found along
           the way. First iteration from disconnected to disconnected is only to provide general direction
           As of version 0.2, the discovery of any room along the way will complete the first tunnel.
           The bigest problem with this method is having to make a path around other disconnected rooms
           to connect from a connected room on one side of the map to a disconnected room on the other.
        */


        #region Fields

        static private Random rand = new Random();
        static private int levelNumber;
        static private int minRoomCount; // variable because it depends on size of floor
        static private int maxRoomCount; 
        static private int numberOfRooms;
        static private int floorWidth;
        static private int floorHeight;
        static private FloorTile.Surfaces[,] floorPlan;
        static private List<Rectangle> rooms = new List<Rectangle>();

        /* 
         * loot scatter works as follows:
         * Scans through all lit and dark floor tiles and sets chance to drop loot for each
         * tile at DROP_LOOT_CHANCE. If roll passes, then list of lootOptionTypes is iterated through
         * testing a new roll with the individual lootProbablity value. If one passes, it is selected
         * as the loot to drop. If none passes, the iteration cycle repeats until one does.
         */
        static private List<InventoryItem> scatteredLoot;
        static private Dictionary<Type, float> lootProbability = new Dictionary<Type, float>();
        static private InventoryItem newLootItem = null;


        //static private List<Type> monsterOptionTypes = new List<Type>();

        // heroLocation is where the hero will be located on the new floor. Negative
        // values show that this hasn't been set yet
        static private Point heroLocation = new Point(-1,-1);


        #endregion



        /*   * Floor generation rules:
             
             * Low levels have all lit rooms and no hidden doors
             * As you increase in level, chance of dark room and hidden door increases
             * All rooms must be connected to starting room, even if hidden door is required to access
             * Small percentage of rooms will have lots of treasures, and lots of monsters (not roaming)
             * One room must have a stairs going down. After level 30, odds of finding stairs going up
             *    increase from zero to a percentage equal to 0.05 * the level number (so Level 50
             *    will have a 2.5% chance of having a stair going up) and shall bring the hero
             *    up 5 levels (decrementing the level number). This is so they have an option to fight
             *    easier monsters again. The floor plan will be new as will the loot be repopulated.
             * After level 80, the Golden Grail may be found with 20% chance and increasing 10% every
             *    level. If floor has the Golden Grail, it will be set next to stairs going up which
             *    bring the hero all the way out of the dungeon.
             */


        /// <summary>
        /// Creates the floor structure and contents, wiping any existing floor data
        /// </summary>
        /// <exception cref="StackOverflowException">Thrown when unable to map tunnels</exception>
        static internal void CreateNewFloor(int level, int width, int height, out Point heroStartLocation, out FloorTile.Surfaces[,] newFloorPlan, out List<InventoryItem> newScatteredLoot)
        {

            // Set private fields
            levelNumber = level;
            floorWidth = width;
            floorHeight = height;

            // Define the number of rooms based on size of level (and DEBUG setting)
            minRoomCount = GameConstants.DEBUG_OPTION_SET_ROOM_COUNT > 0
                ? GameConstants.DEBUG_OPTION_SET_ROOM_COUNT
                : 1 + (int)Math.Ceiling((decimal)width*height/800);

            maxRoomCount = GameConstants.DEBUG_OPTION_SET_ROOM_COUNT >0
                ? GameConstants.DEBUG_OPTION_SET_ROOM_COUNT
                :(int)Math.Floor((decimal)width * height / 400);

            numberOfRooms = rand.Next(minRoomCount, maxRoomCount + 1);

            if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                Debug.WriteLine(string.Format("Begin creating floor {0} x {1} with {2} rooms",floorWidth,floorHeight, numberOfRooms));

            // Clear floor, loot and monster lists
            rooms.Clear();
            floorPlan = new FloorTile.Surfaces[width, height];
            scatteredLoot = new List<InventoryItem>();
            if (lootProbability.Count == 0) PopulateLootProbabilities();
            // PLANNING: Loot probabilities may be determined by floor level, in which case it should
            // be called with every new level.

            // First create the boarder tiles so tunnels do not route through them.
            for(int x=0; x<width; x++)
            {
                floorPlan[x, 0] = FloorTile.Surfaces.Border;
                floorPlan[x, height-1] = FloorTile.Surfaces.Border;
            }

            for(int y=1; y<height-1; y++)
            {
                floorPlan[0, y] = FloorTile.Surfaces.Border;
                floorPlan[width-1, y] = FloorTile.Surfaces.Border;
            }

            
            // Attempts to create the number of rooms determined above. If unable to find space
            // for all of them, accepts what it could and moves on.
            do
            {
                for (int i = 0; i < numberOfRooms; i++)
                {
                    if (!CreateRoom())
                    {
                        // Taking too long to find space for a room, reduce number
                        // of rooms to present quantity
                        numberOfRooms = i;
                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                            Debug.WriteLine(string.Format("Unable to create room. Number of rooms now {0}", numberOfRooms));
                        break;
                    }
                }
            }
            // If for some reason it fails to find space for 2 rooms, maybe if it tries again
            // it will pick smaller rooms the next time.
            while (numberOfRooms < 2); 

            PlaceHero();
            PlaceStairsDown();

            int tunnelAttempts = 0;
            while (!CreateTunnels()) // Sometimes the tunnel algorithm gets lockd up and needs a fresh start.
            {
                ClearAllTunnelsAndDoors();
                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                    Debug.WriteLine(string.Format("Tunnels failed. Clearing all tunnels and trying again. (Attempt {0})",tunnelAttempts));
                if (tunnelAttempts++ > 100)
                {
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                        Debug.WriteLine("Too many attempts to create tunnels. Canceling floor creation and throwing StackOverflowExcepton.");

                    throw new StackOverflowException("All attempts to create tunnels have failed");
                }
                
            }

            ChangeUpDoors(); // Sets hidden and locked doors on level


            // Scans through each floor space in rooms only and randomly drops loot
            // which may be weapons, armor, magical items, gold, chests, or anything else
            // that can be picked up.
            foreach (var room in rooms)
            {
                for (int x = room.Left; x < room.Right; x++)
                    for (int y = room.Top; y < room.Bottom; y++)
                        RandomlyDropLoot(x, y);
            }

            // TODO: Place monsters


            // fill OUT parameter values
            newFloorPlan = floorPlan;
            heroStartLocation = heroLocation;
            newScatteredLoot = scatteredLoot;

            if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                Debug.WriteLine("Finished creating new floor");

        }




        #region Room Generation

        /// <summary>
        /// Adds a new room to the list and requests floor and wall tiles get set
        /// </summary>
        /// <returns></returns>
        static private bool CreateRoom()
        {
            int roomWidth = rand.Next(GameConstants.MIN_ROOM_FLOOR_DIMENSION, GameConstants.MAX_ROOM_FLOOR_DIMENSION + 1);
            int roomHeight = rand.Next(GameConstants.MIN_ROOM_FLOOR_DIMENSION, GameConstants.MAX_ROOM_FLOOR_DIMENSION + 1);

            Rectangle newRoom = FindRandomEmptySpace(roomWidth, roomHeight);
            if (newRoom.Width == 0) return false;
            rooms.Add(newRoom);
            PaintRoom(newRoom);
            return true;
        }


        /// <summary>
        /// Seeks void space on map for the size of the room, its surounding walls, and the
        /// required margin of space between rooms.
        /// </summary>
        /// <param name="width">Width of open floor space in room</param>
        /// <param name="height">Height of open floor space in room</param>
        /// <returns></returns>
        static private Rectangle FindRandomEmptySpace(int width, int height)
        { 
            bool foundSpace = false;
            int x=0; int y=0;
            Rectangle testSpace = new Rectangle();
            int iCounter = 0; // Ensures method can give up searching
            while (!foundSpace && iCounter++ < 2000)
            {
                foundSpace = true;

                // Pick coordinate on the floorPlan for new room (without its walls)
                x = rand.Next(1 + GameConstants.MIN_MARGIN_BETWEEN_ROOMS, floorWidth - 1 - width - GameConstants.MIN_MARGIN_BETWEEN_ROOMS);
                y = rand.Next(1 + GameConstants.MIN_MARGIN_BETWEEN_ROOMS, floorHeight - 1 - height - GameConstants.MIN_MARGIN_BETWEEN_ROOMS);
                
                // Create test space to include floor space (width x height) + 2 for walls
                // (each dimension) + 2 for neighboring walls + margin on each side
                testSpace.X = x - 2 - GameConstants.MIN_MARGIN_BETWEEN_ROOMS;
                testSpace.Y = y - 2 - GameConstants.MIN_MARGIN_BETWEEN_ROOMS;
                testSpace.Width = width + 4 + GameConstants.MIN_MARGIN_BETWEEN_ROOMS *2;
                testSpace.Height = height + 4 + GameConstants.MIN_MARGIN_BETWEEN_ROOMS *2;

                // Checks to see if the new random test space intersects an existing room
                foreach (var room in rooms)
                {
                    if(room.Intersects(testSpace))
                    {
                        foundSpace = false;
                        break;
                    }
                }
            } // If test space was bad, repeats loop to try again

            // After predetermined number of attempts, either returns the new space if one was found
            // or returns an empty rectangle indicating that a space could not be found.
            if (!foundSpace) return new Rectangle(0, 0, 0, 0);
            return new Rectangle(x,y,width,height);
        }

        /// <summary>
        /// Sets the tileType to indicate what type of floor (Lit or dark) the room has and the
        /// wall spaces around the room.
        /// </summary>
        /// <param name="room"></param>
        static private void PaintRoom(Rectangle room)
        {
            FloorTile.Surfaces tileType;

            // Probability of having a lit room decreases with each level after level 5
            if (levelNumber > 5 && rand.NextDouble() < ((levelNumber * 0.05) - 0.1))
                tileType = FloorTile.Surfaces.DarkRoom;
            else tileType = FloorTile.Surfaces.LitRoom;

            // paint floor with selected tile type
            // note, the bottom and right of a rectangle is exclusive of the intended dimensions
            for (int x = room.X; x < room.Right; x++)
                for (int y = room.Y; y < room.Bottom; y++)
                    floorPlan[x, y] = tileType;

            // Begin wall painting
            tileType = FloorTile.Surfaces.Wall;

            // paint top and bottom walls
            for(int x=room.X-1; x<room.Right+1;x++)
            {
                floorPlan[x, room.Top - 1] = tileType;
                floorPlan[x, room.Bottom ] = tileType;
            }

            // paint left and right walls
            for(int y=room.Y;y<room.Bottom;y++)
            {
                floorPlan[room.Left - 1, y] = tileType;
                floorPlan[room.Right, y] = tileType;
            }
        }

        #endregion




        #region Hero and Monster placement

        /// <summary>
        /// Randomly places hero in a room (assumes before loot and monster placement)
        /// </summary>
        static private void PlaceHero()
        {
            int roomNumber = rand.Next(rooms.Count);
            heroLocation.X = rand.Next(rooms[roomNumber].Left, rooms[roomNumber].Right);
            heroLocation.Y = rand.Next(rooms[roomNumber].Top, rooms[roomNumber].Bottom);
        }

        #endregion




        #region Loot Placement

        /// <summary>
        /// Populates the lootProbability table for each type of loot.
        /// </summary>
        static internal void PopulateLootProbabilities()
        {
            // See note above declarations to see how probability works
            lootProbability.Add(typeof(MagicalRing), 0.05f);

        }


        /// <summary>
        /// Selects and drops loot based on probability. Location is determined before entering
        /// method and usually involves scanning through all spaces on the floor, but this method
        /// may also be used to garantee something drops and picks randomly what it is. For example,
        /// when killing a monster, it may have its own chance to drop loot.
        /// </summary>
        /// <param name="x">X coordinate of Location to drop</param>
        /// <param name="y">Y coordinate of Location to drop</param>
        /// <param name="forceDrop">Ignors chance of dropping loot and forces it to drop</param>
        static private void RandomlyDropLoot(int x, int y, bool forceDrop = false)
        {

            // Determine if loot should drop
            if (forceDrop || rand.NextDouble()< GameConstants.DROP_LOOT_CHANCE)
            {
                Type lootTypePicked = null;

                // Determine what to drop
                while (lootTypePicked == null)
                    foreach (var lootOption in lootProbability)
                    {
                            if (rand.NextDouble() < lootOption.Value)
                            {
                                lootTypePicked = lootOption.Key;
                                break;
                            }
                    }

                // TODO: Add more loot types to be created after their classes are written
                // Create loot objects
                if (lootTypePicked == typeof(MagicalRing)) newLootItem = new MagicalRing(new Point(x,y));
                // ...

                if (newLootItem != null) scatteredLoot.Add(newLootItem);

            }
        }

        #endregion





        #region Tunnel and door generation

        /// <summary>
        /// Resets all tunnel spaces to void, and all door spaces to walls. May be used if an attempt
        /// to map tunnels gets locked up and needs to start over.
        /// </summary>
        static private void ClearAllTunnelsAndDoors()
        {
            for (int x = 0; x < floorWidth; x++)
                for (int y = 0; y < floorHeight; y++)
                {
                    if (floorPlan[x, y] == FloorTile.Surfaces.Tunnel) floorPlan[x, y] = FloorTile.Surfaces.Void;
                    if (floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor ||
                        floorPlan[x, y] == FloorTile.Surfaces.LockedDoor ||
                        floorPlan[x, y] == FloorTile.Surfaces.OpenDoor) floorPlan[x, y] = FloorTile.Surfaces.Wall;
                }
        }

        /// <summary>
        /// Maps the tunnels required to connect each room to a single network of connected rooms
        /// </summary>
        /// <returns></returns>
        static private bool CreateTunnels()
        {
            if(GameConstants.DEBUG_OPTION_LOGGING_LEVEL >0)
                Debug.WriteLine("Begin CreateTunnels with {0} rooms", rooms.Count);

            List<Rectangle> connectedRooms = new List<Rectangle>(); 
            List<Rectangle> disconnectedRooms = new List<Rectangle>(rooms);

            if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
            {
                Debug.WriteLine("Rooms added to disconnectedRooms:");
                foreach (var room in disconnectedRooms)
                    Debug.WriteLine(room.ToString());
            }

            Rectangle sourceRoom;
            Rectangle targetRoom;
            int indexPick; // For picking a source or target room
            GameConstants.Direction4 direction; // Used to determine direction of tunnel or side of room to start on
            

            List<Point> currentTunnel = new List<Point>(); // used so we don't run into own tunnel
            Point currentPosition;
            bool currentTunnelCollapsed = false;
            int tunnelAttemptCounter = 0;
            // Loop requires selection of a disconnected room as source, in addition, the selection of a
            // connected room if available or else selection of disconnected room as target.
            // The target only gives a general direction to dig towards. If a connected room or tunnel
            // is found, the tunnel is complete. For the first loop, any disconnected room found along
            // the way will also be accepted.
            while (disconnectedRooms.Count > 0 || currentTunnelCollapsed) 
            {
                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine(string.Format("Top of while disconnectedRooms.Count>0 with tunnelAttemptCounter={0}", tunnelAttemptCounter));

                if (++tunnelAttemptCounter > 100)
                {
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                        Debug.WriteLine("tunnelAttemptCounter exceeded 100, exitting while loop");
                    return false;
                }
                currentTunnel.Clear();

                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine("currentTunnel cleared");

                currentTunnelCollapsed = false;

                // Select source from disconnected rooms
                indexPick = rand.Next(disconnectedRooms.Count);
                sourceRoom = disconnectedRooms[indexPick];

                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine("Source selected: {0}", sourceRoom.ToString());

                // Select target from connected list if available, else disconnected
                if (connectedRooms.Count == 0)
                {
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine("No connected rooms present, selecting target from disconnected.");
                    do
                    {
                        indexPick = rand.Next(disconnectedRooms.Count);
                        targetRoom = disconnectedRooms[indexPick];
                    } while (targetRoom == sourceRoom);
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine(string.Format("Selected room {0}", targetRoom.ToString()));
                }
                else
                {
                    indexPick = rand.Next(connectedRooms.Count);
                    targetRoom = connectedRooms[indexPick];
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine(string.Format("Selected connected room {0}", targetRoom.ToString()));
                }

                // Pick the best wall to dig tunnel from to get from source to target
                GameConstants.Direction4 wallSide = AffinityDirection(sourceRoom.Center, targetRoom.Center);


                // Place door on chosen side of wall, then move outside the door
                Point startingDoor = SetStartingDoor(sourceRoom, wallSide); // place door on wall

                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine(string.Format("Placed starting door at {0}", startingDoor.ToString()));

                currentPosition = MovePosition(startingDoor, wallSide); // move in direction as set by wallSide

                // Due to protected margin space, we know this spot is not blocked, so mark it
                floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;

                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine(string.Format("Marked {0} as a tunnel", currentPosition.ToString()));

                // Dig tunnel - Set starting values
                var tunnelComplete = false;
                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                    Debug.WriteLine("Set tunnelComplete to False");

                FloorTile.Surfaces currentSurface;
                var foundRoom = new Rectangle();

                // Repeats process until the tunnel is finished
                while (!tunnelComplete)
                {
                    currentTunnel.Add(currentPosition);
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine(string.Format("Added {0} to currentTunnel", currentPosition.ToString()));
                    int loopCounter = 0; // Catches difficulty in finding a path and starts over
                    bool directionBlocked=false;
                    do {
                        // Uses affinity and random to pick a direction to dig towards
                        direction = PickDirection(currentPosition, targetRoom.Center);

                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                            Debug.WriteLine(string.Format("Set direction to {0}", direction));

                        // If unable to find a valid direction to move to, the tunnel is a failure
                        if (++loopCounter > (floorWidth + floorHeight) * 4)
                        {
                            currentTunnelCollapsed = true;
                            if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                                Debug.WriteLine(string.Format("Tunnel Collapsed after {0} tries", loopCounter));
                            break;
                        }
                        directionBlocked = IsBlocked(
                            currentPosition,
                            direction,
                            currentTunnel,      // blocked when running into own tunnel
                            targetRoom,         // not blocked if connected to target room
                            sourceRoom,         // blocked if wall from source room found
                            connectedRooms,     // not blocked if wall found from connected room
                            disconnectedRooms,  // blocked only if other connected rooms exist, otherwise not
                            out foundRoom);

                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                            Debug.WriteLine(string.Format("direction {0} blocked", directionBlocked ? "is" : "is not"));

                    } while (directionBlocked);

                    // If failed to dig current tunnel, reset tiles to void and restart loop
                    if (currentTunnelCollapsed)
                    {
                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                            Debug.WriteLine("Tunnel spaces reset to Void");

                        foreach (var space in currentTunnel)
                            floorPlan[space.X, space.Y] = FloorTile.Surfaces.Void;

                        floorPlan[startingDoor.X, startingDoor.Y] = FloorTile.Surfaces.Wall;

                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                            Debug.WriteLine(string.Format("starting door {0} reset to Wall", startingDoor.ToString()));

                        break;
                    }


                    // isBlocked will return a rectangle with width > 0 as foundRoom if in the process
                    // of diging towards the target we find another room instead.
                    // This room will be connected if there are any, or disconnected if there are not.

                    // Reset target to be what ever room was found

                    if (foundRoom.Width > 0)
                    {
                        if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                            Debug.WriteLine(string.Format("Moving target room from {0} to {1}", targetRoom.ToString(), foundRoom.ToString()));
                        targetRoom = foundRoom;
                    }

                    // move into the direction chosen and identify the surface for this space
                    currentPosition = MovePosition(currentPosition, direction);
                    currentSurface = floorPlan[currentPosition.X, currentPosition.Y];

                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine(string.Format("Moved onto a {0} at {1}", currentSurface, currentPosition.ToString()));

                    // Check to see if standing on a door or wall, or another connected tunnel.
                    // All doors should be open at this point. Any wall would have to be on a valid
                    // room.

                    if (currentSurface == FloorTile.Surfaces.Wall ||
                        currentSurface == FloorTile.Surfaces.Tunnel ||
                        currentSurface == FloorTile.Surfaces.OpenDoor ||
                        IsJoiningOtherTunnel(currentPosition, currentTunnel)) 
                        tunnelComplete = true;
                    else
                        // Its not blocked, and not entering into a room, make it a tunnel
                        floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;

                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine(string.Format("Tunnel {0}", tunnelComplete ? "complete" : "not complete - marking space as tunnel"));

                    // Finally, move both rooms into the connected list if they are in the
                    // disconnected list.
                    if (tunnelComplete)
                        foreach (var room in new Rectangle[] { sourceRoom, targetRoom })
                        {
                            if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                                Debug.WriteLine(string.Format("Checking room {0} to see if it was disconnected", room.ToString()));
                        
                            if (disconnectedRooms.Contains(room))
                            {
                                connectedRooms.Add(room);
                                if (!disconnectedRooms.Remove(room))
                                {
                                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                                        Debug.WriteLine("disconnectedRooms failed to remove room after copying it to connectedRooms");
                                }
                                else
                                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                                    Debug.WriteLine(string.Format("Moved room {0} from disconnected to connected list.",room.ToString()));
                            }
                        }
                } // repeat while (!tunnelComplete)

                if (currentTunnelCollapsed) continue;

                // Depending on type of tile tunnel ended on, either change it to a door or tunnel.
                if (floorPlan[currentPosition.X, currentPosition.Y] == FloorTile.Surfaces.Wall)
                {
                    floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.OpenDoor;
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine("Tunnel ended on a Wall. Changed it to an Open Door.");
                }
                else if (floorPlan[currentPosition.X, currentPosition.Y] == FloorTile.Surfaces.Void)
                {
                    floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;
                    if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 1)
                        Debug.WriteLine("Tunnel ended on a Void. Changed it to a Tunnel.");
                }

                tunnelAttemptCounter = 0; // Tunnel was completed, reset attempt counter for next tunnel.
                if (GameConstants.DEBUG_OPTION_LOGGING_LEVEL > 0)
                    Debug.WriteLine("Tunnel was completed. Reset attempt counter to 0.");
            } // repeat while (disconnectedRooms.Count > 0)

            return true;
            // end of createTunnels() method
        }


        /// <summary>
        /// Prevents running into own tunnel to ensure path makes its way towards an older
        /// tunnel, or wall/door at destination (or another connected) room. Also blocks entry
        /// onto room corners and map borders. If there are no connected rooms to start with, any room
        /// may be connected to and returned as the roomFound argument.
        /// </summary>
        /// <param name="currentPosition">Position to move from</param>
        /// <param name="direction">Direction to dig into</param>
        /// <param name="ownTunnel">path created by this dig session</param>
        /// <param name="connectedRooms">list of rooms already connected</param>
        /// <param name="disconnectedRooms">list of rooms yet to be connected</param>
        /// <param name="roomFound">Room connected to even if not the target</param>
        /// <param name="targetRoom">Room to aim for</param>
        /// <returns>true if path is blocked</returns>
        private static bool IsBlocked(Point currentPosition, GameConstants.Direction4 direction, List<Point> ownTunnel, Rectangle targetRoom, Rectangle sourceRoom, List<Rectangle> connectedRooms, List<Rectangle> disconnectedRooms, out Rectangle roomFound)
        {
            // Initialize OUT parameter values
            roomFound = new Rectangle();

            // Determine if connecting to disconnected rooms is allowed (there are no connected rooms)
            bool allowDisconnected = (connectedRooms.Count == 0);

            // Sets the location to check and gets the surface type
            var targetLocation = MovePosition(currentPosition, direction);
            var targetSurface = floorPlan[targetLocation.X, targetLocation.Y];

            // shortcuts, since all void spaces are free to tunnel and running
            // into own tunnel or border tiles is not allowed
            if (targetSurface == FloorTile.Surfaces.Void) return false;
            if (targetSurface == FloorTile.Surfaces.Border) return true;
            if (ownTunnel.Contains(targetLocation)) return true;

            
            // If surface is another door or wall
            if (targetSurface == FloorTile.Surfaces.Wall || targetSurface == FloorTile.Surfaces.HiddenDoor ||
                targetSurface == FloorTile.Surfaces.LockedDoor || targetSurface == FloorTile.Surfaces.OpenDoor)
            {
                // Get room surounded by found wall
                Rectangle joinToRoom = new Rectangle();
                foreach (var room in rooms)
                {
                    if (RoomWalls(room).Contains(targetLocation))
                    {
                        joinToRoom = room; // Inidicates that a connected room has been found
                        break;
                    }
                }

                // If found sourceRoom, it's a turnaround loop and must be blocked.
                if (joinToRoom == sourceRoom) return true;

                // If wall is a corner, return true
                if (joinToRoom.Width == 0 || IsCorner(joinToRoom, targetLocation)) return true;

                // Otherwise, if there are no connected rooms, then a disconnected room will do
                // But if there are, only connected rooms are valid.
                if (allowDisconnected || connectedRooms.Contains(joinToRoom))
                {
                    roomFound = joinToRoom;
                    return false;
                }

                // And if the room is not connected though there are connected rooms available, mark this wall segment as blocked.
                return true;
            }

            // By this point, target is not on a wall border, or own tunnel and thus is not blocked.
            return false;
        }

        private static Rectangle RoomWalls(Rectangle room)
        {
            Rectangle walls;
            walls.X = room.X - 1;
            walls.Y = room.Y - 1;
            walls.Width = room.Width + 2;
            walls.Height = room.Height + 2;
            return walls;
        }

        /// <summary>
        /// Determines if the location provided is a corner of the given room
        /// </summary>
        /// <param name="room">Room dimensions</param>
        /// <param name="location">Point to check for corner</param>
        /// <returns></returns>
        private static bool IsCorner(Rectangle room, Point location)
        {
            if (location.X == room.X - 1 && location.Y == room.Y - 1) return true;
            if (location.X == room.Right && location.Y == room.Y - 1) return true;
            if (location.X == room.X - 1 && location.Y == room.Bottom) return true;
            if (location.X == room.Right && location.Y == room.Bottom) return true;
            return false;
        }


        /// <summary>
        /// Determines if another tunnel (not the current one being dug) can be found in either of
        /// the four points vertically or horizontally of the current point.
        /// </summary>
        /// <param name="currentPosition">Center of search area</param>
        /// <param name="ownTunnel">List of points dug by current cycle</param>
        /// <returns>True if another tunnel is found, otherwise false</returns>
        private static bool IsJoiningOtherTunnel(Point currentPosition, List<Point> ownTunnel)
        {
            // Even though it has no effect, the index positions are consistent with other uses
            // of Direction in this class.
            var testPoints = new Point[4];
            testPoints[0].X = currentPosition.X;
            testPoints[0].Y = currentPosition.Y - 1; // Up
            testPoints[1].X = currentPosition.X + 1; // Right
            testPoints[1].Y = currentPosition.Y;
            testPoints[2].X = currentPosition.X;
            testPoints[2].Y = currentPosition.Y + 1; // Down
            testPoints[3].X = currentPosition.X - 1; // Left
            testPoints[3].Y = currentPosition.Y;
            foreach (var testPoint in testPoints)
                if (testPoint.X>=0 &&
                    testPoint.X < floorWidth &&
                    testPoint.Y>=0 &&
                    testPoint.Y < floorHeight &&
                    floorPlan[testPoint.X, testPoint.Y] == FloorTile.Surfaces.Tunnel)
                            if (!ownTunnel.Contains(testPoint)) return true;
                    
            return false;
        }

        /// <summary>
        /// Determines the position of a new point moving one space in a given direction from
        /// a given point.
        /// </summary>
        /// <param name="point">Starting point</param>
        /// <param name="direction">Direction to move {Up, Right, Down, Left}</param>
        /// <returns></returns>
        private static Point MovePosition(Point point, GameConstants.Direction4 direction)
        {
            var newPosition = point;
            switch (direction)
            {
                case GameConstants.Direction4.Up: newPosition.Y--; break;
                case GameConstants.Direction4.Right: newPosition.X++; break;
                case GameConstants.Direction4.Down: newPosition.Y++; break;
                case GameConstants.Direction4.Left: newPosition.X--; break;
                default: break; // If invalid direction given, no move can be determined
                                
            }
            return newPosition;
        }


        /// <summary>
        /// Determines which direction to give preference towards to get from source to target. For
        /// example, if target is up and right of source, and the vertical distance is greater than
        /// the horizontal distance, than affinity should be up. Return values are 0(Up), 1(Right),
        /// 2(Down),3(Left).
        /// </summary>
        /// <param name="sourceX">X coordinate of source node</param>
        /// <param name="sourceY">Y coordinate of source node</param>
        /// <param name="targetX">X coordinate of target node</param>
        /// <param name="targetY">Y coordinate of target node</param>
        /// <returns>integer direction 0 to 4 as described above</returns>
        static private GameConstants.Direction4 AffinityDirection(Point source, Point target)
        {
            var distanceInDirection = new int[4];

            // Calculate distance toward target in each direction
            distanceInDirection[(int)GameConstants.Direction4.Up] = source.Y - target.Y;
            distanceInDirection[(int)GameConstants.Direction4.Left] = source.X - target.X;
            distanceInDirection[(int)GameConstants.Direction4.Down] = -distanceInDirection[(int)GameConstants.Direction4.Up];
            distanceInDirection[(int)GameConstants.Direction4.Right] = -distanceInDirection[(int)GameConstants.Direction4.Left];

            // Determine the greatest distance and return the direction
            return (GameConstants.Direction4)Array.IndexOf(distanceInDirection, distanceInDirection.Max());
            // JC: Convert all directional references to an Enum for clarity
        }

        /// <summary>
        /// Determines which of four directions should have great affinity and sets
        /// probability of selecting each direction, then returns the selected direction.
        /// As tunnel progresses towards target, affinity direction may change with each
        /// new source point. This ensures the general direction of the tunnel leads toward
        /// the target.
        /// </summary>
        /// <param name="source">Point to travel from</param>
        /// <param name="target">Point to travel to</param>
        /// <returns></returns>
        static private GameConstants.Direction4 PickDirection(Point source, Point target)
        {
            var directionProbability = new GameConstants.Range[4];

            // Set direction classifications
            var affinityDir = AffinityDirection(source, target);
            var altCounterClockwise = (affinityDir == GameConstants.Direction4.Up ? GameConstants.Direction4.Left : affinityDir - 1);
            var altClockwise = (affinityDir == GameConstants.Direction4.Left ? GameConstants.Direction4.Up : affinityDir + 1);
            var antiAffinityDir = (affinityDir > GameConstants.Direction4.Right ? affinityDir - 2 : affinityDir + 2);

            // Set probabilities
            directionProbability[(int)affinityDir].Low = 0;
            directionProbability[(int)affinityDir].High = 79;
            directionProbability[(int)altCounterClockwise].Low = 80;
            directionProbability[(int)altCounterClockwise].High = 89;
            directionProbability[(int)altClockwise].Low = 90;
            directionProbability[(int)altClockwise].High = 99;
            directionProbability[(int)antiAffinityDir].Low = -1; // No chance
            directionProbability[(int)antiAffinityDir].High = -100;

            var rnd = rand.Next(100);

            // Check each direction to see which the rnd value falls in between
            var direction = GameConstants.Direction4.Up;
            while (!(directionProbability[(int)direction].Low <= rnd && directionProbability[(int)direction].High >= rnd)) direction++;

            return direction;
        }

        /// <summary>
        /// Determines where to set the starting door for a tunnel and places it.
        /// </summary>
        /// <param name="room">Boundaries of room</param>
        /// <param name="wallSide">Which wall to place door</param>
        /// <returns></returns>
        static private Point SetStartingDoor(Rectangle room, GameConstants.Direction4 wallSide)
        {
            var doorLocation = new Point();

            // Determine which wall to place door
            if ((int)wallSide % 2 == 0) // Top and Bottom walls
            {
                doorLocation.X = rand.Next(room.Left, room.Right); // 
                doorLocation.Y = wallSide == GameConstants.Direction4.Up ? room.Top - 1 : room.Bottom;
            }
            else // Left and Right walls
            {
                doorLocation.Y = rand.Next(room.Top, room.Bottom);
                doorLocation.X = wallSide == GameConstants.Direction4.Left ? room.Left - 1 : room.Right;
            }

            // Place door
            floorPlan[doorLocation.X, doorLocation.Y] = FloorTile.Surfaces.OpenDoor;
            return doorLocation;
        }


        /// <summary>
        /// Iterates through all open doors to randomly change them to locked or hidden doors.
        /// Ensures that levels 1-5 will have none of these door types added by this method.
        /// </summary>
        static private void ChangeUpDoors()
        {
            GameConstants.Range hiddenProbability;
            GameConstants.Range lockedProbability;
            var doorList = new List<Point>();
            int rnd;

            // Range for hidden doors starts at 50, and locked doors starts at 75. The scope
            // of this range determines how likely the door will be hidden or locked.
            // If random number chosen does not fall within either range, then the door will
            // remain unlocked.
            hiddenProbability.Low = 50;
            lockedProbability.Low = 75;

            // As level increases, the odds should increase, up to a point.
            // Levels 1 - 5 have no chance of hidden or locked doors
            var probabilityRange = (levelNumber < 31 ? levelNumber - 6 : 24);
            hiddenProbability.High = hiddenProbability.Low + probabilityRange;
            lockedProbability.High = lockedProbability.Low + probabilityRange;


            // Iterate through each room to find doors and test each one
            foreach (var room in rooms)
            {
                for(int x=room.Left-1; x < room.Right+2; x++)
                {
                    if (floorPlan[x, room.Top-1] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(x, room.Top-1));
                    if (floorPlan[x, room.Bottom+1] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(x, room.Bottom+1));
                }

                for(int y=room.Height-1; y<room.Bottom+2; y++)
                {
                    if (floorPlan[room.Left-1, y] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(room.Left-1, y));
                    if (floorPlan[room.Right+1, y] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(room.Right+1, y));
                }
            }

            
            foreach (var door in doorList)
            {
                // Pick random number and determine which range its in to set door tile
                rnd = rand.Next(100);
                if (rnd >= hiddenProbability.Low && rnd <= hiddenProbability.High)
                    floorPlan[door.X,door.Y] = FloorTile.Surfaces.HiddenDoor;
                if (rnd >= lockedProbability.Low && rnd <= lockedProbability.High)
                    floorPlan[door.X, door.Y] = FloorTile.Surfaces.LockedDoor;
            }
        }

        /// <summary>
        /// Locations a space to drop the stairs going down.
        /// </summary>
        static private void PlaceStairsDown()
        {
            int x; int y;
            do
            {
                int roomNumber = rand.Next(rooms.Count);
                x = rand.Next(rooms[roomNumber].Left, rooms[roomNumber].Right);
                y = rand.Next(rooms[roomNumber].Top, rooms[roomNumber].Bottom);
            } while (heroLocation.X == x && heroLocation.Y == y);

            floorPlan[x, y] = FloorTile.Surfaces.StairsDown;
        }

        
        #endregion





        #region Internally accessible methods

        /// <summary>
        /// Used to return a rectangle representing the map coordinates of any room
        /// containing the specified point.
        /// </summary>
        /// <param name="containingPoint">A Point within the room to be returned</param>
        /// <param name="foundRoom">The room containing the given point</param>
        /// <returns>True if room is found, otherwise false</returns>
        static internal bool GetRoomWithPoint(Point containingPoint, out Rectangle foundRoom)
        {
            foreach (var room in rooms)
                if (room.Contains(containingPoint))
                {
                    foundRoom = room;
                    return true;
                }

            foundRoom = new Rectangle();
            return false; 
        }

        static internal int GetNumberOfRooms()
        {
            return rooms.Count;
        }


        /// <summary>
        /// Moves the draw rectangle x,y position in concurance with changed tile dimensions (map zooming)
        /// </summary>
        /// <param name="currentDrawRectangle">Rectangle to edit</param>
        /// <param name="currentSprite">graphic associated with the rectangle</param>
        /// <param name="tileWidth">scaled tile width</param>
        /// <param name="tileHeight">scaled tile height</param>
        static internal Rectangle TranslateRecToTile(Rectangle tileSize, Rectangle currentView, Point mapPos)
        {
            Rectangle currentDrawRectangle = tileSize; // sets width and height
            currentDrawRectangle.X = (mapPos.X - currentView.X) * tileSize.Width;
            currentDrawRectangle.Y = (mapPos.Y - currentView.Y) * tileSize.Height;
            return currentDrawRectangle;
        }
        #endregion
    }
}
