﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;


namespace DungeonGeek
{
    class Food : InventoryItem
    {
        private int baseCallories = 800;

        
        #region Properties

        internal override string EquipedLocation
        {
            // Food cannot be equipped
            get
            {
                return string.Empty;
            }
        }

        internal override string ReservedTextForTitle
        {
            // Used for renaming text length. Not possible with stackables.
            get
            {
                return string.Empty;
            }
        }
        #endregion


        #region Constructor
        internal Food(Point mapLocation)
        {
            InventoryTitle = "Food";
            IsStackable = true;
            InventoryWeight = 0.5f;
            Location = mapLocation;
            itemClass = GameConstants.itemClasses.Food;

        }

        #endregion


        #region Methods
        internal override string Activate(List<InventoryItem> replacesItems)
        {
            int deviationEffect = rand.Next(3);
            int cal = baseCallories;
            string result=string.Empty;
            if(deviationEffect==0)
            {
                result = "That wasn't very filling";
                cal /= 2;
            } else if(deviationEffect == 1)
            {
                result = "That hit the spot";
            } else
            {
                result = "Such a large portion, you feel like you couldn't eat another bite.";
                cal *= 2;
            }
            InventoryEffectManager.Hero.Eat(cal);
            return result;
        }

        internal override string Remove()
        {
            // Remove is for items the hero might be wearing. This shouldn't get called on food.
            return string.Empty;
        }

        internal override void Rename(string newName)
        {
            // Food is a stackable item and should not be renamed
            return;
        }
        #endregion
    }
}
