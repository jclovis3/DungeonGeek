﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System;
using System.Text;
using System.Collections.Generic;

namespace DungeonGeek
{
    /// <summary>
    /// Abstract class for any item the hero may find lying around that he can add to
    /// his/her inventory. Class includes methods for drawing the item, generating a
    /// random magical name, and all the shared properties of inventory items that allow
    /// them to be added to and worked with within a List.
    /// </summary>
    internal abstract class InventoryItem
    {
        #region Fields
        // protected fields are accessible from current and subclasses only
        protected Random rand;
        protected GameConstants.itemClasses itemClass;
        protected bool discoveredEffect;
        protected bool inView;
        private string inventoryTitle;
        private float inventoryWeight;
        private Point location;
        private bool isEquipped;
        private bool isStackable=false;
        private int uniqueID;
        private static int nextID = 0;

        // graphic and drawing info
        protected string spriteFile;
        protected Texture2D sprite;
        //protected Rectangle drawRectangle = new Rectangle();
        



        #endregion



        #region Properties
        // internal properties are available anywhere within the same name space
        // Must have private variable to reference for property set/get methods


        internal string InventoryTitle // name given to item in inventory
        {
            get { return inventoryTitle; }
            set { inventoryTitle = value; }
        }

        internal int UniqueID
        {
            get { return uniqueID; }
        }
        internal abstract string ReservedTextForTitle { get; }


        internal float InventoryWeight // weight as it counts towards carry limit
        {
            get { return inventoryWeight; }
            set { inventoryWeight = value; }
        }
        
        internal Point Location // where object can be found on current map if not in inventory
        {
            get { return location; }
            set { location = value; }
        }
        
        internal bool IsEquipped
        {
            get { return isEquipped; }
            set { isEquipped = value; }
        }

        internal bool IsStackable
        {
            get { return isStackable; }
            set { isStackable = value; }
        }

        internal GameConstants.itemClasses Class
        {
            get { return itemClass; }
        }
        
        internal string SortingValue
        {
            get { return Class.ToString() + ":" + InventoryTitle + ":" + UniqueID; }
        }

        internal string DiscoveryText
        {
            get {return "You found " + inventoryTitle;}
        }

        internal abstract string EquipedLocation { get; }

        #endregion



        #region Constructor
        protected InventoryItem()
        {
            rand = InventoryEffectManager.RandomNumberGenerator;
            inView = false;
            uniqueID = nextID++;
        }
        #endregion



        #region Methods

        /// <summary>
        /// Creates a magical name using random words from the word list.
        /// </summary>
        /// <returns></returns>
        protected void GenerateMagicalName()
        {
            string[] wordList = {"bik","lok","nuk","sac","do","voo","kel","nif",
                          "abice","croda","nebel","monji","nelba","baxtice","barlow",
                          "borna","owata","coflack","zeltona","yalto","lupidus","goat"};

            
            int numberOfWords = rand.Next(4, 8);
            StringBuilder magicalName = new StringBuilder();

            for (int wordNum = 0; wordNum < numberOfWords; wordNum++)
            {
                magicalName.Append(wordList[rand.Next(wordList.Length)]);
                if (wordNum < numberOfWords - 1) magicalName.Append(" ");
            }
            InventoryTitle = magicalName.ToString();
            return;
        }


        /// <summary>
        /// Updates draw rectangle for sprite based on currentView of level floor plan
        /// so that as the view pans to the right keeping centered on hero if possible, the
        /// drawRectangle moves to the left by the given number of pixels as determined by
        /// tileWidth. Same concept for vertical and tileHeight.
        /// </summary>
        /// <param name="currentView">Tiles in floor map within viewable area</param>
        /// <param name="tileWidth">pixel width of tile</param>
        /// <param name="tileHeight">pixel height of tile</param>
        internal void Update(Rectangle currentView,int tileWidth, int tileHeight)
        {
            // Location is the tile coordinate, not a pixel location. To convert to pixel
            // relative to currentView, need to use tileWidth & tileHeight as pixel dimensions
            // location.X * tileWidth determines adjusted pixel location in drawing area
            // (tileWidth - sprite.Width) / 2 provides amount of margin to add to left edge
            // currentView.X * tileWidth is the offset for when the currentView moves

            inView = currentView.Contains(Location);
        }

        internal void Draw(SpriteBatch spriteBatch, Rectangle currentDrawRectangle)
        {
            if (inView)
            {
                sprite = Inventory.InventorySprites[itemClass];
                spriteBatch.Draw(sprite, currentDrawRectangle, Color.White); // White is full color with no tinting
            }
                
        }

        /// <summary>
        /// Allows player to change the inscription or rename an item
        /// </summary>
        /// <param name="newName"></param>
        internal abstract void Rename(string newName);

        /// <summary>
        /// Causes the hero to use, wear, weild, etc. the item. If this requires removal of a like item,
        /// it is removed automatically if it is not cursed. When the new item is activated, its effect is
        /// discovered if it wasn't and the result of activiating the item is returned for the message queue.
        /// </summary>
        /// <param name="replacesItem">Item of the same class that is currently active</param>
        /// <returns>Result of using the item.</returns>
        internal abstract string Activate(List<InventoryItem> replacesItems);

        internal abstract string Remove();
        

        #endregion

    }
}
