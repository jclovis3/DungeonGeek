﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    interface IWearable
    {
        bool IsOn { get;  set; }
        string WornOn { get; }


        string PutOn(List<InventoryItem> replacesItems);

        string TakeOff();


    }
}
