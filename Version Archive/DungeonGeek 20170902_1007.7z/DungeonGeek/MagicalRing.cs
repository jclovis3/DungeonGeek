﻿using Microsoft.Xna.Framework;
using System;


namespace DungeonGeek
{
    /// <summary>
    /// Magical Rings, as opposed to Ordinary Rings, have magical enchantments.
    /// Named this way in case of added structure for ordinary ring later that you can
    /// enchant with a scroll. May add a disenchant scroll to disenchant the ring.
    /// </summary>
    internal class MagicalRing : InventoryItem
    {
        #region Constants and Enums
        enum effectTypes {IncreaseStrength,IncreaseHitPoints,EnhanceArmour,ExtendSight};

        #endregion

        #region Fields

        private effectTypes magicalEffect;
        private int effectPower;     // Cursed items get negative values by default,
                                     // but a negative value does not imply isCurssed


        #endregion

        #region Properties
        private bool isCursed;
        internal bool IsCursed
        {
            get { return isCursed; }
            set { isCursed = value; }
        }

        #endregion

        /// <summary>
        /// Creates instance of a Magical Ring treasure. It is necessary to share the same
        /// Random object as other instances created at the same time to ensure unique values
        /// are returned.
        /// </summary>
        /// <param name="mapLocation">Where on the map the item is located (x,y)</param>
        /// <param name="rand">Random number generator</param>
        internal MagicalRing(Point mapLocation)
        {
            GenerateMagicalName();
            InventoryTitle = "a ring inscribed \"" + InventoryTitle+"\"";
            // TODO: Make sure that when the magical effect is discovered, the title changes
            discoveredEffect = false;
            InventoryWeight = 0.01f;
            Location = mapLocation;
            spriteFile = spritePath+"ring_30x25";
            itemClass = itemClasses.Ring;
            SetEffectType();
            SetEffectPower();
        }

        private void SetEffectType()
        {
            int effectRoll = rand.Next(100);
            if (effectRoll < 30) magicalEffect = effectTypes.EnhanceArmour; // 30%
            else if (effectRoll < 40) magicalEffect = effectTypes.ExtendSight; // 10%
            else if (effectRoll < 70) magicalEffect = effectTypes.IncreaseHitPoints; // 30%
            else magicalEffect = effectTypes.IncreaseStrength; // 30%
            return;
        }

        private void SetEffectPower()
        {
            // TODO: Consider increasing effectPower based on player level to encourage trying on new rings
            int effectRoll = rand.Next(100);
            if (effectRoll < 10) { IsCursed = true; effectPower = -2; }
            else if (effectRoll < 25) { IsCursed = true; effectPower = -1; }
            else if (effectRoll < 50) { IsCursed = false; effectPower = 1; }
            else if (effectRoll < 80) { IsCursed = false; effectPower = 2; }
            else { IsCursed = false; effectPower = 3; }
        }

       
    }
}
