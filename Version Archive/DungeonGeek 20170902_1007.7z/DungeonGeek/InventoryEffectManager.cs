﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    /// <summary>
    /// Handles calculation of hero stat modifications and other affects related to equiped inventory
    /// and temporary effects from scrolls, potions, monster attacks, traps, etc.
    /// </summary>
    static class InventoryEffectManager
    {

        #region Constants and Enums

        public enum TemporaryEffects {
            Hastened,           // Moves twice for each monster move
            Slowed,             // Moves only every other turn while monsters continue to move
            Blind,              // Does not light up rooms or reveal floor tiles
            Confused,           // All moves are in random directions (and run is eratic)
            Overburdened,       // Slowed, but not relieved by time (set to -1 when used)
            Poisoned,           // Causes damage each turn instead of healing (same rate)
            ImprovedNightSight, // Visible area in dark rooms and tunnels exended by 2 tiles in all directions
            SensesMonster,      // Monsters on the map within 100 tile range are revealed each turn
            Stuck,              // Can't move due to trap, relieved by time
            Fainted,            // Fell asleep due to lack of food or other reasons
            Observant           // 5x chance to notice hidden (multiplied when searching)
        }

        // TODO: After adding monsters, implement SensesMonster.
        // TODO: After adding food, implement energy consumption, fainting and starvation effect

        private const double CHANCE_OF_FAINT = 0.10;
        private const int FAINT_TIME_MIN = 3; // Small because it will occur frequently when feelsFaint.
        private const int FAINT_TIME_MAX = 5;
        private const int SHORTER_EFFECT_MIN = 10; // Stuck, Confused, Poisoned
        private const int SHORTER_EFFECT_MAX = 20;
        private const int LONGER_EFFECT_MIN = 50;  // Hastened, Slowed, Blind, ImprovedNightSight, Observant
        private const int LONGER_EFFECT_MAX = 200;
        #endregion



        #region fields
        private static List<string> outputMessageQueue = new List<string>();
        private static Random rand = new Random();

        // Hero state
        private static bool feelsFaint = false; // Hero can loose consciousness for a time
        
        // time each effect lasts (-1 is indefinate until something else changes)
        private static Dictionary<TemporaryEffects, int> heroCurrentEffects;

        // Statements used when status of effect changes (loaded in constructor)
        private static Dictionary<TemporaryEffects, string> affectedStatement;
        private static Dictionary<TemporaryEffects, string> unaffectedStatement;



        #endregion



        #region Properties

        internal static Random RandomNumberGenerator
        {
            get { return rand; }
        }    // Read only
        internal static List<string> ImportMessageQueue
        { // Passes the message queue up and clears it locally
            get
            {
                List<string> sendQueue = new List<string>(outputMessageQueue);
                outputMessageQueue.Clear();
                return sendQueue;
            }
        } // Read with clear only
        internal static bool FeelsFaint
        { // Used when hero is low on calories and needs food
            get { return feelsFaint; }
            set { feelsFaint = value; }
        }                 // Read/Write
        internal static bool HeroHastened
        {
            get { return heroCurrentEffects[TemporaryEffects.Hastened] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Hastened] > -1)
                    heroCurrentEffects[TemporaryEffects.Hastened] += rand.Next(LONGER_EFFECT_MIN, LONGER_EFFECT_MAX + 1);
            }
        }               // Read/Write
        internal static bool HeroSlowed
        {
            get { return heroCurrentEffects[TemporaryEffects.Slowed] > 0 || HeroOverburdened; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Slowed] > -1)
                    heroCurrentEffects[TemporaryEffects.Slowed] += rand.Next(LONGER_EFFECT_MIN, LONGER_EFFECT_MAX + 1);
            }
        }                 // Read/Write
        internal static bool HeroBlind
        {
            get { return heroCurrentEffects[TemporaryEffects.Blind] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Blind] > -1)
                    heroCurrentEffects[TemporaryEffects.Blind] += rand.Next(LONGER_EFFECT_MIN, LONGER_EFFECT_MAX + 1);
            }
        }                  // Read/Write
        internal static bool HeroConfused
        {
            get { return heroCurrentEffects[TemporaryEffects.Confused] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Confused] > -1)
                    heroCurrentEffects[TemporaryEffects.Confused] += rand.Next(SHORTER_EFFECT_MIN, SHORTER_EFFECT_MAX + 1);
            }
        }               // Read/Write
        internal static bool HeroOverburdened
        {
            get { return heroCurrentEffects[TemporaryEffects.Overburdened] > 0; }
            set { if (value) heroCurrentEffects[TemporaryEffects.Overburdened] = -1; }
        }           // Read/Write
        internal static bool HeroPoisoned
        {
            get { return heroCurrentEffects[TemporaryEffects.Poisoned] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Poisoned] > -1)
                    heroCurrentEffects[TemporaryEffects.Poisoned] += rand.Next(SHORTER_EFFECT_MIN, SHORTER_EFFECT_MAX + 1);
            }
        }               // Read/Write
        internal static bool HeroSeeksInDark
        {
            get { return heroCurrentEffects[TemporaryEffects.ImprovedNightSight] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.ImprovedNightSight] > -1)
                    heroCurrentEffects[TemporaryEffects.ImprovedNightSight] += rand.Next(LONGER_EFFECT_MIN, LONGER_EFFECT_MAX + 1);
            }
        }            // Read/Write
        internal static bool HeroDetectsMonsters
        {
            get { return heroCurrentEffects[TemporaryEffects.SensesMonster] > 0; }
        }        // Read/Write
        internal static bool HeroStuck
        {
            get { return heroCurrentEffects[TemporaryEffects.Stuck] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Stuck] > -1)
                    heroCurrentEffects[TemporaryEffects.Stuck] += rand.Next(SHORTER_EFFECT_MIN, SHORTER_EFFECT_MAX + 1);
            }
        }                  // Read/Write
        internal static bool HeroConcious
        { // Used to determine if the world takes moves without the player
            get { return heroCurrentEffects[TemporaryEffects.Fainted] == 0; }
        }               // Read only
        internal static bool HeroObservant
        {
            get { return heroCurrentEffects[TemporaryEffects.Observant] > 0; }
            set
            {
                if (value && heroCurrentEffects[TemporaryEffects.Observant] > -1)
                    heroCurrentEffects[TemporaryEffects.Observant] += rand.Next(LONGER_EFFECT_MIN, LONGER_EFFECT_MAX + 1);
            }
        }              // Read/Write

        #endregion



        #region Constructor
        static InventoryEffectManager()
        {
            // Load effects dictionaries
            heroCurrentEffects = new Dictionary<TemporaryEffects, int>();
            affectedStatement = new Dictionary<TemporaryEffects, string>();
            unaffectedStatement = new Dictionary<TemporaryEffects, string>();
            foreach (var effect in Enum.GetValues(typeof(TemporaryEffects)).Cast<TemporaryEffects>())
            {
                // Effect timers
                heroCurrentEffects.Add(effect, 0);

                
                #region Effect status change messages
                switch (effect)
                {
                    case TemporaryEffects.Hastened:
                        {
                            affectedStatement.Add(effect, "You feel quick on your feet.");
                            unaffectedStatement.Add(effect, "Your feet don't feel so quick anymore.");
                            break;
                        }

                    case TemporaryEffects.Slowed:
                        {
                            affectedStatement.Add(effect, "Why is everything moving so fast.");
                            unaffectedStatement.Add(effect, "The world slows down again.");
                            break;
                        }

                    case TemporaryEffects.Blind:
                        {
                            affectedStatement.Add(effect, "You have gone blind.");
                            unaffectedStatement.Add(effect, "\"I see,\" said the blind man.");
                            break;
                        }

                    case TemporaryEffects.Confused:
                        {
                            affectedStatement.Add(effect, "You can't seem to tell your left from your right anymore.");
                            unaffectedStatement.Add(effect, "You feel less confused now.");
                            break;
                        }

                    case TemporaryEffects.Overburdened:
                        {
                            affectedStatement.Add(effect, "You are slowed by your weight. Don't be a hoarder.");
                            unaffectedStatement.Add(effect, "Your knees are thanking you again.");
                            break;
                        }

                    case TemporaryEffects.Poisoned:
                        {
                            affectedStatement.Add(effect, "The poison will sap at your health if you don't find a cure.");
                            unaffectedStatement.Add(effect, "You can heal naturally again.");
                            break;
                        }

                    case TemporaryEffects.ImprovedNightSight:
                        {
                            affectedStatement.Add(effect, "The world seems a brighter place for a moment.");
                            unaffectedStatement.Add(effect, "Your night blindness has returned.");
                            break;
                        }

                    case TemporaryEffects.SensesMonster:
                        {
                            affectedStatement.Add(effect, "You can smell monsters from a greater distance.");
                            unaffectedStatement.Add(effect, "Your sense of smell is normal again.");
                            break;
                        }

                    case TemporaryEffects.Stuck:
                        {
                            affectedStatement.Add(effect, "You are stuck.");
                            unaffectedStatement.Add(effect, "You can move again.");
                            break;
                        }

                    case TemporaryEffects.Fainted:
                        {
                            affectedStatement.Add(effect, "You have fainted.");
                            unaffectedStatement.Add(effect, "You have awaken.");
                            break;
                        }

                    case TemporaryEffects.Observant:
                        {
                            affectedStatement.Add(effect, "Eyes like an eagle, you notice anything out of place.");
                            unaffectedStatement.Add(effect, "The walls all seem the same again.");
                            break;
                        }
                }
                #endregion
            }
        }
        #endregion



        #region Internal Methods

        internal static void AdvanceTurn()
        {
            // Decrement positive counters affected by time checking for 0 along the way


            // Use foreach loop instead
            if (heroCurrentEffects[TemporaryEffects.Hastened] > 0 &&
                --heroCurrentEffects[TemporaryEffects.Hastened] == 0)
                SetEffect(TemporaryEffects.Hastened,false);
            


            CheckHeroFaints();
        }



        #endregion



        #region Private Methods

        private static void CheckHeroFaints()
        {
            if (heroCurrentEffects[TemporaryEffects.Fainted] == 0 &&
                feelsFaint && rand.NextDouble() < CHANCE_OF_FAINT)
            {
                outputMessageQueue.Add("You have fainted.");
                heroCurrentEffects[TemporaryEffects.Fainted] =
                    rand.Next(FAINT_TIME_MIN, FAINT_TIME_MAX + 1);
                
            }
        }

        private static void HeroAwakens()
        {
            outputMessageQueue.Add("You are awake again.");
        }


        private static void SetEffect(TemporaryEffects effect, bool isAffected)
        {
            if (isAffected)
                outputMessageQueue.Add(affectedStatement[effect]);
            else
                outputMessageQueue.Add(unaffectedStatement[effect]);
        }


       


        

        #endregion
    }
}
