﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    static class Instructions
    {
        #region Constants
        const int TOP_MARGIN = 5;
        const int HEAD_FOOT_LEFT = 5;
        const int LIST_LEFT = 10;
        const float UNDERLINE_RATIO = 0.15f;
        #endregion


        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string[] gameInstructionList;
        

        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);

            // TODO: Implement any functions noted below
            gameInstructionList = new string[]
            {
                "? or / - Displays this help screen (Duh)",
                "ESC - Exit any open screen, or opens Game Menu",
                "Arrow Keys / Number Pad (Numlock Off) - General movement (may hold key down)",
                "SHIFT + movement - Run until you find something (door, monster, loot, etc.)",
                "   - Also explores tunnel until the end or first intersection",
                "   - Move toward locked door or monster to attack / bash it", // not implemented yet
                "DEL - Rest one turn (may hold key down)",      // Not implemented yet
                "INS - Search for hidden doors & traps (3x chance to find than movement or resting)",
                "A,S,W,D - Pan camera (normal and map view)",
                "M - Zoom out to show more of the map",
                "I - Opens inventory screen",
                "< or ,  - Go down stairs (must be on top of them)"
                // PLANNING: Update instruction list with added features
            };

        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {
            // TODO: Refactor Create Method. Instructions.Show() shares many common lines from Inventory.Show()

            Color fontColor;
            Viewport oldViewPort = graphicsDevice.Viewport;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            
            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + TOP_MARGIN;

            // Show header text with underline
            currentText = new GameText("Instructions:", new Point(0, nextTextTop), graphicsDevice);
            currentText.ForeColor = headerFontColor;
            currentText.Scale = new Vector2(1.5f, 1.25f);
            currentText.X = blackCanvas.Left + HEAD_FOOT_LEFT;
            nextTextTop += (int)(currentText.Height * currentText.Scale.Y);
            currentText.Draw(spriteBatch);

            underline.X = currentText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(currentText.Width * currentText.Scale.X);
            underline.Height = (int)(currentText.Height * UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(currentText.Height * 0.25f);


            
            for (int i = 0; i < gameInstructionList.Length; i++)
            {
                fontColor = normalFontColor;
                currentText = new GameText(gameInstructionList[i],graphicsDevice);
                currentText.X = LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }

            // Display current screen instructions
            currentText = new GameText("Esc - Exit", new Point(0, nextTextTop), graphicsDevice);
            currentText.Y = (int)(blackCanvas.Top + blackCanvas.Height - currentText.Height * 1.25f);
            currentText.X = blackCanvas.Left + HEAD_FOOT_LEFT;
            currentText.ForeColor = screenInstructionFontColor;
            currentText.Draw(spriteBatch);


            spriteBatch.End();
            graphicsDevice.Viewport = oldViewPort;

        }

        internal static bool ProcessPlayerInputs(Keys key)
        {
            if (key == Keys.Escape)
            {
                return true;
            }

            return false; // Does not allow inventory menu to exit yet
        }




    }
}
