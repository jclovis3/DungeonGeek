﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{

    /// <summary>
    /// Handles sprite font loading and string output in XNA/MonoGame.
    /// </summary>
    class GameText
    {

        const string FONT_FILE = @"Sprites\Fonts\Arial";
        
        #region Fields
        static private SpriteFont font;
        private string text;
        private Point location;
        private Vector2 scale;
        Color foreColor = Color.White;
        Color backColor = Color.Black;
        Texture2D pixel;

        

        #endregion

        #region Properties

        public string Text
        {
            set { text = value; }
            get { return text; }
        }

        public int X
        {
            set { location.X = value; }
            get { return location.X; }
        }

        public int Y
        {
            set { location.Y = value; }
            get { return location.Y; }
        }

        public Point Location
        {
            set { location = value; }
            get { return location; }
        }

        public int Height
        {
            get { return font.LineSpacing; }
        }

        public int Width
        {
            get { return (int)font.MeasureString(Text).Length(); }
        }

        public Color ForeColor
        {
            get { return foreColor; }
            set { foreColor = value; }
        }

        public Color BackColor
        {
            get { return backColor; }
            set { backColor = value; }
        }

        public float Spacing
        {
            get { return font.Spacing; }
            set { font.Spacing = value; }
        }

        public Vector2 Scale
        {
            get { return scale; }
            set { scale = value; }
        }

        #endregion

        #region Constructors
        public GameText (string text, Point location, GraphicsDevice graphicsDevice)
        {
            Text = text;
            Location = location;
            Color[] colorData = {Color.White};
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            scale = new Vector2(1f, 1f);
        }

        public GameText(string text, GraphicsDevice graphicsDevice) : this(text, new Point(), graphicsDevice) { }

        public GameText(GraphicsDevice graphicsDevice) : this("", new Point(), graphicsDevice) { }

        #endregion


        static public void LoadContent(ContentManager content)
        {
            font = content.Load<SpriteFont>(FONT_FILE);
        }


        /// <summary>
        /// Draws text in active view port. Used during an open SpriteBatch session.
        /// </summary>
        /// <param name="spriteBatch">SpriteBatch to render to</param>
        public void Draw(SpriteBatch spriteBatch)
        {
            // Draw background color first
            spriteBatch.Draw(pixel, new Rectangle(X, Y, Width, Height), backColor);

            // Draw text onto background
            spriteBatch.DrawString(font, Text, new Vector2(location.X,location.Y), foreColor,0,new Vector2(),scale,SpriteEffects.None,0);
            
        }
    }
}
