﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    static class Inventory
    {
        #region Constants
        const int TOP_MARGIN = 5;
        const int HEAD_FOOT_LEFT = 5;
        const int LIST_LEFT = 10;
        const float UNDERLINE_RATIO = 0.15f;
        #endregion


        #region Fields
        private static Dictionary<InventoryItem, GameText> inventoryList;
        private static float weight = 0;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GraphicsDevice graphicsDevice;
        private static GameText currentText;
        private static Color selectedFontColor = Color.GreenYellow;
        private static Color normalFontColor = Color.White;
        private static Color instructionFontColor = Color.Gold;
        private static Color headerFontColor = Color.MintCream;
        private static int selectedIndex;
        private static List<InventoryItem> dropList = new List<InventoryItem>();
        private static int viewableListItems;
        

        #endregion

        #region Properties

        internal static float Weight
        {
            get { return weight; }
        }


        #endregion



        #region Methods

        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            inventoryList = new Dictionary<InventoryItem, GameText>();
            selectedIndex = -1;

        }

        internal static void Add(InventoryItem item)
        {
            if (graphicsDevice == null)
                throw new InvalidOperationException("Inventory not Initialized.");

            weight += item.InventoryWeight;
            inventoryList.Add(item, new GameText(item.InventoryTitle, graphicsDevice));
        }

        private static bool Drop(InventoryItem item)
        {
            if (inventoryList.Remove(item))
            {
                weight -= item.InventoryWeight;
                dropList.Add(item);
                return true;
            }
            else return false;
        }

        private static void Drop()
        {
            if (selectedIndex < 0 || selectedIndex > inventoryList.Count-1) return;
            InventoryItem item = inventoryList.ElementAt(selectedIndex).Key;
            Drop(item);

        }

        internal static int ArmorRating()
        {
            int rating = 0;
            foreach (var item in inventoryList)
            {

                if (item.Key.Class == InventoryItem.itemClasses.Armor && item.Key.IsEquipped)
                    // TODO: Update after armor class is created
                    rating += 0;
            }
            return rating;
        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {

            Color fontColor;
            Viewport oldViewPort = graphicsDevice.Viewport;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            if (selectedIndex < 0 && inventoryList.Count > 0) selectedIndex = 0;
            // TODO: Add Sort to Inventory

            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + TOP_MARGIN; 
            
            // Show header text with underline
            currentText = new GameText("Inventory:", new Point(0, nextTextTop), graphicsDevice);
            currentText.ForeColor = headerFontColor;
            currentText.Scale = new Vector2(1.5f, 1.25f);
            currentText.X = blackCanvas.Left + HEAD_FOOT_LEFT;
            nextTextTop += (int)(currentText.Height * currentText.Scale.Y);
            currentText.Draw(spriteBatch);

            underline.X = currentText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(currentText.Width * currentText.Scale.X);
            underline.Height = (int)(currentText.Height * UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height+(int)(currentText.Height*0.25f);
           

            // Count how many items will fit in the current view, leaving room at the bottom for instructions
            viewableListItems = (int)Math.Floor((decimal)(viewPortBounds.Height - nextTextTop) / currentText.Height) - 3;

            int startingPoint = selectedIndex >= viewableListItems ? selectedIndex - viewableListItems+1 : 0;
            for (int i= startingPoint; i < inventoryList.Count && i < startingPoint+viewableListItems; i++)
            {
                fontColor = (i == selectedIndex ? selectedFontColor : normalFontColor);
                currentText = inventoryList.ElementAt(i).Value;
                currentText.X = LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }

            // Display current screen instructions
            currentText = new GameText("Up/Down - Change selection     Enter - Activate/Use     Delete - Drop    Esc - Exit", new Point(0, nextTextTop), graphicsDevice);
            currentText.Y = (int)(blackCanvas.Top + blackCanvas.Height - currentText.Height * 1.25f);
            currentText.X = blackCanvas.Left + HEAD_FOOT_LEFT;
            currentText.ForeColor = instructionFontColor;
            currentText.Draw(spriteBatch);


            spriteBatch.End();
            graphicsDevice.Viewport = oldViewPort;

        }

        internal static bool ProcessPlayerInputs(Keys key, out List<InventoryItem> dropped)
        {
            if (key == Keys.Escape)
            {
                selectedIndex = -1;
                dropped = dropList.ToList();
                dropList.Clear();
                return true;
            }
            if (key == Keys.Up) selectedIndex--;
            if (key == Keys.Down) selectedIndex++;
            if (selectedIndex < 0) selectedIndex = 0;
            if (selectedIndex > inventoryList.Count-1) selectedIndex = inventoryList.Count - 1;
            if (key == Keys.Enter) ActivateItem();
            if (key == Keys.Delete) Drop();

            dropped = new List<InventoryItem>();
            return false; // Does not allow inventory menu to exit yet
        }

        private static void ActivateItem()
        {
            // Uses selectedIndex to pick the item from the list
            // Must not allow two sets of armor to be eqiped, or other such violations

        }

        #endregion
    }
}
