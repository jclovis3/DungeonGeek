﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace DungeonGeek
{
    /// <summary>
    /// Runs the game loop and all major event cycles are launched from here.
    /// </summary>
    public class DungeonGameEngine : Game
    {

        // Planning Notes:
        // PLANNING: Change default icon
        // PLANNING: Track what types of magical items have been discovered
        // PLANNING: When hero is unconcious, set delay slow enough the player can see monsters move.
        // PLANNING: Implement variable zoom by mouse scroll wheel and keyboard
        // PLANNING: Make hero and stairs grow and shrink repeatedly in map view (when not moving) to make them easier to see
        // PLANNING: Allow mouse click to set target run-to point
        // PLANNING: Provide pan to stairs feature after they are found
        // PLANNING: Create data load and save features
        // PLANNING: Get player name at the beginning to record high score list
        // PLANNING: After trying a scroll or potion, force renaming it
        // PLANNING: Reassess tunnel algorithm


        #region Fields

        // Graphics and game timing
        int elapsedTime = 0;
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Viewport statsViewPort;
        Viewport mainViewPort;
        Viewport childWindowViewPort;
        Viewport inputWindowViewPort;
        Viewport defaultViewPort;
        

        // Map view and manipulation
        Rectangle localView; // Viewable area of map - moves with hero
        int tileHeight = GameConstants.TILE_SIDE_NORMAL;
        int tileWidth = GameConstants.TILE_SIDE_NORMAL;
        Dictionary<Keys, GameConstants.Direction8> panningDirectionKeys = new Dictionary<Keys, GameConstants.Direction8>();

        FloorTile.Surfaces[,] floorPlan; // Contains walkable and blockable surfaces for current floor
        bool[,] floorRevealed;
        List<InventoryItem> scatteredLoot; // Items to be discovered on floor while walking around
        List<InventoryItem> pickupList = new List<InventoryItem>();
        bool showMap = false;
        Rectangle lastWindowSize;

        // Game state data
        StringBuilder statsRow;
        int floorLevel = 1;
        private int floorWidth = GameConstants.FLOOR_WIDTH_START;
        private int floorHeight = GameConstants.FLOOR_HEIGHT_START;
        Hero hero;
        List<string> outputMessageQueue = new List<string>();
        List<string> messageHistory = new List<string>();
        string returnedMessageText;
        Random rand = new Random();
        GameText stats;
        GameText message;
        GameText moreText;
        bool evenCycle = false; // Used for hastened and slowed effect to trigger movement of hero or monsters every other cycle
        

        // Keyboard handling
        KeyboardState keyState;
        bool rapidRepeat = false; // rapid repeat of same move
        bool isKeyDown = false;
        bool isShiftDown = false;
        bool isRunning = false;
        bool waitForKeyRelease = false;
        GameConstants.Direction8 currentDirection = GameConstants.Direction8.Up;
        Dictionary<Keys, GameConstants.Direction8> movementDirectionKeys = new Dictionary<Keys, GameConstants.Direction8>();
        Keys lastNonStateKeyPressed = Keys.None;  // Stores a key other than Shift, Alt, Ctrl, CAPS_LOCK.
        int currentDelay = GameConstants.NO_DELAY;
        GameConstants.InputControlFocus screenHavingFocus = GameConstants.InputControlFocus.MainGameScreen; // used when inventory or other menus are open

        // Mouse handling
        MouseState mouse;
        MouseState oldMouse;
        int mouseCursorTime = 0;
        #endregion




        #region Constructor
        /// <summary>
        /// CONSTRUCTOR
        /// </summary>
        public DungeonGameEngine()
        {
            
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            
        }

        #endregion
        



        #region Game Class Overrides and Events

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            ShowAboutScreen();

            // Adjust window to 3/4 of screen size and allow resizing
            graphics.PreferredBackBufferWidth = (int)(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width* 0.75);
            graphics.PreferredBackBufferHeight = (int)(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height * 0.75);
            graphics.ApplyChanges();
            Inventory.Initialize(graphics.GraphicsDevice);
            RenameItemScreen.Initialize(graphics.GraphicsDevice);
            InstructionsScreen.Initialize(graphics.GraphicsDevice);
            MessageHistoryScreen.Initialize(graphics.GraphicsDevice);
            
            lastWindowSize = Window.ClientBounds;
            Window.AllowUserResizing = true;
            Window.ClientSizeChanged += Window_ClientSizeChanged;
            Window.Title = GameConstants.TITLE_BAR_TEXT;
            
            hero = new Hero();
            InventoryEffectManager.Hero = hero;
            statsRow = new StringBuilder();
            stats = new GameText(StatText(),graphics.GraphicsDevice);
            message = new GameText(graphics.GraphicsDevice);
            moreText = new GameText(" MORE ",graphics.GraphicsDevice);
            
            statsViewPort = GraphicsDevice.Viewport;
            mainViewPort = GraphicsDevice.Viewport;
            childWindowViewPort = GraphicsDevice.Viewport;
            inputWindowViewPort = GraphicsDevice.Viewport;
            defaultViewPort = GraphicsDevice.Viewport;
            oldMouse = Mouse.GetState();

            movementDirectionKeys.Add(Keys.Up, GameConstants.Direction8.Up);
            movementDirectionKeys.Add(Keys.Down, GameConstants.Direction8.Down);
            movementDirectionKeys.Add(Keys.Left, GameConstants.Direction8.Left);
            movementDirectionKeys.Add(Keys.Right, GameConstants.Direction8.Right);
            movementDirectionKeys.Add(Keys.Home, GameConstants.Direction8.UpLeft);
            movementDirectionKeys.Add(Keys.PageUp, GameConstants.Direction8.UpRight);
            movementDirectionKeys.Add(Keys.End, GameConstants.Direction8.DownLeft);
            movementDirectionKeys.Add(Keys.PageDown, GameConstants.Direction8.DownRight);

            panningDirectionKeys.Add(Keys.A, GameConstants.Direction8.Left);
            panningDirectionKeys.Add(Keys.D, GameConstants.Direction8.Right);
            panningDirectionKeys.Add(Keys.W, GameConstants.Direction8.Up);
            panningDirectionKeys.Add(Keys.S, GameConstants.Direction8.Down);
            
            base.Initialize();
        }


        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // SpriteBatch is used to draw textures to the GPU in a single stream.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            
            // Note, scattered loot items are loaded in the generateMap() method because creating a
            // new floor level destroys any loot items left on the floor and the sprites along with them.
            // This way, when a new list of scattered loot is created, the sprites for them can be loaded.

            GenerateMap();
            hero.LoadContent(Content);
            FloorTile.LoadContent(Content);
            Inventory.LoadContent(Content);
            GameText.LoadContent(Content);

            

            stats.ForeColor = Color.Yellow;
            stats.BackColor = Color.Black;
            message.Y = stats.Height;
            message.ForeColor = Color.White;
            message.BackColor = Color.Black;
            moreText.Y = stats.Height;
            moreText.ForeColor = Color.Black;
            moreText.BackColor = Color.White;
            UpdateViewPorts(); // Requires that GameText content be loaded first

            // Intro messages
            outputMessageQueue.Add("When you see the MORE prompt, press space.");
            outputMessageQueue.Add("It is shown when there are more messages in queue.");
            outputMessageQueue.Add("Use arrow keys or numeric keypad (NumLock off) to move.");
            outputMessageQueue.Add("Press ? for a complete list of commands.");
            outputMessageQueue.Add("This messages clears when you move.");


        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // REMINDER: Unload any non ContentManager content here
            base.UnloadContent();
        }

       
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if(GameConstants.DEBUG_MODE_WALK_THROUGH_WALLS || GameConstants.DEBUG_MODE_REVEAL)
                Window.Title = GameConstants.TITLE_BAR_TEXT + " Hero: " + hero.Location;

            // Ensure maximize / restore event is handled
            if (lastWindowSize != Window.ClientBounds)
                Window_ClientSizeChanged(this,EventArgs.Empty);

            ProcessMessageQueue(); // Displays next message if there is one

            // Get new keyState and Shift status as well
            lastNonStateKeyPressed = GetKeyPressed();

            
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            mouseCursorTime += gameTime.ElapsedGameTime.Milliseconds;

            if (lastNonStateKeyPressed == Keys.None)
            {
                waitForKeyRelease = false;
                currentDelay = GameConstants.NO_DELAY;
            }


            // If hero is unconcious, cancel run if active, move the monsters and update effect timing
            // Effectively skips hero's turn to move or control game events.
            if (!InventoryEffectManager.HeroConcious)
            {
                isRunning = false;
                rapidRepeat = true;
                MoveMonsters();
                InventoryEffectManager.AdvanceTurn();
                FinishTurn();
            }

            // Hero is concious. If running, control running interval with same interval as hold key
            else if (isRunning && GameConstants.HOLD_KEY_DELAY < elapsedTime)
            {
                elapsedTime = 0;
                currentDelay = GameConstants.NO_DELAY; // used when falling out of run cycle
                rapidRepeat = false;
                waitForKeyRelease = true;
                HeroRuns(); // Used here to continue the running cycle once started
            }

            // Handle message queue acknowledgements if more than one message in queue
            // Blocks any movement actions while MORE is shown.

            else if (!waitForKeyRelease && outputMessageQueue.Count > 1 && lastNonStateKeyPressed == Keys.Space)
                ProcessMessageQueue(true); // Acknowledge message

            #region Movement with or without holding key down

            // delay is 0 until key is pressed, so this should execute right
            // away when key initially pressed
            else if (!isRunning && currentDelay < elapsedTime && !waitForKeyRelease)
            {
                elapsedTime = 0;

                // Decide where current inputs should be passed along to. If no other child window open,
                // movement, search and rest inputs will trigger monsters to move and other game turn advancements
                DirectPlayerInputs(gameTime);
                rapidRepeat = true;




                // Cycle delay in response to repeat state
                // First, ensure control is local, otherwise remove delay
                // if coming in with no delay and local control, next delay should be INITIAL_KEY_DELAY
                // if delay is already at INITIAL_KEY_DELAY and holding key, advance to RAPID_DELAY
                if (lastNonStateKeyPressed != Keys.None)
                {
                    if (screenHavingFocus != GameConstants.InputControlFocus.MainGameScreen)
                        currentDelay = GameConstants.NO_DELAY; // Allows timing control to be handled by other windows.
                    else if (currentDelay == GameConstants.NO_DELAY)
                        currentDelay = GameConstants.INITIAL_KEY_DELAY;
                    else if (rapidRepeat && currentDelay == GameConstants.INITIAL_KEY_DELAY)
                        currentDelay = GameConstants.HOLD_KEY_DELAY;
                    else if (!rapidRepeat) currentDelay = GameConstants.INITIAL_KEY_DELAY;
                }
                else
                {
                    currentDelay = GameConstants.NO_DELAY;
                    rapidRepeat = false;
                }

            }


            #endregion


            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black); // Seems to affect whole screen regardless if placed after Viewport is assigned.
            
            DrawMainView();
            DrawStatsView();
            switch(screenHavingFocus)
            {
                case GameConstants.InputControlFocus.Inventory:
                    Inventory.Draw(spriteBatch, childWindowViewPort.Bounds);
                    break;
                case GameConstants.InputControlFocus.RenameItemScreen:
                    Inventory.Draw(spriteBatch, childWindowViewPort.Bounds);
                    RenameItemScreen.Draw(spriteBatch, inputWindowViewPort.Bounds);
                    break;
                case GameConstants.InputControlFocus.Instructions:
                    InstructionsScreen.Show(spriteBatch, childWindowViewPort.Bounds);
                    break;
                case GameConstants.InputControlFocus.MessageHistory:
                    MessageHistoryScreen.Show(spriteBatch, childWindowViewPort.Bounds, messageHistory);
                    break;
            }

            
            base.Draw(gameTime);
        }

        protected void DrawMainView()
        {
            GraphicsDevice.Viewport = mainViewPort;
            spriteBatch.Begin(); // requires an End

            Rectangle tileSize = new Rectangle(0, 0, tileWidth, tileHeight);

            // Draw floor tiles
            for (int x = 0; x < floorWidth; x++)
                for (int y = 0; y < floorHeight; y++)
                    if (floorRevealed[x, y] || GameConstants.DEBUG_MODE_REVEAL)
                        FloorTile.Draw(spriteBatch,
                            floorPlan[x, y],     // Tile type to draw
                            FloorGenerator.TranslateRecToTile( // Rectangle to draw in
                              tileSize,
                              localView,
                              new Point(x, y)));

            // Draw scattered loot
            foreach (var item in scatteredLoot)
            {
                if (floorRevealed[item.Location.X, item.Location.Y] || GameConstants.DEBUG_MODE_REVEAL)
                    item.Draw(spriteBatch, FloorGenerator.TranslateRecToTile(tileSize, localView, item.Location));
            }

            hero.Draw(spriteBatch,
                FloorGenerator.TranslateRecToTile(tileSize, localView, hero.Location));

            spriteBatch.End();


        }

        protected void DrawStatsView()
        {
            GraphicsDevice.Viewport = statsViewPort;
            spriteBatch.Begin();
            stats.Draw(spriteBatch);
            if (outputMessageQueue.Count > 0) message.Draw(spriteBatch);
            if (outputMessageQueue.Count > 1) moreText.Draw(spriteBatch);

            spriteBatch.End();

        }



        /// <summary>
        /// Event handler for user changing the size of the window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ClientSizeChanged(object sender, EventArgs e)
        {
            lastWindowSize = Window.ClientBounds;
            graphics.PreferredBackBufferWidth = lastWindowSize.Width;
            graphics.PreferredBackBufferHeight = lastWindowSize.Height;
            graphics.ApplyChanges();
            UpdateViewPorts();
        }


        #endregion




        #region Game Play

        /// <summary>
        /// Generates the line of text for displaying hero and game status data
        /// </summary>
        /// <returns>string of text to display</returns>
        private string StatText()
        {
            statsRow.Clear();
            statsRow.Append(string.Format("Floor: {0}", floorLevel));
            statsRow.Append(string.Format("     HP: {0}/{1}", hero.HP,hero.HP_Max));
            statsRow.Append(string.Format("     XP [{0}] {1}/{2}", hero.XPLvl, hero.XP, hero.XpToNext));
            statsRow.Append(string.Format("     Armor: {0}", Inventory.CalculateArmorRating()));
            statsRow.Append(string.Format("     Str: {0}/{1}", hero.EffectiveStrength, hero.BaseStrength));
            statsRow.Append(string.Format("     Energy: {0}/{1}", hero.Energy, hero.EnergyStorage));
            return statsRow.ToString();
        }


        /// <summary>
        /// Accepts keyboard and mouse inputs and processes game logic in response to those inputs
        /// </summary>
        private void ProcessPlayerInputs()
        {

            #region Mouse Input
            mouse = Mouse.GetState();
            if (mouse != oldMouse)
            {
                mouseCursorTime = 0;
                IsMouseVisible = true;
            }
            if (mouseCursorTime > GameConstants.MOUSE_HIDE_DELAY && mouse == oldMouse)
            {
                // Mouse has not moved for a short time, make it vanish
                IsMouseVisible = false;
            }
            oldMouse = mouse;

            #endregion


            #region Keyboard Input

            if (lastNonStateKeyPressed == Keys.None) return;

            #region Turn advancement actions

            Debug.Assert (InventoryEffectManager.HeroConcious);

            isRunning = false;
            // Get movement direction, and move if a movement key is pressed (adjusting for being slowed by effect)
            foreach (var directionAssignment in movementDirectionKeys)
            {
                if (lastNonStateKeyPressed == directionAssignment.Key)
                {
                    isRunning = isShiftDown && !GameConstants.DEBUG_MODE_WALK_THROUGH_WALLS && !InventoryEffectManager.HeroSlowed;
                    if (isRunning) rapidRepeat = false;
                    currentDirection = directionAssignment.Value;
                    if (isRunning) HeroRuns(); // Used here to start the running cycle
                    else if (!InventoryEffectManager.HeroSlowed || (InventoryEffectManager.HeroSlowed && evenCycle))
                        Move(); // Used in the HeroRuns method as well and calls FinishTurn with each move
                    else
                        FinishTurn();
                    break;
                }
            }

            // Press Delete to rest one turn - lets other monsters move and effects wear off
            if (lastNonStateKeyPressed == Keys.Delete)
            {
                // Clear last message from screen
                if (outputMessageQueue.Count > 0)
                    ProcessMessageQueue(true);
                FinishTurn();
            }

            // Press Insert to search 3 times in one turn
            else if (lastNonStateKeyPressed == Keys.Insert)
            {
                // Clear last message from screen
                if (outputMessageQueue.Count > 0 )
                {
                    ProcessMessageQueue(true);
                    waitForKeyRelease = true;
                }
                FinishTurn(3); // Passes number of searches along to tripple the chance using the same pass
            }

            #endregion

            #region Static Actions - No turn advancement
            // Defined as an action that does not cause monsters to move or game turn to increment

            // Pan camera with assigned keys
            foreach (var panDirection in panningDirectionKeys)
            {
                if (panDirection.Key == lastNonStateKeyPressed)
                    PanViewManually(panDirection.Value);
            }

            // Center view back on hero without requiring movement or toggling the map view
            if (lastNonStateKeyPressed == Keys.Tab && !rapidRepeat)
                PanViewWithHero();

            // Esc - Game menu
            else if (lastNonStateKeyPressed == Keys.Escape && !rapidRepeat)
            {
                if (!ShowGameMenu())
                    return; // Quick exit if user selects exit from menu.
            }

            // Comma - Descends stairs
            else if (lastNonStateKeyPressed == Keys.OemComma && !rapidRepeat &&
                floorPlan[hero.Location.X, hero.Location.Y] == FloorTile.Surfaces.StairsDown)
            {
                floorLevel++;
                GenerateMap();
                ToggleView(true); // Reset view back to normal
            }

            // M - Toggle Map view
            else if (lastNonStateKeyPressed == Keys.M && !rapidRepeat) ToggleView();

            // I - Show inventory
            else if (lastNonStateKeyPressed == Keys.I && !rapidRepeat && screenHavingFocus != GameConstants.InputControlFocus.Inventory)
            {
                screenHavingFocus = GameConstants.InputControlFocus.Inventory;
                ProcessMessageQueue(true); // Clears message queue from screen so it doesn't hold up rapid key firing in the rename window
            }

            // H - Show Message History
            else if (lastNonStateKeyPressed == Keys.H && !rapidRepeat && screenHavingFocus != GameConstants.InputControlFocus.MessageHistory)
            {
                screenHavingFocus = GameConstants.InputControlFocus.MessageHistory;
            }


            // ? - Show Instructions
            else if (lastNonStateKeyPressed == Keys.OemQuestion && !rapidRepeat && screenHavingFocus != GameConstants.InputControlFocus.Instructions)
            {
                screenHavingFocus = GameConstants.InputControlFocus.Instructions;
            }

            #region DEBUG FEATURES
            // DEBUG FEATURE: Instantly jump up and down floor levels with F2 and F3
            if (GameConstants.DEBUG_MODE_ALLOW_FLOOR_JUMPING && lastNonStateKeyPressed == Keys.F2)
            {
                floorLevel++;
                GenerateMap();
                ToggleView(true);
            }

            if (GameConstants.DEBUG_MODE_ALLOW_FLOOR_JUMPING && lastNonStateKeyPressed == Keys.F3)
            {
                // TODO: Remove after testing screen fonts
                for (int i = 0; i < GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH; i++)
                {
                    messageHistory.Add(string.Format("DEBUG INSERT LINE - {0}", i));
                    //Inventory.Add(new MagicalRing(string.Format("DEBUG INSERT LINE - {0}",i)));
                    Inventory.Add(new MagicalRing(hero.Location));
                } // END Remove
                        

                floorLevel--;
                GenerateMap();
                ToggleView(true);
            }

            // DEBUG FEATURE: Checks the map for hidden doors and traps
            if (GameConstants.DEBUG_MODE_REVEAL && lastNonStateKeyPressed == Keys.F1 && !rapidRepeat)
                FindHidden();
            #endregion


            #endregion Static Actions - No turn advancement
            

            

            #endregion

        }


        /// <summary>
        /// Handles decisions as to whether player inputs should affect the main
        /// game or be passed along to an open dialog such as the inventory,
        /// instructions or other such child windows.
        /// </summary>
        private void DirectPlayerInputs(GameTime gameTime)
        {
            // Stop hold key rapid fire if a message is still on screen.
            if (outputMessageQueue.Count > 0 && lastNonStateKeyPressed != Keys.None)
                waitForKeyRelease = true;
            

            #region switch(keyboardControls)
            switch (screenHavingFocus)
            {
                case GameConstants.InputControlFocus.RenameItemScreen: // Keyboard control passes through Inventory
                case GameConstants.InputControlFocus.Inventory:
                    {
                        List<InventoryItem> dropList; // to receive items dropped by Inventory
                        bool showRenameItemScreen;
                        if (Inventory.ProcessPlayerInputs(lastNonStateKeyPressed, gameTime, out dropList, out showRenameItemScreen))
                        {
                            // Restore local controls when Inventory closes
                            screenHavingFocus = GameConstants.InputControlFocus.MainGameScreen;

                            // Update stat text and item location on screen in case of loot drop or stat changes from used items
                            UpdateLocations();

                            // Pull in any messages passed from Inventory Window
                            outputMessageQueue.AddRange(InventoryEffectManager.ImportMessageQueue);
                            if (lastNonStateKeyPressed != Keys.None && outputMessageQueue.Count > 0) waitForKeyRelease = true;
                        }

                        if (dropList.Count > 0) ScatterDroppedLoot(dropList);

                        if (showRenameItemScreen)
                        {
                            currentDelay = GameConstants.NO_DELAY; // Timing is handled by the rename window
                            screenHavingFocus = GameConstants.InputControlFocus.RenameItemScreen;
                        }
                        else
                        {
                            currentDelay = GameConstants.INITIAL_KEY_DELAY;
                            if (screenHavingFocus != GameConstants.InputControlFocus.MainGameScreen)
                                screenHavingFocus = GameConstants.InputControlFocus.Inventory;
                        }
                        break;
                    }

                case GameConstants.InputControlFocus.Instructions:
                    {
                        if (InstructionsScreen.ProcessPlayerInputs(lastNonStateKeyPressed))
                        {
                            // Restore local controls when Inventory closes
                            screenHavingFocus = GameConstants.InputControlFocus.MainGameScreen;
                        }
                        break;
                    }

                case GameConstants.InputControlFocus.MessageHistory:
                    {
                        if (MessageHistoryScreen.ProcessPlayerInputs(lastNonStateKeyPressed))
                        {
                            // Restore local controls when Inventory closes
                            screenHavingFocus = GameConstants.InputControlFocus.MainGameScreen;
                        }
                        break;
                    }
                default:
                    {
                        ProcessPlayerInputs();
                        break;
                    }
            }
            #endregion switch(keyboardControls)

        }

        private Keys GetKeyPressed()
        {
            Keys rtnVal = Keys.None;
            keyState = Keyboard.GetState();
            if (keyState.GetPressedKeys().Length != 0)
                foreach(var key in keyState.GetPressedKeys())
                {
                    if(key != Keys.LeftShift && key != Keys.RightShift &&
                        key != Keys.LeftAlt && key != Keys.RightAlt &&
                        key != Keys.LeftControl && key != Keys.RightControl &&
                        key != Keys.LeftWindows && key != Keys.RightWindows &&
                        key != Keys.CapsLock)
                    {
                        rtnVal = key;
                        break; // Only allows first non-state change key to be passed
                    }
                }
            isShiftDown = (keyState.IsKeyDown(Keys.LeftShift) || keyState.IsKeyDown(Keys.RightShift));

            return rtnVal;
            // Keys.None seems to be true all the time
        }


        /// <summary>
        /// Checks the ground below the hero's feet and picks up the item if there is room.
        /// Works on stacks of items if on the same space as well. 
        /// </summary>
        private void PickUpItem()
        {
            // Created pickupList as class variable so as not to create
            // and dispose of a new object with every move. Can't alter the scatteredLoot
            // list while iterating through it so a secondary list was needed.

            pickupList.Clear();
            foreach (var item in scatteredLoot)
            {
                if (item.Location == hero.Location && hero.AttemptPickupItem(item))
                {
                    pickupList.Add(item);
                }
            }

            foreach (var item in pickupList)
            {
                scatteredLoot.Remove(item);
                waitForKeyRelease = true; // Interupts rapid fire movement
                outputMessageQueue.Add(item.DiscoveryText);
            }
        }


        /// <summary>
        /// Moves each item from the droppedLoot list to the ground around the
        /// hero if there is room and aborts if there is not. Player will be notified
        /// if there is no more room. Items successfully dropped will be transferred
        /// from the droppedLoot list to the scatteredLoot list. All failed items
        /// will be returned back to the Inventory.
        /// </summary>
        /// <param name="droppedLoot">List of Inventory Items dropped from the Inventory</param>
        private void ScatterDroppedLoot(List<InventoryItem> droppedLoot)
        {
            while (droppedLoot.Count > 0)
            {
                // Locate free space around hero to drop an item, starting with space above 
                bool foundSpace = false;
                Point dropPoint=hero.Location;
                for (GameConstants.Direction8 testDirection = GameConstants.Direction8.Up; testDirection<= GameConstants.Direction8.UpLeft; testDirection++)
                {
                    var testPoint = GetNewPointFrom(testDirection, hero.Location);
                    if (!Blocked(testPoint) && !LootFoundAt(testPoint))
                    {
                        dropPoint = testPoint;
                        foundSpace = true;
                        break;
                    }
                }
                if (foundSpace)
                {
                    //Drop the last item in the list
                    var item = droppedLoot.Last();
                    item.Location = dropPoint;
                    scatteredLoot.Add(item);
                    droppedLoot.Remove(item);
                } else
                {
                    // return all remaining items to inventory and inform player
                    outputMessageQueue.Add("No room to drop anything.");
                    foreach(var item in droppedLoot)
                    {
                        Inventory.Add(item);
                    }
                    droppedLoot.Clear();
                }
            } // end of while (droppedLoot.Count > 0)

            UpdateLocations(); // Ensures new scattered loot gets drawn

        }

        private bool LootFoundAt(Point testPoint)
        {
            foreach (var item in scatteredLoot)
                if (item.Location == testPoint) return true;
            return false;
        }


        /// <summary>
        /// Calls upon the FloorGenerator to create a map, loot and monsters, then
        /// requests those items after they are created.
        /// </summary>
        private void GenerateMap()
        {
            Point heroStartLocation=new Point();
            floorWidth = NewFloorSize();
            floorHeight = floorWidth;
            bool floorComplete = true;
            int floorTryCounter = 0;
            do
            {
                try
                {
                    FloorGenerator.CreateNewFloor(floorLevel, floorWidth, floorHeight, out heroStartLocation, out floorPlan, out scatteredLoot);
                }
                catch (StackOverflowException)
                {
                    // Unable to map tunnels given current room configuration. Try again.
                    floorComplete = false;
                }


            } while (!floorComplete && ++floorTryCounter<10);
            if (!floorComplete) throw new StackOverflowException("Unable to create new floor after 10 tries");
            // TODO: When game saving is enabled, allow player to save before closing from this exception.


            floorRevealed = new bool[floorWidth, floorHeight];
            hero.Location = heroStartLocation;

            if(messageHistory.Count> GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH)
                messageHistory.RemoveRange(0, messageHistory.Count - GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH);
        }

        private int NewFloorSize()
        {
            // Produces a range of 80 to 400 tiles, capping out at floorLevel 108
            int fSize = GameConstants.FLOOR_WIDTH_START + (floorLevel * 3) - 3;
            if (fSize > GameConstants.FLOOR_WIDTH_MAX) fSize = GameConstants.FLOOR_WIDTH_MAX;
            return fSize;

        }


        private void ProcessMessageQueue(bool ack = false)
        {


            if (ack && outputMessageQueue.Count > 0)
            {
                messageHistory.Add(outputMessageQueue[0]);
                outputMessageQueue.RemoveAt(0);
                waitForKeyRelease = outputMessageQueue.Count > 0;
            }
            else if (outputMessageQueue.Count > 0)
            {
                message.Text = outputMessageQueue[0];
                moreText.X = message.Width;
                isRunning = false;
            }
            else if (lastNonStateKeyPressed == Keys.None) waitForKeyRelease = false;
        }

        /// <summary>
        /// Displays a basic menu for events such as Loading, Saving, Quitting, and serves as
        /// a pause while hero is not concious.
        /// </summary>
        /// <returns>True if staying in game, else false</returns>
        private bool ShowGameMenu()
        {
            // For now just ends the game
            // TODO: Develop Esc game menu
            int userChoice = 0;
            switch (userChoice)
            {
                case 0: Exit(); return false;
                default: return true;
            }

        }

        private void GameOver(string reason)
        {
            // TODO: Complete GameOver method
            Exit();
            

        }

        #endregion




        #region Movement

        /// <summary>
        /// Allows drawRectangles to be updated for loot, hero or anything else after
        /// moving the localView around.
        /// </summary>
        private void UpdateLocations()
        {
            
            foreach (var item in scatteredLoot)
            {
                item.Update(localView, tileWidth, tileHeight);
            }
            hero.Update(localView, tileWidth, tileHeight);
            
            // When room is lit, whole room lights up, otherwise, just spaces around the hero.
            ShowLitSpaces();

            stats.Text = StatText();
        }

        /// <summary>
        /// Consolidates all 8 movement methods into one, passes the new location to be
        /// checked to see if it is blocked, and moves only if it is not. If move is successfull,
        /// monsters are given a chance to move and if there are output messages queued up, they
        /// get a chance to be viewed and acknowledged. Each of these actions were appended to the
        /// move method because they are also required for each step when running.
        /// </summary>
        /// <param name="direction">Direction to move</param>
        /// <returns>True is moved, false if blocked</returns>
        private bool Move()
        {

            // Clear last message from screen
            if(outputMessageQueue.Count>0) ProcessMessageQueue(true);

            // If hero is confused, choose a random direction instead
            if (InventoryEffectManager.HeroConfused)
                currentDirection = (GameConstants.Direction8)rand.Next(Enum.GetValues(typeof(GameConstants.Direction8)).Length);

            var newPoint = GetNewPointFrom(currentDirection, hero.Location);
            
            if (!Blocked(newPoint))
            {
                if(!InventoryEffectManager.HeroStuck) hero.Location = newPoint; // Move hero
                FinishTurn();
                return true;
            }
            else return Attack(newPoint);
        }


        /// <summary>
        /// Checks to see if new space is beyond the map boarders or is a non-walkable surface.
        /// </summary>
        /// <param name="newX"></param>
        /// <param name="newY"></param>
        /// <returns></returns>
        private bool Blocked(Point checkPoint)
        {
            // Map boarder check
            if ((checkPoint.X <= 0) ||
                (checkPoint.Y <= 0) ||
                (checkPoint.X >= floorWidth - 1) ||
                (checkPoint.Y >= floorHeight - 1)) return true;

            // Tile type check
            if (!GameConstants.DEBUG_MODE_WALK_THROUGH_WALLS)
                if (floorPlan[checkPoint.X, checkPoint.Y] == FloorTile.Surfaces.LockedDoor ||
                    floorPlan[checkPoint.X, checkPoint.Y] == FloorTile.Surfaces.Void ||
                    floorPlan[checkPoint.X, checkPoint.Y] == FloorTile.Surfaces.HiddenDoor ||
                    floorPlan[checkPoint.X, checkPoint.Y] == FloorTile.Surfaces.Wall) return true;

            // TODO: Monster type check

            return false;
        }


        /// <summary>
        /// Detects if hero is next to objects, doors, stairs that may stop him. Ignores spot
        /// where hero just left from.
        /// from running.
        /// </summary>
        /// <returns></returns>
        private bool NearObject(Point heroLastLocation)
        {
            for(int x=hero.Location.X-1; x<hero.Location.X+2; x++)
                for(int y=hero.Location.Y-1; y<hero.Location.Y+2; y++)
                {
                    if(!(x==heroLastLocation.X && y == heroLastLocation.Y))
                    {
                        foreach (var item in scatteredLoot)
                            if (item.Location.X == x && item.Location.Y == y) return true;
                        var tileType = floorPlan[x, y];
                        if (tileType == FloorTile.Surfaces.LockedDoor ||
                            tileType == FloorTile.Surfaces.OpenDoor ||
                            tileType == FloorTile.Surfaces.StairsDown ||
                            tileType == FloorTile.Surfaces.StairsUp) return true;
                    }
                    
                }
            return false;
        }


        /// <summary>
        /// Checks to see if near tunnel intersection. Allows up to 2 neighboring tunnel
        /// spaces near hero (excluding diagonals) to not be in an intersection.
        /// </summary>
        /// <returns></returns>
        private bool NearTunnelIntersection()
        {
            var tunnelCount = 0;

            if (TunnelContinues(GameConstants.Direction8.Up, hero.Location)) tunnelCount++;
            if (TunnelContinues(GameConstants.Direction8.Down, hero.Location)) tunnelCount++;
            if (TunnelContinues(GameConstants.Direction8.Left, hero.Location)) tunnelCount++;
            if (TunnelContinues(GameConstants.Direction8.Right, hero.Location)) tunnelCount++;
            if (tunnelCount > 2) return true;
            else return false;
            
        }


        /// <summary>
        /// Supports tunnel running by catching changes in tunnel direction as long
        /// as hero is not near an intersection.
        /// </summary>
        /// <param name="currentDirection"></param>
        /// <returns>New direction to follow tunnel with</returns>
        private void UpdateDirectionWithTunnel()
        {
            // enum Direction {Up, UpRight, Right, DownRight, Down, DownLeft, Left, UpLeft}
            var cameFrom = (int)currentDirection - 4;
            if (cameFrom < 0) cameFrom += 8;
            for (int direction = 0; direction < 8; direction+=2) // skip diagonals
                if (direction != cameFrom &&
                    TunnelContinues((GameConstants.Direction8)direction, hero.Location))
                {
                    currentDirection = (GameConstants.Direction8)direction;
                    return;
                }
        }

        /// <summary>
        /// Checks to see if the tunnel continues in the direction indicated.
        /// </summary>
        /// <param name="direction">Direction from given point</param>
        /// <param name="fromPoint">Point to look from</param>
        /// <returns>True if tunnel continues in the indicated direction, otherwise false</returns>
        private bool TunnelContinues(GameConstants.Direction8 direction, Point fromPoint)
        {
            var newPoint = GetNewPointFrom(direction, fromPoint);
            return (floorPlan[newPoint.X, newPoint.Y] == FloorTile.Surfaces.Tunnel);

        }

        private Point GetNewPointFrom(GameConstants.Direction8 direction, Point fromPoint)
        {
            var newX = fromPoint.X;
            var newY = fromPoint.Y;
            switch (direction)
            {
                case GameConstants.Direction8.UpLeft: newX--; newY--; break;
                case GameConstants.Direction8.Up: newY--; break;
                case GameConstants.Direction8.UpRight: newX++; newY--; break;
                case GameConstants.Direction8.Right: newX++; break;
                case GameConstants.Direction8.DownRight: newX++; newY++; break;
                case GameConstants.Direction8.Down: newY++; break;
                case GameConstants.Direction8.DownLeft: newX--; newY++; break;
                case GameConstants.Direction8.Left: newX--; break;
                default: break;

            }
            return new Point(newX, newY);
        }

        private bool MonsterIsClose()
        {
            // TODO: Add code to detect monsters within view to force single step keyboard input
            return false;
        }

        /// <summary>
        /// Hero runs straight when in a room until any obstical is found.
        /// Hero runs through a tunnel until a split in the tunnel or any obstical is found.
        /// This entire run happens during a single game loop
        /// </summary>
        /// <param name="direciton">Direction to start running</param>
        private void HeroRuns()
        {
            // Determine if tunnel runner
            var floorType = floorPlan[hero.Location.X, hero.Location.Y];
            bool isTunnelRunner = (floorType == FloorTile.Surfaces.Tunnel);

            bool isStopped = false;
            var heroLastLocation = hero.Location;

            // Can't handle running through tunnels on diagonals (evaluates to odd numbered int).
            if (isTunnelRunner && (int)currentDirection % 2 == 1) isStopped = true;

            if (!Move() ||
                MonsterIsClose() ||
                NearObject(heroLastLocation)) isStopped = true;

            PanViewWithHero();

            // For in tunnels
            if (isTunnelRunner && NearTunnelIntersection()) isStopped = true;
            if (!isStopped && isTunnelRunner) UpdateDirectionWithTunnel();
            
            isRunning = !isStopped;
            
        }

        /// <summary>
        /// Used after each hero move to allow all monsters to move about and attack.
        /// </summary>
        private void MoveMonsters()
        {
            //TODO: Code the method for moveMonsters()
        }



        private void FinishTurn(int searchCount=1)
        {
            int chanceMultiplier = searchCount * (InventoryEffectManager.HeroObservant ? 5 : 1);

            if (NoticeHidden(out returnedMessageText, searchCount))
                outputMessageQueue.Add("You found a " + returnedMessageText);

            PickUpItem(); // anything the hero is standing on

            if (hero.HP < hero.HP_Max && !InventoryEffectManager.HeroPoisoned)
                hero.Heal();

            if (!hero.BurnCalories()) { GameOver("You have died of starvation."); return; }

            if (InventoryEffectManager.HeroPoisoned && !hero.TakePoisonDmg())
                {GameOver("You have been poisoned to death."); return; }

            if(!InventoryEffectManager.HeroHastened || (InventoryEffectManager.HeroHastened && !evenCycle))
                MoveMonsters();
            InventoryEffectManager.AdvanceTurn();
            PanViewWithHero();
            evenCycle = !evenCycle;
            outputMessageQueue.AddRange(InventoryEffectManager.ImportMessageQueue);
            if (lastNonStateKeyPressed != Keys.None && outputMessageQueue.Count > 0) waitForKeyRelease = true;
        }


        #endregion




        #region Attack and Door Bashing

        private bool Attack(Point location)
        {
            if (floorPlan[location.X, location.Y] == FloorTile.Surfaces.LockedDoor &&
                BashDoor(location))
                {
                    rapidRepeat = false;
                    waitForKeyRelease = true;
                    return true;
                }

                


            // No monsters to attack yet
            return false; // Assumes point is neither a door or a monster and must be blocked
        }
        private bool BashDoor(Point doorLocation)
        {
            if(floorPlan[doorLocation.X,doorLocation.Y]==FloorTile.Surfaces.LockedDoor &&
                rand.NextDouble() < 0.10)
            {
                floorPlan[doorLocation.X, doorLocation.Y] = FloorTile.Surfaces.OpenDoor;
                outputMessageQueue.Add("The door busts wide open.");
                hero.Location = doorLocation;
                return true;
            }
            return false;
        }


        #endregion




        #region Visibility


        /// <summary>
        /// Sets the range of tiles on the map that can be viewed within the game window
        /// </summary>
        private void PanViewWithHero()
        {
            // margins are the number of tiles around the hero that should be in the window
            int marginX = (int)Math.Floor((decimal)(localView.Width / 2));
            int marginY = (int)Math.Floor((decimal)(localView.Height / 2));

            // Determines if hero is too close to map edges to remain centered, and centers if not
            if (hero.Location.X < marginX) localView.X = 0;
            else if (hero.Location.X > floorWidth - marginX - 1) localView.X = floorWidth - localView.Width;
            else localView.X = hero.Location.X - marginX;

            if (hero.Location.Y < marginY) localView.Y = 0;
            else if (hero.Location.Y > floorHeight - marginY - 1) localView.Y = floorHeight - localView.Height;
            else localView.Y = hero.Location.Y - marginY;
            
            UpdateLocations(); // with new localView, all loot, traps, monsters, etc. need to be updated
        }
        private void PanViewManually(GameConstants.Direction8 moveDirection)
        {
            switch (moveDirection)
            {
                case GameConstants.Direction8.Up: localView.Y--; break;
                case GameConstants.Direction8.Down: localView.Y++; break;
                case GameConstants.Direction8.Left: localView.X--; break;
                case GameConstants.Direction8.Right: localView.X++; break;
                default: return;
            }

            localView.X = MathHelper.Clamp(localView.X, 0, floorWidth - localView.Width);
            localView.Y = MathHelper.Clamp(localView.Y, 0, floorHeight - localView.Height);

            UpdateLocations(); // with new localView, all loot, traps, monsters, etc. need to be updated
        }
        private void UpdateViewPorts()
        {
            // Adjust full viewport (default)
            defaultViewPort.Width = Window.ClientBounds.Width;
            defaultViewPort.Height = Window.ClientBounds.Height;


            // Leave room for message output below stats by invoking with twice the height
            statsViewPort.Height = stats.Height * 2;

            // Change tile sizes based on new view mode
            if (showMap)
            {
                // Calculate tile size to fit entire map on screen
                tileWidth = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width / floorWidth;
                tileHeight = (GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height - statsViewPort.Height) / floorHeight;

                // Set both to smallest dimension to keep the tile square (min 8 pixels)
                if (tileWidth < tileHeight) tileHeight = tileWidth;
                else tileWidth = tileHeight;

                // Prevent tile size from being set too small
                if (tileWidth < GameConstants.TILE_SIDE_MININUM)
                {
                    tileWidth = GameConstants.TILE_SIDE_MININUM;
                    tileHeight = GameConstants.TILE_SIDE_MININUM;
                }
                
                
            }
            else
            {
                tileWidth = GameConstants.TILE_SIDE_NORMAL;
                tileHeight = GameConstants.TILE_SIDE_NORMAL;
                // PLANNING: If changing to a rectangular tile, change this (and showMap above) as
                // not to square off the tile but just ensure the length/width ratio stays the same.
            }



            // Allow statsViewPort to consume the entire width of the screen
            statsViewPort.Width = Window.ClientBounds.Width;

            // Set size of mainViewPort
            mainViewPort.Width = Window.ClientBounds.Width;
            mainViewPort.Height = Window.ClientBounds.Height - statsViewPort.Height;

            // Reduce each dimension of mainViewPort to meet mapSize if too wide/tall
            int mapSizePixelWidth = tileWidth * floorWidth;
            int mapSizePixelHeight = tileHeight * floorHeight;
            if (mainViewPort.Width > mapSizePixelWidth) mainViewPort.Width = mapSizePixelWidth;
            if (mainViewPort.Height > mapSizePixelHeight) mainViewPort.Height = mapSizePixelHeight;

            // Center main viewport
            mainViewPort.X = Window.ClientBounds.Width / 2 - mainViewPort.Width / 2;
            mainViewPort.Y = (Window.ClientBounds.Height - statsViewPort.Height) / 2 - (mainViewPort.Height / 2) + statsViewPort.Height;
            
            localView.Width = mainViewPort.Width / tileWidth;
            localView.Height = mainViewPort.Height / tileHeight;

            // Fix Sub Window Size
            childWindowViewPort.Width = MathHelper.Min(GameConstants.CHILD_WINDOW_WIDTH, Window.ClientBounds.Width);
            childWindowViewPort.Height = MathHelper.Min(GameConstants.CHILD_WINDOW_HEIGHT, Window.ClientBounds.Height);
            childWindowViewPort.X = mainViewPort.Width / 2 - childWindowViewPort.Width / 2;
            childWindowViewPort.Y = mainViewPort.Height / 2 - childWindowViewPort.Height / 2 + statsViewPort.Height;

            // Center Input Window when used
            inputWindowViewPort.Width = GameConstants.INPUT_VIEW_WIDTH;
            inputWindowViewPort.Height = GameConstants.INPUT_VIEW_HEIGHT;
            inputWindowViewPort.X = childWindowViewPort.Bounds.Center.X - inputWindowViewPort.Width / 2;
            inputWindowViewPort.Y = childWindowViewPort.Bounds.Center.Y - inputWindowViewPort.Height / 2;

            PanViewWithHero(); // attempts to keep hero in center of view
        }

        /// <summary>
        /// Toggles between normal view and map view (full level)
        /// </summary>
        /// <param name="setLocalView"></param>
        private void ToggleView(bool setLocalView = false)
        {
            showMap = !showMap && !setLocalView; // toggle view mode
            UpdateViewPorts();
        }

        /// <summary>
        /// Identifies spaces near hero that are to be revealed up upon entry into
        /// a lit room or movement in the dark.
        /// </summary>
        private void ShowLitSpaces()
        {
            int visibleDistance = 1;
            if (InventoryEffectManager.HeroBlind)
                visibleDistance = 0;
            else if (InventoryEffectManager.HeroSeeksInDark)
                visibleDistance = 3;

            Rectangle visibleSpace;

            // If hero is in a lit room, light up the room, otherwise, light up only the spaces next
            // to the hero (distance and visiblity of lit room affected by blindness and seeing in dark).
            if (floorPlan[hero.Location.X, hero.Location.Y] == FloorTile.Surfaces.LitRoom && visibleDistance>0)
            {
                if (FloorGenerator.GetRoomWithPoint(hero.Location, out visibleSpace))
                {
                    // Expand space to include walls
                    visibleSpace.X--;
                    visibleSpace.Y--;
                    visibleSpace.Width += 2;
                    visibleSpace.Height += 2;
                }
            }
            else
            {
                visibleSpace = new Rectangle(hero.Location.X - visibleDistance, hero.Location.Y - visibleDistance, visibleDistance*2+1, visibleDistance * 2 + 1);
            }

            // Cycle through floorRevealed elements to turn them on if within the new
            // visibleSpace rectangle.
            // injected conditional values to prevent sending array out of range of the map.
            for (int x = (visibleSpace.X < 0 ? 0 : visibleSpace.X);
                x < (visibleSpace.Right > floorWidth ? floorWidth : visibleSpace.Right); x++)
                for (int y = (visibleSpace.Y < 0 ? 0 : visibleSpace.Y);
                    y < (visibleSpace.Bottom > floorHeight ? floorHeight : visibleSpace.Bottom); y++)
                // If blind, can only reveal non-floor tiles (walls, stiars, tunnels, etc.
                {
                    floorRevealed[x, y] = true;
                    if (!InventoryEffectManager.HeroBlind ||
                        !(floorPlan[x, y] == FloorTile.Surfaces.DarkRoom ||
                        floorPlan[x, y] == FloorTile.Surfaces.LitRoom)
                    ) floorRevealed[x, y] = true;
                }


            if (visibleDistance > 0)
                // TODO: Draw glowing light around hero on dark floor tiles
                return; // Then remove this
        }

        /// <summary>
        /// Applies CHANCE_TO_FIND in detecting hidden doors and traps around the hero.
        /// </summary>
        /// <param name="foundText">String of what was found for output message</param>
        /// <returns>True if something was detected, otherwise false.</returns>
        private bool NoticeHidden(out string foundText, int chanceMultiplier = 1)
        {
            // Check all spaces around hero. Note, if it were under the hero's foot, it
            // would have already been discovered (traps for instance). Removed logic to avoid checking
            // that space because it would affect all the other eight spaces by adding one more
            // comparison to each.
            // TODO: Remove debug option to findHidden();
            foundText = "";
            for (int x = hero.Location.X - 1; x < hero.Location.X + 2; x++)
                for (int y = hero.Location.Y - 1; y < hero.Location.Y + 2; y++)
                    if (x > 0 && y > 0 && x < floorWidth && y < floorHeight &&
                        floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor && rand.Next(100) < GameConstants.CHANCE_TO_FIND * chanceMultiplier)
                    {
                        floorPlan[x, y] = FloorTile.Surfaces.OpenDoor;
                        foundText = "hidden door";
                        waitForKeyRelease = true;
                        return true;
                    }

            return false;
        }


        #endregion




        #region Help
        /// <summary>
        /// Shows modal dialog of about contents. Called from within DungeonGameEngine to decrease
        /// delay after closing the dialog.
        /// </summary>
        internal static void ShowAboutScreen()
        {
            StringBuilder aboutText = new StringBuilder();
            aboutText.Append("Dungeon Geek\n");
            aboutText.Append("version 0.2\n");
            aboutText.Append("\n");
            aboutText.Append("Explore a randomly generated dungeon\n");
            aboutText.Append("Concept inspired by Rogue, a game created by Jon Lane and released for DOS in 1983.");
            System.Windows.Forms.MessageBox.Show(aboutText.ToString());

            /*
             * Version History:
             * v0.1 - Basic map generation and hero movement through map. Included one loot item
             *        for picking up and adding to inventory. Map panning and zooming.
             *        Started: 8/17/2017
             *        Closed: 8/26/2017
             *        
             * v0.2 - Improved movement features. Added inventory screen with features to drop, equip
             *        unequip, consume, and rename items. Added food along with food consumption, starvation
             *        fainting and penalties for getting too fat. Updated camera pan ability to look around
             *        without moving hero and recenter back on hero afterward. Implemented a screen to show
             *        keyboard commands and one to show the message history in case you miss something.
             *        Started: 8/30/2017
             *
             * */
        }

        #endregion




        #region DEBUG TOOLS
        // These tools are created to test features as they are added.

        // Added to test discovery of hidden doors. Retained for when traps are added. The idea is
        // that the immediate window can be used to set the hero next to the door so it can walk back
        // and fourth (or use search button when implemented) to find it and see that it is revealed
        // safely and the message queue is updated.
        private int FindHidden()
        {
            List<KeyValuePair<Point, FloorTile.Surfaces>> hiddenPlaces = new List<KeyValuePair<Point, FloorTile.Surfaces>>();

            for (int x = 0; x < floorWidth; x++)
                for (int y = 0; y < floorHeight; y++)
                    if (floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor)
                        hiddenPlaces.Add(new KeyValuePair<Point, FloorTile.Surfaces>(new Point(x, y), floorPlan[x, y]));

            if (hiddenPlaces.Count == 0) outputMessageQueue.Add("No hidden objects found");
            else outputMessageQueue.Add("Found something at " + hiddenPlaces[0].Key.ToString());
            return  hiddenPlaces.Count;
        }


        #endregion
    }


}
