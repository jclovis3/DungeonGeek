﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace DungeonGeek
{
    static class Inventory
    {
        #region Fields
        private static SortedDictionary<string, GameText> inventoryList; // sorting string, text to view
        private static Dictionary<int,InventoryItem> inventoryContents; // item's UniqueID, Item
        private static Dictionary<string, string> inputInstructions; // key pressed, what it does
        private static float weight = 0;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GraphicsDevice graphicsDevice;

        // These are an attempt to prevent creating new objects with every draw cycle
        private static GameText currentText;
        private static GameText headerText;
        private static GameText instructionsText;
        private static InventoryItem currentItem;
        private static List<GameText> listTextObjects;
        private static StringBuilder modifiedText = new StringBuilder();
        private static StringBuilder instructions = new StringBuilder();

        private static Color selectedFontColor = Color.GreenYellow;
        private static Color normalFontColor = Color.White;
        private static Color instructionFontColor = Color.Gold;
        private static Color headerFontColor = Color.MintCream;
        private static int selectedIndex;
        private static List<InventoryItem> dropList = new List<InventoryItem>();
        private static List<InventoryItem> nothingToDrop = new List<InventoryItem>();
        private static int viewableListItems;
        private static Dictionary<GameConstants.itemClasses, Texture2D> inventorySprites;
        private static bool usingRenameItemScreen = false;
        private static bool readyToLeave = false;
        private static string response;
        private static int elapsedTime = 0;
        private static int currentDelay = 0;
        private static bool firstLoop = true;
        private static Keys lastKey = Keys.None;
        private static bool resetInputWindow = false;
        private static string searchString;


        #endregion



        #region Properties

        internal static float Weight
        {
            get { return weight; }
        }

        internal static Dictionary<GameConstants.itemClasses, Texture2D> InventorySprites
        {
            get { return inventorySprites; }
        }


        #endregion



        #region Methods

        /// <summary>
        /// Loads each InventoryItem sprite into a list for reuse in the Draw method.
        /// </summary>
        /// <param name="contentManager">Content Manager passed from the Game class</param>
        internal static void LoadContent(ContentManager contentManager)
        {
            inventorySprites = new Dictionary<GameConstants.itemClasses, Texture2D>();
            
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Chain,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "chain_armor_30x34"));
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Leather,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "leather_armor_25x26"));
            inventorySprites.Add(
                GameConstants.itemClasses.Armor_Plate,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_ARMOR + "plate_armor_17x34"));
            inventorySprites.Add(
                GameConstants.itemClasses.MagicalRing,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_MAGICAL + "ring_30x25"));
            inventorySprites.Add(
                GameConstants.itemClasses.Scroll,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_MAGICAL + "scroll_31x31"));
            inventorySprites.Add(
                GameConstants.itemClasses.Food,
                contentManager.Load<Texture2D>(GameConstants.SPRITE_PATH_MISC + "Food_35x20"));
        }

        /// <summary>
        /// Creates objects for reuse within the Draw or Input loops which the game engine calls
        /// at an estimate rated of 60 fps. These objects should not be created new with each loop.
        /// Also sets instructions for window use regardless of inventory quantity.
        /// </summary>
        /// <param name="gd"></param>
        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            
            inventoryList = new SortedDictionary<string, GameText>();
            inventoryContents = new Dictionary<int, InventoryItem>();
            selectedIndex = -1;
            headerText = new GameText(graphicsDevice);
            instructionsText = new GameText(graphicsDevice);
            listTextObjects = new List<GameText>();
            listTextObjects.Add(new GameText(graphicsDevice));
            listTextObjects[0].Text = "XXXXX"; // Allows for font size measurements to be taken

            inputInstructions = new Dictionary<string, string>();
            inputInstructions.Add("Up/Down", "Change selection");
            inputInstructions.Add("Esc", "Exit");
            inputInstructions.Add("Del", string.Empty);
            inputInstructions.Add("Enter", string.Empty);
            inputInstructions.Add("R", string.Empty);


        }

        /// <summary>
        /// Draws the Inventory screen and any text to be displayed on it using a black canvas inside
        /// a boarder which runs around the edges of the frame.
        /// </summary>
        /// <param name="spriteBatch">SpriteBatch object doing the drawing from a Game class</param>
        /// <param name="viewPortBounds">Area which contains the fram and all text.</param>
        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {

            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();
            if (firstLoop) UpdateCurrentItem();

            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            headerText.Text = "Inventory:";
            headerText.ForeColor = headerFontColor;
            headerText.Scale = new Vector2(1.5f, 1.25f);
            headerText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            headerText.Y = nextTextTop;
            nextTextTop += (int)(headerText.Height * headerText.Scale.Y);
            headerText.Draw(spriteBatch);

            underline.X = headerText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(headerText.Width * headerText.Scale.X);
            underline.Height = (int)(headerText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + GameConstants.LINE_SPACING;


            // Count how many items will fit in the current view, leaving room at the bottom for instructions
            viewableListItems = (int)Math.Floor((decimal)(viewPortBounds.Height - nextTextTop) / (listTextObjects[0].Height + GameConstants.LINE_SPACING)) - 3;

            int startingPoint = selectedIndex >= viewableListItems ? selectedIndex - viewableListItems + 1 : 0;
            for (int i = startingPoint; i < inventoryList.Count && i < startingPoint + viewableListItems; i++)
            {
                fontColor = (i == selectedIndex ? selectedFontColor : normalFontColor);
                if (listTextObjects.Count < i + 1) listTextObjects.Add(new GameText(graphicsDevice));
                currentText = listTextObjects[i];
                FitTextToWindow(inventoryList.ElementAt(i).Value);
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }


            // Rebuild Instruction line
            instructions.Clear();
            for (int i = 0; i < inputInstructions.Count; i++)
                if (inputInstructions.ElementAt(i).Value != string.Empty)
                {
                    if (instructions.Length > 0)
                        instructions.Append("   ");
                    instructions.Append(inputInstructions.ElementAt(i).Key + " - " + inputInstructions.ElementAt(i).Value);
                }
            instructionsText.Text = instructions.ToString();

            // Display current screen instructions
            instructionsText.Width = blackCanvas.Width - (GameConstants.HEAD_FOOT_LEFT * 2);
            instructionsText.Y = blackCanvas.Top + blackCanvas.Height - instructionsText.Height - GameConstants.LINE_SPACING;
            instructionsText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            instructionsText.ForeColor = instructionFontColor;
            instructionsText.Draw(spriteBatch);

            spriteBatch.End();
        }

        /// <summary>
        /// Uses the searchValue to locate an InventoryItem from within the
        /// inventoryContents Dictionary
        /// </summary>
        /// <param name="searchValue">Key used in the Dictionary</param>
        /// <returns>The item if found, otherwise null</returns>
        private static InventoryItem GetItem(string searchValue)
        {
            foreach (var item in inventoryContents)
                if (item.Value.SortingValue == searchValue)
                    return item.Value;

            return null;
        }

        /// <summary>
        /// Used by the status text to show the effective armor rating after adding it up for
        /// all equipped items in the inventory. Applies effect modifiers as well.
        /// </summary>
        /// <returns></returns>
        internal static int CalculateArmorRating()
        {
            int rating = 0;
            foreach (var kvPair in inventoryContents)
            {
                var item = kvPair.Value;
                if (item is IWearable && (item as IWearable).Equipped &&
                    (item.Class == GameConstants.itemClasses.Armor_Chain ||
                    item.Class == GameConstants.itemClasses.Armor_Leather ||
                    item.Class == GameConstants.itemClasses.Armor_Plate))
                    // TODO: Update after armor class is created
                    rating += 0;
            }
            return rating; // TODO: Add any effect modifiers when they exist.
        }

        /// <summary>
        /// Reduces length of text to fit within window. This should only be necessary for magical
        /// names produced in excess of the limits as user name changes will be guarded against over
        /// run.
        /// </summary>
        /// <param name="textToFit"></param>
        private static void FitTextToWindow (GameText textToFit)
        {
            modifiedText.Clear();
            modifiedText.Append(textToFit.Text);
            currentText.Text = modifiedText.ToString();

            // If text is too wide to fit window, append elipses and keep reducing it
            // until it fits
            if(currentText.Width > GameConstants.INV_MAX_TITLE_LENGTH)
            {
                modifiedText.Append("...");
                currentText.Text = modifiedText.ToString();

                while (currentText.Width > GameConstants.INV_MAX_TITLE_LENGTH)
                {
                    modifiedText.Remove(modifiedText.Length - 4, 1);
                    currentText.Text = modifiedText.ToString();
                }
            }
        }

        /// <summary>
        /// Takes player keyboard input and either updates selection change or activates an action on
        /// the selected item. If the rename window is open, control is passed over and directed to
        /// that window. Handles timing for when player holds a key while using Inventory window.
        /// </summary>
        /// <param name="key"></param>
        /// <param name="gameTime"></param>
        /// <param name="dropped"></param>
        /// <param name="showRenameItemScreen"></param>
        /// <returns></returns>
        internal static bool ProcessPlayerInputs(Keys key, GameTime gameTime,
            out List<InventoryItem> dropped, out bool showRenameItemScreen)
        {
            dropped = nothingToDrop; // Prevents creating a new list with every loop
            showRenameItemScreen = usingRenameItemScreen;
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;

            if (firstLoop) UpdateCurrentItem();
            if (firstLoop && key != Keys.None) return false; // Forces keys to be released upon entry of first loop
            firstLoop = false;

            

            // If no key pressed, or input passes directly to the RenameScreen, there should be no more delay in this class
            if (key == Keys.None || key != lastKey || usingRenameItemScreen) currentDelay = GameConstants.NO_DELAY;



            if (usingRenameItemScreen)
            {
                Debug.Assert(currentItem != null);
                string reservedText = GetItem(inventoryList.ElementAt(selectedIndex).Key).ReservedTextForTitle;
                
                if (RenameItemScreen.ProcessPlayerInputs(key, gameTime, resetInputWindow, reservedText, out response))
                {
                    // Screen closed
                    usingRenameItemScreen = false;
                    firstLoop = true;
                }

                resetInputWindow = false;
                if (response != string.Empty)
                    Rename(currentItem,true);

                lastKey = key;
                return false; // The inventory window stays open
            } else if (key != Keys.None && elapsedTime > currentDelay)
            {

                elapsedTime = 0;
                
                // When a key is first pressed, the initial delay should be set
                if (key != lastKey) currentDelay = GameConstants.INITIAL_KEY_DELAY;

                // Once the initial delay is over, if the key is still held down, then repeating is allowed
                else currentDelay = GameConstants.HOLD_KEY_DELAY;

                switch (key)
                {
                    case Keys.Up: selectedIndex--; break;
                    case Keys.Down: selectedIndex++; break;
                    case Keys.Enter:
                        if (currentItem != null)
                        {
                            if (currentItem is IWearable) Equip(currentItem);
                            else if (currentItem is IConsumable) Consume(currentItem);
                            // TODO: Add options for reading scrolls, drinking potions, and eating food using respective interfaces
                            // IReadable, IConsumable
                        }
                        break;
                    case Keys.Delete:
                        if (currentItem != null)
                        {
                            if (currentItem is IWearable && (currentItem as IWearable).Equipped) Unequip(currentItem);
                            else Drop(currentItem);
                        }
                        break;
                    case Keys.R: if(currentItem != null && currentItem is INamable) Rename(currentItem); break;
                    case Keys.Escape: readyToLeave = true; break;
                }
                
                UpdateCurrentItem();
                UpdateKeyboardInstructions();
            }

            lastKey = key;
            if(readyToLeave)
            {
                dropped = dropList.ToList();
                dropList.Clear();
                firstLoop = true; // Reset for next time window opens
                readyToLeave = false;
                return true;
            } else
            return false; // Does not allow inventory menu to exit yet
        }

        /// <summary>
        /// Dynamicaly adjusts keyboard instructions based on the item selected. Does not change base
        /// options to change selection or exit the screen.
        /// </summary>
        private static void UpdateKeyboardInstructions()
        {
            if (currentItem != null)
            {
                // Delete key action
                if (currentItem is IWearable && (currentItem as IWearable).Equipped)
                    inputInstructions["Del"] = "Unequip";
                else
                    inputInstructions["Del"] = "Drop";

                // Enter key action
                if (currentItem is IWearable && !(currentItem as IWearable).Equipped)
                    inputInstructions["Enter"] = "Equip";
                else if (currentItem is IConsumable)
                    inputInstructions["Enter"] = "Consume";
                else
                    inputInstructions["Enter"] = string.Empty;

                // R key action
                if (currentItem is INamable)
                    inputInstructions["R"] = "Rename";
                else
                    inputInstructions["R"] = string.Empty;
            }
            else
            {
                inputInstructions["Del"] = string.Empty;
                inputInstructions["Enter"] = string.Empty;
                inputInstructions["R"] = string.Empty;

            }
        }

        /// <summary>
        /// Sets the currentItem marker depending on the state of the Inventory List. An empty list
        /// will have the marker set to -1. If the marker is already at -1 when a new item is added,
        /// the marker will be set to index 0 pointing to the new item.
        /// </summary>
        private static void UpdateCurrentItem()
        {
            if (inventoryList.Count > 0)
            {
                selectedIndex = MathHelper.Clamp(selectedIndex, 0, inventoryList.Count - 1);
                searchString = inventoryList.ElementAt(selectedIndex).Key;
                currentItem = GetItem(searchString);
            }
            else
            {
                selectedIndex = -1;
                currentItem = null;
            }
            UpdateKeyboardInstructions();

        }

        /// <summary>
        /// Adds picked up items to the inventory and stacks any stackable
        /// items if one already exists of the same item class.
        /// </summary>
        /// <param name="item">InventoryItem being picked up or added through any other means.</param>
        internal static void Add(InventoryItem item)
        {
            if (graphicsDevice == null)
                throw new InvalidOperationException("Inventory not Initialized.");

            weight += item.InventoryWeight;
            bool itemExistsInInventory = false;
            if(item is IStackable && inventoryContents.Count>0)
                // If item of same class already in inventory, then add the new item qty to the inventory
                foreach(var existingItem in inventoryContents)
                    if(existingItem.Value.Class == item.Class)
                    {
                        // Preserve objects from Dictionaries before replacing them
                        var listKey = existingItem.Value.SortingValue;
                        var existingGameText = inventoryList[listKey];
                        var existingStack = existingItem.Value;

                        // Update quantity
                        (existingStack as IStackable).Add((item as IStackable).Qty);

                        // Update GameText to show new quantity
                        existingGameText.Text = existingStack.InventoryTitle;

                        // Remove old item from dictionary and replace with new item (because key changed).
                        inventoryList.Remove(listKey);
                        inventoryList.Add(existingStack.SortingValue, existingGameText);
                        itemExistsInInventory = true;
                        break;
                    }
            if(!itemExistsInInventory)
            {   // Otherwise, add the new item to the inventory instead
                inventoryContents.Add(item.UniqueID, item);
                inventoryList.Add(item.SortingValue, new GameText(item.InventoryTitle, graphicsDevice));
            }
            
            if (inventoryList.Count == 1) UpdateCurrentItem();
        }

        /// <summary>
        /// Drops a single item from the inventory. Stackable items are separated in this way.
        /// dropList will carry these items back to the main game engine where they can be placed
        /// around the hero.
        /// </summary>
        /// <param name="item"></param>
        /// <returns>True if item dropped successfully</returns>
        private static bool Drop(InventoryItem item)
        {
            if (item == null) return false;

            InventoryItem itemRemoved = null;
            bool dropFromList = true;
            if (item is IStackable && (item as IStackable).Qty>1)
            {   // To remove only one item from the stack and drop it on the floor
                // leaving the stack in the inventory with adjusted values

                IStackable itemStack = item as IStackable;
                // Preserve old inventoryList Dictionary values on item
                var oldItemSortingValue = item.SortingValue;
                var oldItemInventoryGameText = inventoryList[oldItemSortingValue];
                
                // Remove old item from inventoryList (not contents though)
                inventoryList.Remove(oldItemSortingValue);

                // Get the consumed item by removing it from the stack
                itemRemoved = (InventoryItem)((item as IStackable).Remove());

                // Update the GameText object using the new InventoryTitle (incorperates qty change)
                oldItemInventoryGameText.Text = item.InventoryTitle;

                // Insert the updated data back into the Dictionary (because the key is different, we couldn't just change it)
                inventoryList.Add(item.SortingValue, oldItemInventoryGameText);

                dropFromList = false;
            }

            if(dropFromList && inventoryContents.Remove(item.UniqueID))
            {
                // Item is last in the stack, or is not stackable so drop it from the list
                inventoryList.Remove(item.SortingValue);
                weight -= item.InventoryWeight;
                dropList.Add(item);
                return true;
            } else if(!dropFromList && itemRemoved != null)
            {
                // Item is not last from stack, but still need to drop an item on the floor
                weight -= itemRemoved.InventoryWeight;
                dropList.Add(itemRemoved);
            }
            else return false;  // Was not able to drop item from list

            UpdateCurrentItem();
            return true; // Drop was successful
        }

        /// <summary>
        /// Separates a consumable from the stack (if stackable) and consumes it triggering its effect.
        /// The weight is adjusted with the loss of the item and the item is removed from the list if it
        /// is the last of its kind in the stack or otherwise not stackable. Consumed items do not get dropped
        /// to the floor.
        /// </summary>
        /// <param name="item">Item to be consumed.</param>
        private static void Consume(InventoryItem item)
        {
            if (item == null || !(item is IConsumable)) return;


            IConsumable consumedItem;
            bool lastOfStack = false;

            

            if (item is IStackable && (item as IStackable).Qty > 1)
            {
                // Preserve old inventoryList Dictionary values on item
                var oldItemSortingValue = item.SortingValue;
                var oldItemInventoryGameText = inventoryList[oldItemSortingValue];

                // Remove old item from inventoryList (not contents though)
                inventoryList.Remove(oldItemSortingValue);

                // Get the consumed item by removing it from the stack
                consumedItem = (IConsumable)((item as IStackable).Remove());

                // Update the GameText object using the new InventoryTitle (incorperates qty change)
                oldItemInventoryGameText.Text = item.InventoryTitle;

                // Insert the updated data back into the Dictionary (because the key is different, we couldn't just change it)
                inventoryList.Add(item.SortingValue, oldItemInventoryGameText);
            }
                
            else
            {
                consumedItem = item as IConsumable;
                lastOfStack = true;
            }



            // Consume the item and get the string response from it for the message log
            string attemptResponse = consumedItem.Consume();
            if (attemptResponse != string.Empty)
            {
                InventoryEffectManager.AddMessageToQueue(attemptResponse);
                readyToLeave = true;
            }

            // If last in the stack, remove the stack and update inventory weight
            if (lastOfStack && inventoryContents.Remove(item.UniqueID))
            {
                inventoryList.Remove(item.SortingValue);
                weight -= item.InventoryWeight;
            } else // otherwise just update the inventory weight
            if (!lastOfStack)
            {
                weight -= (consumedItem as InventoryItem).InventoryWeight;
            }

            else throw new IndexOutOfRangeException("Item to be removed not found in the Inventory's Contents List");
            UpdateCurrentItem();
        }

        /// <summary>
        /// Attempts to put on a wearable InventoryItem if there is space. Does not remove items to do so.
        /// </summary>
        /// <param name="item">Item to put on</param>
        private static void Equip(InventoryItem item)
        {
            if (item == null || !(item is IWearable)) return;
            var wornItem = item as IWearable;
            if (wornItem.Equipped) return;

            // Identify all items of the same class that are equiped. Most classes will have only
            // one item equiped at a time, but rings may have more than one. This list is used to
            // handle removing and replacing one worn item with another.
            List<InventoryItem> replaces = new List<InventoryItem>();
            foreach (var kvPair in inventoryContents) // UniqueID, InventoryItem
            {
                if (kvPair.Value.Class != item.Class) continue;
                // If they are the same class, then assume IWearable
                if ((kvPair.Value as IWearable).Equipped)
                    replaces.Add(kvPair.Value);
            }

            
            string attemptResponse = wornItem.Equip(replaces);
            if (attemptResponse != string.Empty)
            {
                InventoryEffectManager.AddMessageToQueue(attemptResponse);
                readyToLeave = true;
            }
            GameText inventoryText = inventoryList[searchString];
            inventoryText.Text = item.InventoryTitle + wornItem.WornOn;
            inventoryList.Remove(searchString);
            inventoryList.Add(item.SortingValue, inventoryText);
        }

        /// <summary>
        /// Attempts to unequip an item if it is not cursed. Cursed items are blocked from removal.
        /// </summary>
        /// <param name="item">Item to remove from body</param>
        private static void Unequip( InventoryItem item)
        {
            if (item == null || !(item is IWearable)) return;
            var wornItem = item as IWearable;
            if (!wornItem.Equipped) return;

            string attemptResponse = wornItem.Unequip();
            if (attemptResponse != string.Empty)
            {
                InventoryEffectManager.AddMessageToQueue(attemptResponse);
                readyToLeave = true;
            }
            inventoryList[searchString].Text = item.InventoryTitle + wornItem.WornOn;
        }

        /// <summary>
        /// Allows player to rename some items
        /// </summary>
        /// <param name="item">Item to be renamed</param>
        /// <param name="receivedResponse">Result message returned to the player</param>
        private static void Rename(InventoryItem item ,bool receivedResponse = false)
        {
            if (!receivedResponse)
            {
                usingRenameItemScreen = true;
                resetInputWindow = true;
                RenameItemScreen.Prompt = "What would you call it?";
                RenameItemScreen.Value = string.Empty;
            }
            else
            {
                string itemKey = inventoryList.ElementAt(selectedIndex).Key;
                if(item is INamable)
                {
                    GameText gameText = inventoryList[itemKey];
                    inventoryList.Remove(itemKey);
                    (item as INamable).Rename(response);
                    if(item is IWearable)
                    {
                        gameText.Text = item.InventoryTitle + (item as IWearable).WornOn;
                    } else
                        gameText.Text = item.InventoryTitle;
                    inventoryList.Add(item.SortingValue, gameText);

                }
                usingRenameItemScreen = false;
            }
        }


        #endregion


    }
}
