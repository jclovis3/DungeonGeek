﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{
    static class Inventory
    {
        private static List<InventoryItem> inventoryList = new List<InventoryItem>();
        internal static List<InventoryItem> InventoryList
        {
            get { return inventoryList; }
        }
        
        private static float weight = 0;
        internal static float Weight
        {
            get { return weight; }
        }

        internal static void Add(InventoryItem item)
        {
            weight += item.InventoryWeight;
            inventoryList.Add(item);
        }

        internal static bool Drop(InventoryItem item)
        {
            if (inventoryList.Remove(item))
            {
                weight -= item.InventoryWeight;
                return true;
            }
            else return false;
        }

        internal static int ArmorRating()
        {
            int rating = 0;
            foreach (var item in inventoryList)
            {

                if (item.Class == InventoryItem.itemClasses.Armor)
                    // TODO: Update after armor class is created
                    rating += 0;
            }
            return rating;
        }


    }
}
