﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGeek
{

    /// <summary>
    /// Handles sprite font loading and string output in XNA/MonoGame.
    /// </summary>
    class GameText
    {

        const string FONT_FILE = @"Sprites\Fonts\Arial";
        
        #region Fields
        static private SpriteFont font;
        private string text;
        private Point location;
        

        #endregion

        #region Properties

        public string Text
        {
            set { text = value; }
            get { return text; }
        }

        public int X
        {
            set { location.X = value; }
            get { return location.X; }
        }

        public int Y
        {
            set { location.Y = value; }
            get { return location.Y; }
        }

        public Point Location
        {
            set { location = value; }
            get { return location; }
        }

        public int Height
        {
            get { return font.LineSpacing; }
        }

        public int Width
        {
            get { return (int)font.MeasureString(Text).Length(); }
        }


        #endregion

        #region Constructors
        public GameText (string text, Point location)
        {
            Text = text;
            Location = location;
        }

        public GameText(string text) : this(text, new Point(0,0)) { }

        public GameText() : this("", new Point(0, 0)) { }

        #endregion


        static public void LoadContent(ContentManager content)
        {
            font = content.Load<SpriteFont>(FONT_FILE);
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            spriteBatch.DrawString(font, Text, new Vector2(X, Y), Color.Yellow);

        }

    }
}
