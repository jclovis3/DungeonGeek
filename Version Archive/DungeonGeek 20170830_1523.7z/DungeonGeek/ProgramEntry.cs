﻿using System;
using System.Windows.Forms;
using System.Text;


namespace DungeonGeek
{
#if WINDOWS || LINUX
    /// <summary>
    /// The main class.
    /// </summary>
    public static class ProgramEntry
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            using (var game = new DungeonGameEngine())
            {
                // Open the about screen in new thread so game engine can load while user reads it.
                System.Threading.Tasks.Task.Factory.StartNew(() => ShowAboutScreen());

                game.Run();
            }
            
        }

        /// <summary>
        /// Shows modal dialog of about contents. Called from within DungeonGameEngine to decrease
        /// delay after closing the dialog.
        /// </summary>
        internal static void ShowAboutScreen()
        {
            StringBuilder aboutText = new StringBuilder();
            aboutText.Append("Dungeon Geek\n");
            aboutText.Append("version 0.1\n");
            aboutText.Append("\n");
            aboutText.Append("Explore a randomly generated dungeon\n");
            aboutText.Append("Concept inspired by Rogue, a game created by Jon Lane and released for DOS in 1983.");
            MessageBox.Show(aboutText.ToString());

            /*
             * Version History:
             * v0.1 - Basic map generation and hero movement through map. Included one loot item
             *        for picking up and adding to inventory.
             *        Started: 8/17/2017
             *        Last Update: 8/23/2014
             *
             *
             * */
        }
    }
#endif
}
