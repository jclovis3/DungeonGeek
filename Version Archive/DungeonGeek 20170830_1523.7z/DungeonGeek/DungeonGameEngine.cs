﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonGeek
{
    /// <summary>
    /// Runs the game loop and all major event cycles are launched from here.
    /// </summary>
    public class DungeonGameEngine : Game
    {
        
        // Planning Notes:
        // PLANNING: Create class for storing and processing magical effects of inventory
        // PLANNING: When hero is unconcious, set delay slow enough the player can see monsters move.
        // PLANNING: Implement a screen to show controlls and possibly a way to remap some of them.
        // PLANNING: Implement variable zoom by mouse scroll wheel and keyboard
        // PLANNING: Allow mouse click to set target run-to point
        



        #region Constants and Enums
        enum Direction {Up, UpRight, Right, DownRight, Down, DownLeft, Left, UpLeft}

        // Floor plan uses tiled references to track type of surface. Objects found
        // within the dungeon will have location relative to this floor plan.
        const int FLOOR_WIDTH = 80; // Normal is 80
        const int FLOOR_HEIGHT = 80;// Normal is 80
        //JC: Change to variable floor sizes that get larger as you go deeper
        // Requires testing of large floor sizes to see what might fail.

        // Pixels each tile in floor plan will consume on screen at normal zoom level
        const int TILE_SIDE_NORMAL = 35;
        

        // Number of tiles to be visible at one time (best if odd to create
        // same margin on both sides of hero)
        const int VIEW_WIDTH = 27;
        const int VIEW_HEIGHT = 19;
        
        

        // Key timing controls
        const int UPDATE_DELAY_NO_KEYS_PRESSED = 0;
        const int INITIAL_KEY_DELAY = 500;
        const int RAPID_CYCLE_DELAY = 20;


        const int CHANCE_TO_FIND = 20;
        
        const bool DEBUG_MODE_WALK_THROUGH_WALLS = false;
        const bool DEBUG_MODE_REVEAL = false;
        #endregion




        #region Fields

        // Graphics and game timing
        int elapsedTime = 0;
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Viewport statsViewPort;
        Viewport mainViewPort;
        

        // Map view and manipulation
        Rectangle localView; // Viewable area of map - moves with hero
        int tileHeight = TILE_SIDE_NORMAL;
        int tileWidth = TILE_SIDE_NORMAL;

        FloorTile.Surfaces[,] floorPlan; // Contains walkable and blockable surfaces for current floor
        bool[,] floorRevealed;
        List<InventoryItem> scatteredLoot; // Items to be discovered on floor while walking around
        List<InventoryItem> pickupList = new List<InventoryItem>();
        bool showMap = false;
        Rectangle lastWindowSize;

        // Game state data
        int floorLevel = 1;
        Hero hero;
        List<String> outputMessageQueue = new List<string>();
        string returnedMessageText;
        Random rand = new Random();
        GameText message;
        GameText stats;

        // Keyboard handling
        KeyboardState keyState;
        bool isRapid = false;
        bool keyDown = false;
        bool isShiftDown = false;
        bool isRunning = false;
        int currentDelay = UPDATE_DELAY_NO_KEYS_PRESSED;


        #endregion




        #region Constructor
        /// <summary>
        /// CONSTRUCTOR
        /// </summary>
        public DungeonGameEngine()
        {
            
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            
        }

        #endregion
        



        #region Game Class Overrides and Events

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {

            // Adjust window to 3/4 of screen size and allow resizing
            graphics.PreferredBackBufferWidth = (int)(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width* 0.75);
            graphics.PreferredBackBufferHeight = (int)(GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height * 0.75);
            graphics.ApplyChanges();
            lastWindowSize = Window.ClientBounds;
            Window.AllowUserResizing = true;
            Window.ClientSizeChanged += Window_ClientSizeChanged;
            IsMouseVisible = true;
            hero = new DungeonGeek.Hero();
            stats = new GameText(StatText());
            statsViewPort = GraphicsDevice.Viewport;
            mainViewPort = GraphicsDevice.Viewport;
            
            base.Initialize();
        }


        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            
            // Note, scattered loot items are loaded in the generateMap() method because creating a
            // new floor level destroys any loot items left on the floor and the sprites along with them.
            // This way, when a new list of scattered loot is created, the sprites for them can be loaded.

            GenerateMap();
            hero.LoadContent(Content);
            FloorTile.LoadContent(Content);
            GameText.LoadContent(Content);
            UpdateViewPorts(); // Requires that GameText content be loaded first

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
            base.UnloadContent();
        }

       
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (lastWindowSize != Window.ClientBounds) Window_ClientSizeChanged(this,EventArgs.Empty);

            ProcessMessageQueue();
            keyDown = IsKeyPressed(); // Gets new keyState
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            if (currentDelay < elapsedTime)
            {
                elapsedTime = 0;
                ProcessPlayerInputs();
                
                if (currentDelay == INITIAL_KEY_DELAY) isRapid = true;
            }


            if (keyDown)
            {
                if (isRunning && !isRapid)
                {
                    currentDelay = UPDATE_DELAY_NO_KEYS_PRESSED;
                }
                else
                {
                    if (isRapid) currentDelay = RAPID_CYCLE_DELAY;
                    else currentDelay = INITIAL_KEY_DELAY;
                }
            }
            else
            {
                currentDelay = UPDATE_DELAY_NO_KEYS_PRESSED;
                isRapid = false;
            }
            
            

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black); // Seems to affect whole screen regardless if placed after Viewport is assigned.

            #region Main ViewPort SpriteBatch Drawing Cycle
            GraphicsDevice.Viewport = mainViewPort;
            spriteBatch.Begin(); // requires an End

            Rectangle tileSize = new Rectangle(0, 0, tileWidth, tileHeight);

            // Draw floor tiles
            for (int x = 0; x < FLOOR_WIDTH; x++)
                for (int y = 0; y < FLOOR_HEIGHT; y++)
                    if(floorRevealed[x,y] || DEBUG_MODE_REVEAL)
                        FloorTile.Draw(spriteBatch,
                            floorPlan[x,y],     // Tile type to draw
                            FloorGenerator.TranslateRecToTile( // Rectangle to draw in
                              tileSize,
                              localView,
                              new Point(x, y)));
            
            // Draw scattered loot
            foreach (var item in scatteredLoot)
            {
                if (floorRevealed[item.Location.X,item.Location.Y] || DEBUG_MODE_REVEAL)
                    item.Draw(spriteBatch, FloorGenerator.TranslateRecToTile(tileSize, localView, item.Location));
            }

            hero.Draw(spriteBatch,
                FloorGenerator.TranslateRecToTile(tileSize, localView, hero.Location));
            
            spriteBatch.End();
            #endregion


            #region Stats ViewPort SpriteBatch Drawing Cycle
            GraphicsDevice.Viewport = statsViewPort;
            
            spriteBatch.Begin();
            stats.Draw(spriteBatch);
            spriteBatch.End();
            #endregion

            base.Draw(gameTime);
        }

        /// <summary>
        /// Event handler for user changing the size of the window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_ClientSizeChanged(object sender, EventArgs e)
        {
            lastWindowSize = Window.ClientBounds;
            graphics.PreferredBackBufferWidth = lastWindowSize.Width;
            graphics.PreferredBackBufferHeight = lastWindowSize.Height;
            graphics.ApplyChanges();
            UpdateViewPorts();
        }


        #endregion




        #region Game Play

        /// <summary>
        /// Generates the line of text for displaying hero and game status data
        /// </summary>
        /// <returns>string of text to display</returns>
        private string StatText()
        {
            StringBuilder statsRow = new StringBuilder();
            statsRow.Append(string.Format("Floor: {0}", floorLevel));
            statsRow.Append(string.Format("     HP: {0}", hero.HP));
            statsRow.Append(string.Format("     XP [ {0} ] {1}/{2}", hero.XPLvl, hero.XP, hero.XpToNext()));
            statsRow.Append(string.Format("     Armor: {0}", Inventory.ArmorRating()));
            statsRow.Append(string.Format("     Str: {0}/{1}", hero.EffectiveStrength(), hero.BaseStrength));
            statsRow.Append(string.Format("     Energy: {0}/{1}", hero.Energy, Hero.FULL_ENERGY));
            return statsRow.ToString();
        }


        /// <summary>
        /// Accepts keyboard inputs and processes game logic in response to those inputs
        /// </summary>
        private void ProcessPlayerInputs()
        {

            if (keyState.IsKeyDown(Keys.Escape) && !isRapid)
                if (!ShowGameMenu())
                    return; // Quick exit if user selects exit from menu.

            // Press comma to descend the stairs
            if (keyState.IsKeyDown(Keys.OemComma) && !isRapid &&
                floorPlan[hero.Location.X, hero.Location.Y] == FloorTile.Surfaces.StairsDown)
            {
                floorLevel++;
                GenerateMap();
                ToggleView(true);
            }

            if (keyState.IsKeyDown(Keys.M) && !isRapid) ToggleView();



            #region Movement actions


            isRunning = isShiftDown && !DEBUG_MODE_WALK_THROUGH_WALLS;

            if (isRunning) isRapid = false;

            // If runEnabled and a monster is close, the run will drop out
            if (keyState.IsKeyDown(Keys.Left)) Move(Direction.Left, isRunning);
            if (keyState.IsKeyDown(Keys.Right)) Move(Direction.Right, isRunning);
            if (keyState.IsKeyDown(Keys.Up)) Move(Direction.Up, isRunning);
            if (keyState.IsKeyDown(Keys.Down)) Move(Direction.Down, isRunning);
            if (keyState.IsKeyDown(Keys.PageUp)) Move(Direction.UpRight, isRunning);
            if (keyState.IsKeyDown(Keys.Home)) Move(Direction.UpLeft, isRunning);
            if (keyState.IsKeyDown(Keys.PageDown)) Move(Direction.DownRight, isRunning);
            if (keyState.IsKeyDown(Keys.End)) Move(Direction.DownLeft, isRunning);


            #endregion


        }

        private bool IsKeyPressed()
        {
            keyState = Keyboard.GetState();
            bool rtnVal = (keyState.GetPressedKeys().Length != 0);
            isShiftDown = (keyState.IsKeyDown(Keys.LeftShift) || keyState.IsKeyDown(Keys.RightShift));

            return rtnVal;
            // Keys.None seems to be true all the time
        }


        /// <summary>
        /// Checks the ground below the hero's feet and picks up the item if there is room.
        /// Works on stacks of items if on the same space as well. 
        /// </summary>
        private void PickUpItem()
        {
            // Created pickupList as class variable so as not to create
            // and dispose of a new object with every move. Can't alter the scatteredLoot
            // list while iterating through it so a secondary list was needed.
            pickupList.Clear();
            foreach (var item in scatteredLoot)
            {
                if (item.Location == hero.Location && hero.AttemptPickupItem(item))
                {
                    pickupList.Add(item);
                }
            }

            foreach (var item in pickupList)
                scatteredLoot.Remove(item);
        }

        /// <summary>
        /// Calls upon the FloorGenerator to create a map, loot and monsters, then
        /// requests those items after they are created.
        /// </summary>
        private void GenerateMap()
        {
            Point heroStartLocation;
            FloorGenerator.CreateNewFloor(floorLevel, FLOOR_WIDTH, FLOOR_HEIGHT, out heroStartLocation, out floorPlan, out scatteredLoot);
            floorRevealed = new bool[FLOOR_WIDTH, FLOOR_HEIGHT];
            hero.Location = heroStartLocation;

            // Ensures content is loaded for each item in inventory because reference to the item's
            // sprite is lost when the list is reset.
            foreach (InventoryItem item in scatteredLoot)
            {
                item.LoadContent(this.Content);
            }
        }


        private void ProcessMessageQueue()
        {
            while (outputMessageQueue.Count > 0)
            {
                // queued up messages for acknoledgement one at a time.
                outputMessageQueue.RemoveAt(0);
            }

        }

        /// <summary>
        /// Displays a basic menu for events such as Loading, Saving, Quitting, and serves as
        /// a pause while hero is not concious.
        /// </summary>
        /// <returns>True if staying in game, else false</returns>
        private bool ShowGameMenu()
        {
            // For now just ends the game
            // TODO: Develop Esc game menu
            int userChoice = 0;
            switch (userChoice)
            {
                case 0: Exit(); return false;
                default: return true;
            }

        }

        #endregion




        #region Movement

        /// <summary>
        /// Allows drawRectangles to be updated for loot, hero or anything else after
        /// moving the localView around.
        /// </summary>
        private void UpdateLocations()
        {
            
            foreach (var item in scatteredLoot)
            {
                item.Update(localView, tileWidth, tileHeight);
            }
            hero.Update(localView, tileWidth, tileHeight);
            
            // When room is lit, whole room lights up, otherwise, just spaces around the hero.
            ShowLitSpaces();

            stats.Text = StatText();
        }

        /// <summary>
        /// Consolidates all 8 movement methods into one, passes the new location to be
        /// checked to see if it is blocked, and moves only if it is not. If move is successfull,
        /// monsters are given a chance to move and if there are output messages queued up, they
        /// get a chance to be viewed and acknowledged. Each of these actions were appended to the
        /// move method because they are also required for each step when running.
        /// </summary>
        /// <param name="direction">Direction to move</param>
        /// <returns>True is moved, false if blocked</returns>
        private bool Move(Direction direction, bool running = false)
        {
            if (running)
            {
                // The runUntilStopped method will call upon the move method without a value for running, so this block
                // will be skipped for each loop within the run. When the run is blocked, it returns here
                // and returning false from here indicates that there were no more moves.
                RunUntilStopped(direction);
                return false;
            }


            var newPoint = GetNewPointFrom(direction, hero.Location);
                if(newPoint == hero.Location) return false; // No change in movement means no movement key was pressed
            
            if (!Blocked(newPoint.X, newPoint.Y))
            {
                hero.Location = newPoint;
                if (NoticeHidden(out returnedMessageText))
                {
                    outputMessageQueue.Add("You found a " + returnedMessageText);
                }
                PickUpItem(); // anything the hero is standing on
                MoveMonsters();
                PanViewWithHero();
                
            }
            else return false;
            return true;
        }


        /// <summary>
        /// Checks to see if new space is beyond the map boarders or is a non-walkable surface.
        /// </summary>
        /// <param name="newX"></param>
        /// <param name="newY"></param>
        /// <returns></returns>
        private bool Blocked(int newX, int newY)
        {
            // Map boarder check
            if ((newX <= 0) ||
                (newY <= 0) ||
                (newX >= FLOOR_WIDTH - 1) ||
                (newY >= FLOOR_HEIGHT - 1)) return true;

            // Tile type check
            if (!DEBUG_MODE_WALK_THROUGH_WALLS)
                if (floorPlan[newX, newY] == FloorTile.Surfaces.LockedDoor ||
                    floorPlan[newX, newY] == FloorTile.Surfaces.Void ||
                    floorPlan[newX, newY] == FloorTile.Surfaces.HiddenDoor ||
                    floorPlan[newX, newY] == FloorTile.Surfaces.Wall) return true;

            // TODO: Monster type check

            return false;
        }


        /// <summary>
        /// Detects if hero is next to objects, doors, stairs that may stop him
        /// from running.
        /// </summary>
        /// <returns></returns>
        private bool NearObject()
        {
            for(int x=hero.Location.X-1; x<hero.Location.X+2; x++)
                for(int y=hero.Location.Y-1; y<hero.Location.Y+2; y++)
                {
                    foreach (var item in scatteredLoot)
                        if (item.Location.X == x && item.Location.Y == y) return true;
                    var tileType = floorPlan[x, y];
                    if (tileType == FloorTile.Surfaces.LockedDoor ||
                        tileType == FloorTile.Surfaces.OpenDoor ||
                        tileType == FloorTile.Surfaces.StairsDown ||
                        tileType == FloorTile.Surfaces.StairsUp) return true;
                }
            return false;
        }


        /// <summary>
        /// Checks to see if near tunnel intersection. Allows up to 2 neighboring tunnel
        /// spaces near hero (excluding diagonals) to not be in an intersection.
        /// </summary>
        /// <returns></returns>
        private bool NearTunnelIntersection()
        {
            var tunnelCount = 0;

            if (TunnelContinues(Direction.Up, hero.Location)) tunnelCount++;
            if (TunnelContinues(Direction.Down, hero.Location)) tunnelCount++;
            if (TunnelContinues(Direction.Left, hero.Location)) tunnelCount++;
            if (TunnelContinues(Direction.Right, hero.Location)) tunnelCount++;
            if (tunnelCount > 2) return true;
            else return false;
            
        }


        /// <summary>
        /// Supports tunnel running by catching changes in tunnel direction as long
        /// as hero is not near an intersection.
        /// </summary>
        /// <param name="currentDirection"></param>
        /// <returns>New direction to follow tunnel with</returns>
        private void UpdateDirectionWithTunnel(ref Direction currentDirection)
        {
            // enum Direction {Up, UpRight, Right, DownRight, Down, DownLeft, Left, UpLeft}
            var cameFrom = (int)currentDirection - 4;
            if (cameFrom < 0) cameFrom += 8;
            for (int direction = 0; direction < 8; direction+=2) // skip diagonals
                if (direction != cameFrom &&
                    TunnelContinues((Direction)direction, hero.Location))
                {
                    currentDirection = (Direction)direction;
                    return;
                }
        }

        /// <summary>
        /// Checks to see if the tunnel continues in the direction indicated.
        /// </summary>
        /// <param name="direction">Direction from given point</param>
        /// <param name="fromPoint">Point to look from</param>
        /// <returns>True if tunnel continues in the indicated direction, otherwise false</returns>
        private bool TunnelContinues(Direction direction, Point fromPoint)
        {
            var newPoint = GetNewPointFrom(direction, fromPoint);
            return (floorPlan[newPoint.X, newPoint.Y] == FloorTile.Surfaces.Tunnel);

        }

        private Point GetNewPointFrom(Direction direction, Point fromPoint)
        {
            var newX = fromPoint.X;
            var newY = fromPoint.Y;
            switch (direction)
            {
                case Direction.UpLeft: newX--; newY--; break;
                case Direction.Up: newY--; break;
                case Direction.UpRight: newX++; newY--; break;
                case Direction.Right: newX++; break;
                case Direction.DownRight: newX++; newY++; break;
                case Direction.Down: newY++; break;
                case Direction.DownLeft: newX--; newY++; break;
                case Direction.Left: newX--; break;
                default: break;

            }
            return new Point(newX, newY);
        }

        private bool MonsterIsClose()
        {
            // TODO: Add code to detect monsters within view to force single step keyboard input
            return false;
        }

        /// <summary>
        /// Hero runs straight when in a room until any obstical is found.
        /// Hero runs through a tunnel until a split in the tunnel or any obstical is found.
        /// This entire run happens during a single game loop
        /// </summary>
        /// <param name="direciton">Direction to start running</param>
        private void RunUntilStopped(Direction direction)
        {
            // Determine run condition
            var floorType = floorPlan[hero.Location.X, hero.Location.Y];
            bool isTunnelRunner = (floorType == FloorTile.Surfaces.Tunnel);
            bool isStopped = false;

            // Can't handle running through tunnels on diagonals (evaluates to odd numbered int).
            if (isTunnelRunner && (int)direction % 2 == 1) isStopped = true;

            // Loop the run
            while (!isStopped)
            {
                // For either case
                if (!Move(direction) ||
                    MonsterIsClose() ||
                    NearObject()) isStopped = true;

                PanViewWithHero();

                // For in tunnels
                if (isTunnelRunner && NearTunnelIntersection()) isStopped = true;
                if (!isStopped && isTunnelRunner) UpdateDirectionWithTunnel(ref direction);
            }
            isRunning = false;
            
        }

        /// <summary>
        /// Used after each hero move to allow all monsters to move about and attack.
        /// </summary>
        private void MoveMonsters()
        {
            //TODO: Code the method for moveMonsters()
        }


        #endregion




        #region Visibility


        /// <summary>
        /// Sets the range of tiles on the map that can be viewed within the game window
        /// </summary>
        private void PanViewWithHero()
        {
            // margins are the number of tiles around the hero that should be in the window
            int marginX = (int)Math.Floor((decimal)(localView.Width / 2));
            int marginY = (int)Math.Floor((decimal)(localView.Height / 2));

            // Determines if hero is too close to map edges to remain centered, and centers if not
            if (hero.Location.X < marginX) localView.X = 0;
            else if (hero.Location.X > FLOOR_WIDTH - marginX - 1) localView.X = FLOOR_WIDTH - localView.Width;
            else localView.X = hero.Location.X - marginX;

            if (hero.Location.Y < marginY) localView.Y = 0;
            else if (hero.Location.Y > FLOOR_HEIGHT - marginY - 1) localView.Y = FLOOR_HEIGHT - localView.Height;
            else localView.Y = hero.Location.Y - marginY;
            
            UpdateLocations(); // with new localView, all loot, traps, monsters, etc. need to be updated
        }


        private void UpdateViewPorts()
        {
            // Leave room for message output below stats by invoking with twice the height
            statsViewPort.Height = stats.Height * 2;

            // Change tile sizes based on new view mode
            if (showMap)
            {
                // TODO: If implementing growing floor sizes, check that this display adjustment still works
                tileWidth = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width / FLOOR_WIDTH;
                tileHeight = (GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height - statsViewPort.Height) / FLOOR_HEIGHT;

                // Set both to smallest dimension to keep the tile square
                if (tileWidth < tileHeight) tileHeight = tileWidth;
                else tileWidth = tileHeight;
            }
            else
            {
                tileWidth = TILE_SIDE_NORMAL;
                tileHeight = TILE_SIDE_NORMAL;
                // PLANNING: If changing to a rectangular tile, change this (and showMap above) as
                // not to square off the tile but just ensure the length/width ratio stays the same.
            }



            // Allow statsViewPort to consume the entire width of the screen
            statsViewPort.Width = Window.ClientBounds.Width;

            // Set size of mainViewPort
            mainViewPort.Width = Window.ClientBounds.Width;
            mainViewPort.Height = Window.ClientBounds.Height - statsViewPort.Height;

            // Reduce each dimension of mainViewPort to meet mapSize if too wide/tall
            int mapSizePixelWidth = tileWidth * FLOOR_WIDTH;
            int mapSizePixelHeight = tileHeight * FLOOR_HEIGHT;
            if (mainViewPort.Width > mapSizePixelWidth) mainViewPort.Width = mapSizePixelWidth;
            if (mainViewPort.Height > mapSizePixelHeight) mainViewPort.Height = mapSizePixelHeight;

            // Center main viewport
            mainViewPort.X = Window.ClientBounds.Width / 2 - mainViewPort.Width / 2;
            mainViewPort.Y = (Window.ClientBounds.Height - statsViewPort.Height) / 2 - (mainViewPort.Height / 2) + statsViewPort.Height;
            
            localView.Width = mainViewPort.Width / tileWidth;
            localView.Height = mainViewPort.Height / tileHeight;

            PanViewWithHero(); // attempts to keep hero in center of view
        }



        /// <summary>
        /// Toggles between normal view and map view (full level)
        /// </summary>
        /// <param name="setLocalView"></param>
        private void ToggleView(bool setLocalView = false)
        {
            
            showMap = !showMap && !setLocalView; // toggle view mode

            UpdateViewPorts();


            
        }

        /// <summary>
        /// Identifies spaces near hero that are to be revealed up upon entry into
        /// a lit room or movement in the dark.
        /// </summary>
        private void ShowLitSpaces()
        {
            Rectangle visibleSpace;

            // If hero is in a lit room, light up the room, otherwise, light up only the spaces next
            // to the hero (distance may be expanded with magical effects later).
            if (floorPlan[hero.Location.X, hero.Location.Y] == FloorTile.Surfaces.LitRoom)
            {
                if (FloorGenerator.GetRoomWithPoint(hero.Location, out visibleSpace))
                {
                    // Expand space to include walls
                    visibleSpace.X--;
                    visibleSpace.Y--;
                    visibleSpace.Width += 2;
                    visibleSpace.Height += 2;
                }
            }
            else
            {
                visibleSpace = new Rectangle(hero.Location.X - 1, hero.Location.Y - 1, 3, 3);
            }

            // Cycle through floorRevealed elements to turn them on if within the new
            // visibleSpace rectangle.
            // injected conditional values to prevent sending array out of range of the map.
            for (int x = (visibleSpace.X < 0 ? 0 : visibleSpace.X);
                x < (visibleSpace.Right > FLOOR_WIDTH ? FLOOR_WIDTH : visibleSpace.Right); x++)
                for (int y = (visibleSpace.Y < 0 ? 0 : visibleSpace.Y);
                    y < (visibleSpace.Bottom > FLOOR_HEIGHT ? FLOOR_HEIGHT : visibleSpace.Bottom); y++)
                    floorRevealed[x, y] = true;
            // TODO: Draw glowing light around hero on dark floor tiles

        }

        /// <summary>
        /// Applies CHANCE_TO_FIND in detecting hidden doors and traps around the hero.
        /// </summary>
        /// <param name="foundText">String of what was found for output message</param>
        /// <returns>True if something was detected, otherwise false.</returns>
        private bool NoticeHidden(out string foundText)
        {
            // Check all spaces around hero. Note, if it were under the hero's foot, it
            // would have already been discovered (traps for instance). Removed logic to avoid checking
            // that space because it would affect all the other eight spaces by adding one more
            // comparison to each.
            // TODO: Remove debug option to findHidden();
            foundText = "";
            for (int x = hero.Location.X - 1; x < hero.Location.X + 2; x++)
                for (int y = hero.Location.Y - 1; y < hero.Location.Y + 2; y++)
                    if (x > 0 && y > 0 && x < FLOOR_WIDTH && y < FLOOR_HEIGHT &&
                        floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor && rand.Next(100) < CHANCE_TO_FIND)
                    {
                        floorPlan[x, y] = FloorTile.Surfaces.OpenDoor;
                        foundText = "hidden door";
                        return true;
                    }

            return false;
        }


        #endregion




        #region DEBUG TOOLS
        // These tools are created to test features as they are added.

        // Added to test discovery of hidden doors. Retained for when traps are added. The idea is
        // that the immediate window can be used to set the hero next to the door so it can walk back
        // and fourth (or use search button when implemented) to find it and see that it is revealed
        // safely and the message queue is updated.
        private int FindHidden()
        {
            List<KeyValuePair<Point, FloorTile.Surfaces>> hiddenPlaces = new List<KeyValuePair<Point, FloorTile.Surfaces>>();

            for (int x = 0; x < FLOOR_WIDTH; x++)
                for (int y = 0; y < FLOOR_HEIGHT; y++)
                    if (floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor)
                        hiddenPlaces.Add(new KeyValuePair<Point, FloorTile.Surfaces>(new Point(x, y), floorPlan[x, y]));

            return  hiddenPlaces.Count;
        }


        #endregion
    }


}
