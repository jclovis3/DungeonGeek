﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DungeonGeek
{
    /// <summary>
    /// Generates new levels randomly. Rooms are created with random number of rooms, and sizes.
    /// Loot is scattered randomly within them. Tunnels are drawn to ensure every room is connected
    /// to ensure a path always exists to the stairs. Monsters are also generated and placed randomly.
    /// </summary>
    static class FloorGenerator
    {
        #region Constants and Structs

        struct Range // Used to represent a number range
        {
            public int Low;
            public int High;
        }

        const float DROP_LOOT_CHANCE = 0.003f; // Base chance per floor tile to drop anything before deciding what
        const int MIN_ROOM_FLOOR_DIMENSION = 5;
        const int MAX_ROOM_FLOOR_DIMENSION = 16; // normal 16
        const int MIN_MARGIN_BETWEEN_ROOMS = 1; // width of single tunnel/passage way
        const int DEBUG_OPTION_SET_ROOM_COUNT = 0; // Set to 0 to ignore

        #endregion



        #region Fields

        static private Random rand = new Random();
        static private int levelNumber;
        static private int minRoomCount; // variable because it depends on size of floor
        static private int maxRoomCount; 
        static private int numberOfRooms;
        static private int floorWidth;
        static private int floorHeight;
        static private FloorTile.Surfaces[,] floorPlan;
        static private List<Rectangle> rooms = new List<Rectangle>();

        /* 
         * loot scatter works as follows:
         * Scans through all lit and dark floor tiles and sets chance to drop loot for each
         * tile at DROP_LOOT_CHANCE. If roll passes, then list of lootOptionTypes is iterated through
         * testing a new roll with the individual lootProbablity value. If one passes, it is selected
         * as the loot to drop. If none passes, the iteration cycle repeats until one does.
         */
        static private List<InventoryItem> scatteredLoot;
        static private Dictionary<Type, float> lootProbability = new Dictionary<Type, float>();
        static private InventoryItem newLootItem = null;


        //static private List<Type> monsterOptionTypes = new List<Type>();

        // heroLocation is where the hero will be located on the new floor. Negative
        // values show that this hasn't been set yet
        static private Point heroLocation = new Point(-1,-1); 


        #endregion



        /*   * Floor generation rules:
             
             * Low levels have all lit rooms and no hidden doors
             * As you increase in level, chance of dark room and hidden door increases
             * All rooms must be connected to starting room, even if hidden door is required to access
             * Small percentage of rooms will have lots of treasures, and lots of monsters (not roaming)
             * One room must have a stairs going down. After level 30, odds of finding stairs going up
             *    increase from zero to a percentage equal to 0.05 * the level number (so Level 50
             *    will have a 2.5% chance of having a stair going up) and shall bring the hero
             *    up 5 levels (decrementing the level number). This is so they have an option to fight
             *    easier monsters again. The floor plan will be new as will the loot be repopulated.
             * After level 80, the Golden Grail may be found with 20% chance and increasing 10% every
             *    level. If floor has the Golden Grail, it will be set next to stairs going up which
             *    bring the hero all the way out of the dungeon.
             */


        /// <summary>
        /// Creates the floor structure and contents, wiping any existing floor data
        /// </summary>
        static internal void CreateNewFloor(int level, int width, int height, out Point heroStartLocation, out FloorTile.Surfaces[,] newFloorPlan, out List<InventoryItem> newScatteredLoot)
        {

            // Set private fields
            levelNumber = level;
            floorWidth = width;
            floorHeight = height;

            // Define the number of rooms based on size of level (and DEBUG setting)
            minRoomCount = DEBUG_OPTION_SET_ROOM_COUNT > 0
                ? DEBUG_OPTION_SET_ROOM_COUNT
                : 1 + (int)Math.Ceiling((decimal)width*height/800);

            maxRoomCount = DEBUG_OPTION_SET_ROOM_COUNT>0
                ? DEBUG_OPTION_SET_ROOM_COUNT
                :(int)Math.Floor((decimal)width * height / 400);

            numberOfRooms = rand.Next(minRoomCount, maxRoomCount + 1);

            // Clear floor, loot and monster lists
            rooms.Clear();
            floorPlan = new FloorTile.Surfaces[width, height];
            scatteredLoot = new List<InventoryItem>();
            if (lootProbability.Count == 0) PopulateLootProbabilities();
            // PLANNING: Loot probabilities may be determined by floor level, in which case it should
            // be called with every new level.

            // First create the boarder tiles so tunnels do not route through them.
            for(int x=0; x<width; x++)
            {
                floorPlan[x, 0] = FloorTile.Surfaces.Boarder;
                floorPlan[x, height-1] = FloorTile.Surfaces.Boarder;
            }

            for(int y=1; y<height-1; y++)
            {
                floorPlan[0, y] = FloorTile.Surfaces.Boarder;
                floorPlan[width-1, y] = FloorTile.Surfaces.Boarder;
            }

            
            // Attempts to create the number of rooms determined above. If unable to find space
            // for all of them, accepts what it could and moves on.
            do
            {
                for (int i = 0; i < numberOfRooms; i++)
                {
                    if (!CreateRoom())
                    {
                        // Taking too long to find space for a room, reduce number
                        // of rooms to present quantity
                        numberOfRooms = i;
                        break;
                    }
                }
            }
            // If for some reason it fails to find space for 2 rooms, maybe if it tries again
            // it will pick smaller rooms the next time.
            while (numberOfRooms < 2); 

            PlaceHero();
            PlaceStairsDown();


            while (!CreateTunnels()) // Sometimes the tunnel algorithm gets lockd up and needs a fresh start.
                ClearAllTunnelsAndDoors();

            ChangeUpDoors(); // Sets hidden and locked doors on level


            // Scans through each floor space in rooms only and randomly drops loot
            // which may be weapons, armor, magical items, gold, chests, or anything else
            // that can be picked up.
            foreach (var room in rooms)
            {
                for (int x = room.Left; x < room.Right; x++)
                    for (int y = room.Top; y < room.Bottom; y++)
                        RandomlyDropLoot(x, y);
            }

            // TODO: Place monsters


            // fill OUT parameter values
            newFloorPlan = floorPlan;
            heroStartLocation = heroLocation;
            newScatteredLoot = scatteredLoot;

        }




        #region Room Generation

        /// <summary>
        /// Adds a new room to the list and requests floor and wall tiles get set
        /// </summary>
        /// <returns></returns>
        static private bool CreateRoom()
        {
            int roomWidth = rand.Next(MIN_ROOM_FLOOR_DIMENSION, MAX_ROOM_FLOOR_DIMENSION + 1);
            int roomHeight = rand.Next(MIN_ROOM_FLOOR_DIMENSION, MAX_ROOM_FLOOR_DIMENSION + 1);

            Rectangle newRoom = FindRandomEmptySpace(roomWidth, roomHeight);
            if (newRoom.Width == 0) return false;
            rooms.Add(newRoom);
            PaintRoom(newRoom);
            return true;
        }


        /// <summary>
        /// Seeks void space on map for the size of the room, its surounding walls, and the
        /// required margin of space between rooms.
        /// </summary>
        /// <param name="width">Width of open floor space in room</param>
        /// <param name="height">Height of open floor space in room</param>
        /// <returns></returns>
        static private Rectangle FindRandomEmptySpace(int width, int height)
        { 
            bool foundSpace = false;
            int x=0; int y=0;
            Rectangle testSpace = new Rectangle();
            int iCounter = 0; // Ensures method can give up searching
            while (!foundSpace && iCounter++ < 2000)
            {
                foundSpace = true;

                // Pick coordinate on the floorPlan for new room (without its walls)
                x = rand.Next(1 + MIN_MARGIN_BETWEEN_ROOMS, floorWidth - 1 - width - MIN_MARGIN_BETWEEN_ROOMS);
                y = rand.Next(1 + MIN_MARGIN_BETWEEN_ROOMS, floorHeight - 1 - height - MIN_MARGIN_BETWEEN_ROOMS);
                
                // Create test space to include floor space (width x height) + 2 for walls
                // (each dimension) + 2 for neighboring walls + margin on each side
                testSpace.X = x - 2 - MIN_MARGIN_BETWEEN_ROOMS;
                testSpace.Y = y - 2 - MIN_MARGIN_BETWEEN_ROOMS;
                testSpace.Width = width + 4 + MIN_MARGIN_BETWEEN_ROOMS*2;
                testSpace.Height = height + 4 + MIN_MARGIN_BETWEEN_ROOMS*2;

                // Checks to see if the new random test space intersects an existing room
                foreach (var room in rooms)
                {
                    if(room.Intersects(testSpace))
                    {
                        foundSpace = false;
                        break;
                    }
                }
            } // If test space was bad, repeats loop to try again

            // After predetermined number of attempts, either returns the new space if one was found
            // or returns an empty rectangle indicating that a space could not be found.
            if (!foundSpace) return new Rectangle(0, 0, 0, 0);
            return new Rectangle(x,y,width,height);
        }

        /// <summary>
        /// Sets the tileType to indicate what type of floor (Lit or dark) the room has and the
        /// wall spaces around the room.
        /// </summary>
        /// <param name="room"></param>
        static private void PaintRoom(Rectangle room)
        {
            FloorTile.Surfaces tileType;

            // Probability of having a lit room decreases with each level after level 5
            if (levelNumber > 5 && rand.NextDouble() < ((levelNumber * 0.05) - 0.1))
                tileType = FloorTile.Surfaces.DarkRoom;
            else tileType = FloorTile.Surfaces.LitRoom;

            // paint floor with selected tile type
            // note, the bottom and right of a rectangle is exclusive of the intended dimensions
            for (int x = room.X; x < room.Right; x++)
                for (int y = room.Y; y < room.Bottom; y++)
                    floorPlan[x, y] = tileType;

            // Begin wall painting
            tileType = FloorTile.Surfaces.Wall;

            // paint top and bottom walls
            for(int x=room.X-1; x<room.Right+1;x++)
            {
                floorPlan[x, room.Top - 1] = tileType;
                floorPlan[x, room.Bottom ] = tileType;
            }

            // paint left and right walls
            for(int y=room.Y;y<room.Bottom;y++)
            {
                floorPlan[room.Left - 1, y] = tileType;
                floorPlan[room.Right, y] = tileType;
            }
        }

        #endregion




        #region Hero and Monster placement

        /// <summary>
        /// Randomly places hero in a room (assumes before loot and monster placement)
        /// </summary>
        static private void PlaceHero()
        {
            int roomNumber = rand.Next(rooms.Count);
            heroLocation.X = rand.Next(rooms[roomNumber].Left, rooms[roomNumber].Right);
            heroLocation.Y = rand.Next(rooms[roomNumber].Top, rooms[roomNumber].Bottom);
        }

        #endregion




        #region Loot Placement

        /// <summary>
        /// Populates the lootProbability table for each type of loot.
        /// </summary>
        static internal void PopulateLootProbabilities()
        {
            // See note above declarations to see how probability works
            lootProbability.Add(typeof(MagicalRing), 0.05f);

        }


        /// <summary>
        /// Selects and drops loot based on probability. Location is determined before entering
        /// method and usually involves scanning through all spaces on the floor, but this method
        /// may also be used to garantee something drops and picks randomly what it is. For example,
        /// when killing a monster, it may have its own chance to drop loot.
        /// </summary>
        /// <param name="x">X coordinate of Location to drop</param>
        /// <param name="y">Y coordinate of Location to drop</param>
        /// <param name="forceDrop">Ignors chance of dropping loot and forces it to drop</param>
        static private void RandomlyDropLoot(int x, int y, bool forceDrop = false)
        {

            // Determine if loot should drop
            if (forceDrop || rand.NextDouble()< DROP_LOOT_CHANCE)
            {
                Type lootTypePicked = null;

                // Determine what to drop
                while (lootTypePicked == null)
                    foreach (var lootOption in lootProbability)
                    {
                            if (rand.NextDouble() < lootOption.Value)
                            {
                                lootTypePicked = lootOption.Key;
                                break;
                            }
                    }

                // TODO: Add more loot types to be created after their classes are written
                // Create loot objects
                if (lootTypePicked == typeof(MagicalRing)) newLootItem = new MagicalRing(new Point(x,y),rand);
                // ...

                if (newLootItem != null) scatteredLoot.Add(newLootItem);

            }
        }

        #endregion





        #region Tunnel and door generation

        /// <summary>
        /// Resets all tunnel spaces to void, and all door spaces to walls. May be used if an attempt
        /// to map tunnels gets locked up and needs to start over.
        /// </summary>
        static private void ClearAllTunnelsAndDoors()
        {
            for (int x = 0; x < floorWidth; x++)
                for (int y = 0; y < floorHeight; y++)
                {
                    if (floorPlan[x, y] == FloorTile.Surfaces.Tunnel) floorPlan[x, y] = FloorTile.Surfaces.Void;
                    if (floorPlan[x, y] == FloorTile.Surfaces.HiddenDoor ||
                        floorPlan[x, y] == FloorTile.Surfaces.LockedDoor ||
                        floorPlan[x, y] == FloorTile.Surfaces.OpenDoor) floorPlan[x, y] = FloorTile.Surfaces.Wall;
                }
        }

        /// <summary>
        /// Maps the tunnels required to connect each room to a single network of connected rooms
        /// </summary>
        /// <returns></returns>
        static private bool CreateTunnels()
        {
            List<Rectangle> connectedRooms = new List<Rectangle>();
            List<Rectangle> disconnectedRooms = new List<Rectangle>(rooms);
            Rectangle sourceRoom;
            Rectangle targetRoom;
            int indexPick; // For picking a source or target room
            int direction; // Used to determine direction of tunnel or side of room to start on
            // Direction's are mapped as {Top, Right, Bottom, Left}

            List<Point> currentTunnel = new List<Point>(); // used so we don't run into own tunnel
            Point currentPosition;

            // Loop requires selection of disconnected room as source, selection of
            // connected room if available or else selection of disconnected room as target.
            while (disconnectedRooms.Count > 0)
            {
                currentTunnel.Clear();
                
                // Select and remove source from disconnected rooms
                indexPick = rand.Next(disconnectedRooms.Count);
                sourceRoom = disconnectedRooms[indexPick];
                disconnectedRooms.RemoveAt(indexPick);

                // Select and remove target from connected list if available, else disconnected
                if (connectedRooms.Count == 0)
                {
                    indexPick = rand.Next(disconnectedRooms.Count);
                    targetRoom = disconnectedRooms[indexPick];
                    disconnectedRooms.RemoveAt(indexPick);
                } else
                {
                    indexPick = rand.Next(connectedRooms.Count);
                    targetRoom = connectedRooms[indexPick];
                    connectedRooms.RemoveAt(indexPick); // will be added back later after connection to source
                }

                // Pick the best wall to dig tunnel from to get from source to target
                int wallSide = AffinityDirection(sourceRoom.Center, targetRoom.Center);

                // Place door on chosen side of wall, then move outside the door
                currentPosition = MovePosition(
                    SetStartingDoor(sourceRoom, wallSide), // place door on wall
                    wallSide); // move in direction as set by wallSide

                // Due to protected margin space, we know this spot is not blocked, so mark it
                floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;
                
                // Dig tunnel - Set starting values
                var tunnelComplete = false;
                FloorTile.Surfaces currentSurface;
                var foundRoom = new Rectangle();

                // Repeats process until the tunnel is finished
                while (!tunnelComplete)
                {
                    currentTunnel.Add(currentPosition);
                    int loopCounter = 0; // Catches difficulty in finding a path and starts over
                    do {
                        // Uses affinity and random to pick a direction to dig towards
                        direction = PickDirection(currentPosition, targetRoom.Center);

                        // If unable to find a valid direction to move to, the tunnel is a failure
                        if (++loopCounter > (floorWidth + floorHeight) * 4)
                            return false;
                    } while (IsBlocked (currentPosition,direction, currentTunnel, targetRoom, connectedRooms, out foundRoom));

                    // isBlocked will return a rectangle with width > 0 as foundRoom if in the process
                    // of diging towards the target we find another connected room instead.
                    // This means we need to put the target back in the connected List and pull out
                    // the foundRoom to use instead. Note that the first loop will begin with two
                    // disconnected rooms, and foundRoom can only return a room if it is already in
                    // the connected list, so we can not accidentally place a disconnected room into the
                    // connected list.
                    if (foundRoom.Width > 0)
                    {
                        connectedRooms.Add(targetRoom);
                        targetRoom = foundRoom;
                        connectedRooms.Remove(foundRoom);
                    }

                    // move into the direction chosen and identify the surface for this space
                    currentPosition = MovePosition(currentPosition, direction);
                    currentSurface = floorPlan[currentPosition.X, currentPosition.Y];


                    // Check to see if standing on a door or wall, or another connected tunnel.
                    // All doors should be open at this point, but just in case the logic is changed
                    // later, we're covered. If space is a door or wall, isBlocked will only be
                    // false if its for the (original or new) target room.
                    if (currentSurface == FloorTile.Surfaces.Wall ||
                        currentSurface == FloorTile.Surfaces.Tunnel ||
                        currentSurface == FloorTile.Surfaces.OpenDoor ||
                        currentSurface == FloorTile.Surfaces.HiddenDoor ||
                        currentSurface == FloorTile.Surfaces.LockedDoor ||
                        IsJoiningOtherTunnel(currentPosition, currentTunnel)) 
                        tunnelComplete = true;
                    else
                        // Its not blocked, and not entering into a connected room, make it a tunnel
                        floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;
                } // repeat while (!tunnelComplete)


                // Depending on type of tile tunnel ended on, either change it to a door or tunnel.
                if (floorPlan[currentPosition.X, currentPosition.Y] == FloorTile.Surfaces.Wall)
                    floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.OpenDoor;
                if (floorPlan[currentPosition.X, currentPosition.Y] == FloorTile.Surfaces.Void)
                    floorPlan[currentPosition.X, currentPosition.Y] = FloorTile.Surfaces.Tunnel;

                // Finish by placing both rooms in the connectedRooms list.
                connectedRooms.Add(sourceRoom);
                connectedRooms.Add(targetRoom);

            } // repeat while (disconnectedRooms.Count > 0)

            return true;
            // end of createTunnels() method
        }


        /// <summary>
        /// Prevents running into own tunnel to ensure path makes its way towards an older
        /// tunnel, or wall/door at destination (or another connected) room. Also blocks entry
        /// onto room corners.
        /// </summary>
        /// <param name="currentPosition">Position to move from</param>
        /// <param name="direction">Direction to dig into</param>
        /// <param name="ownTunnel">path created by this dig session</param>
        /// <returns></returns>
        private static bool IsBlocked(Point currentPosition, int direction, List<Point> ownTunnel, Rectangle targetRoom, List<Rectangle> connectedRooms, out Rectangle roomFound)
        {
            // Initialize OUT parameter values
            roomFound = new Rectangle();

            // Sets the location to check
            var targetLocation = MovePosition(currentPosition, direction);

            // If outside or on the boarders of the floor, its blocked
            if (targetLocation.X <= 0 || targetLocation.Y <= 0 ||
                targetLocation.X >= floorWidth-1 || targetLocation.Y >= floorHeight-1)
                return true;

            var targetSurface = floorPlan[targetLocation.X, targetLocation.Y];

            // shortcuts, since all void spaces are free to tunnel and running
            // into own tunnel is not allowed
            if (targetSurface == FloorTile.Surfaces.Void) return false;
            if (ownTunnel.Contains(targetLocation)) return true;

            
            // If surface is another door or wall
            if (targetSurface == FloorTile.Surfaces.Wall || targetSurface == FloorTile.Surfaces.HiddenDoor ||
                targetSurface == FloorTile.Surfaces.LockedDoor || targetSurface == FloorTile.Surfaces.OpenDoor)
            {
                // Create a rectangle for the walls around the target room, and test to see if
                // the door or wall detected belongs to target room.
                var targetRoomWalls = new Rectangle(
                    targetRoom.X - 1,
                    targetRoom.Y - 1,
                    targetRoom.Width + 2,
                    targetRoom.Height + 2);

                var joinToRoom = new Rectangle(); // To make room accessable after foreach loop later

                // Need to know if this is the target room or another connected room
                // First, if the target room walls don't include this location, then test the other rooms.
                if (!targetRoomWalls.Contains(targetLocation))
                {
                    var roomWalls = new Rectangle();
                    // Is this wall or door not part of a connected room
                    foreach (var room in connectedRooms)
                    {
                        // Map the walls of the connectedRoom to be tested
                        roomWalls.X = room.X - 1;
                        roomWalls.Y = room.Y - 1;
                        roomWalls.Width = room.Width + 2;
                        roomWalls.Height = room.Height + 2;
                        if (roomWalls.Contains(targetLocation))
                        {
                            joinToRoom = room; // Inidicates that a connected room has been found
                        }
                    }
                    // If a connected room was not found, or if one was but the location is a
                    // corner, then the tunnel is blocked.
                    if (joinToRoom.Width == 0 || IsCorner(joinToRoom,targetLocation)) return true;
                    
                }
                else
                    // Target room wall found, but is this wall a corner
                    if (IsCorner(targetRoom, targetLocation)) return true;
            } // end if target is on a wall or door

            // By this point, target is either on a valid wall of a connected room, or is otherwise not blocked
            return false;
        }

        /// <summary>
        /// Determines if the location provided is a corner of the given room
        /// </summary>
        /// <param name="room">Room dimensions</param>
        /// <param name="location">Point to check for corner</param>
        /// <returns></returns>
        private static bool IsCorner(Rectangle room, Point location)
        {
            if (location.X == room.X - 1 && location.Y == room.Y - 1) return true;
            if (location.X == room.Right && location.Y == room.Y - 1) return true;
            if (location.X == room.X - 1 && location.Y == room.Bottom) return true;
            if (location.X == room.Right && location.Y == room.Bottom) return true;
            return false;
        }


        /// <summary>
        /// Determines if another tunnel (not the current one being dug) can be found in either of
        /// the four points vertically or horizontally of the current point.
        /// </summary>
        /// <param name="currentPosition">Center of search area</param>
        /// <param name="ownTunnel">List of points dug by current cycle</param>
        /// <returns>True if another tunnel is found, otherwise false</returns>
        private static bool IsJoiningOtherTunnel(Point currentPosition, List<Point> ownTunnel)
        {
            // Even though it has no effect, the index positions are consistent with other uses
            // of Direction in this class.
            var testPoints = new Point[4];
            testPoints[0].X = currentPosition.X;
            testPoints[0].Y = currentPosition.Y - 1; // Up
            testPoints[1].X = currentPosition.X + 1; // Right
            testPoints[1].Y = currentPosition.Y;
            testPoints[2].X = currentPosition.X;
            testPoints[2].Y = currentPosition.Y + 1; // Down
            testPoints[3].X = currentPosition.X - 1; // Left
            testPoints[3].Y = currentPosition.Y;
            foreach (var testPoint in testPoints)
                if (testPoint.X>=0 &&
                    testPoint.X < floorWidth &&
                    testPoint.Y>=0 &&
                    testPoint.Y < floorHeight &&
                    floorPlan[testPoint.X, testPoint.Y] == FloorTile.Surfaces.Tunnel)
                            if (!ownTunnel.Contains(testPoint)) return true;
                    
            return false;
        }

        /// <summary>
        /// Determines the position of a new point moving one space in a given direction from
        /// a given point.
        /// </summary>
        /// <param name="point">Starting point</param>
        /// <param name="direction">Direction to move {Up, Right, Down, Left}</param>
        /// <returns></returns>
        private static Point MovePosition(Point point, int direction)
        {
            var newPosition = point;
            switch (direction)
            {
                case 0: newPosition.Y--; break;
                case 1: newPosition.X++; break;
                case 2: newPosition.Y++; break;
                case 3: newPosition.X--; break;
                default: break; // If invalid direction given, no move can be determined
                                // TODO: Consider throwing an exception if not a valid direction.
            }
            return newPosition;
        }


        /// <summary>
        /// Determines which direction to give preference towards to get from source to target. For
        /// example, if target is up and right of source, and the vertical distance is greater than
        /// the horizontal distance, than affinity should be up. Return values are 0(Up), 1(Right),
        /// 2(Down),3(Left).
        /// </summary>
        /// <param name="sourceX">X coordinate of source node</param>
        /// <param name="sourceY">Y coordinate of source node</param>
        /// <param name="targetX">X coordinate of target node</param>
        /// <param name="targetY">Y coordinate of target node</param>
        /// <returns>integer direction 0 to 4 as described above</returns>
        static private int AffinityDirection(Point source, Point target)
        {
            var distanceInDirection = new int[4];

            // Calculate distance toward target in each direction
            distanceInDirection[0] = source.Y - target.Y;         // Up
            distanceInDirection[3] = source.X - target.X;         // Left
            distanceInDirection[2] = -distanceInDirection[0];   // Down
            distanceInDirection[1] = -distanceInDirection[3];   // Right

            // Determine the greatest distance and return the direction
            return Array.IndexOf(distanceInDirection, distanceInDirection.Max());
            // JC: Convert all directional references to an Enum for clarity
        }

        /// <summary>
        /// Determines which of four directions should have great affinity and sets
        /// probability of selecting each direction, then returns the selected direction.
        /// As tunnel progresses towards target, affinity direction may change with each
        /// new source point. This ensures the general direction of the tunnel leads toward
        /// the target.
        /// </summary>
        /// <param name="source">Point to travel from</param>
        /// <param name="target">Point to travel to</param>
        /// <returns></returns>
        static private int PickDirection(Point source, Point target)
        {
            var directionProbability = new Range[4];

            // Set direction classifications
            var affinityDir = AffinityDirection(source, target);
            var altCounterClockwise = (affinityDir == 0 ? 3 : affinityDir - 1);
            var altClockwise = (affinityDir == 3 ? 0 : affinityDir + 1);
            var antiAffinityDir = (affinityDir > 1 ? affinityDir - 2 : affinityDir + 2);

            // Set probabilities
            directionProbability[affinityDir].Low = 0;
            directionProbability[affinityDir].High = 79;
            directionProbability[altCounterClockwise].Low = 80;
            directionProbability[altCounterClockwise].High = 89;
            directionProbability[altClockwise].Low = 90;
            directionProbability[altClockwise].High = 99;
            directionProbability[antiAffinityDir].Low = -1; // No chance
            directionProbability[antiAffinityDir].High = -100;

            var rnd = rand.Next(100);

            // Check each direction to see which the rnd value falls in between
            var direction = 0;
            while (!(directionProbability[direction].Low <= rnd && directionProbability[direction].High >= rnd)) direction++;

            return direction;
        }

        /// <summary>
        /// Determines where to set the starting door for a tunnel and places it.
        /// </summary>
        /// <param name="room">Boundaries of room</param>
        /// <param name="wallSide">Which wall to place door</param>
        /// <returns></returns>
        static private Point SetStartingDoor(Rectangle room, int wallSide)
        {
            var doorLocation = new Point();

            // Determine which wall to place door
            if (wallSide % 2 == 0) // Top and Bottom walls
            {
                doorLocation.X = rand.Next(room.Left, room.Right); // 
                doorLocation.Y = wallSide == 0 ? room.Top - 1 : room.Bottom;
            }
            else // Left and Right walls
            {
                doorLocation.Y = rand.Next(room.Top, room.Bottom);
                doorLocation.X = wallSide == 3 ? room.Left - 1 : room.Right;
            }

            // Place door
            floorPlan[doorLocation.X, doorLocation.Y] = FloorTile.Surfaces.OpenDoor;
            return doorLocation;
        }


        /// <summary>
        /// Iterates through all open doors to randomly change them to locked or hidden doors.
        /// Ensures that levels 1-5 will have none of these door types added by this method.
        /// </summary>
        static private void ChangeUpDoors()
        {
            Range hiddenProbability;
            Range lockedProbability;
            var doorList = new List<Point>();
            int rnd;

            // Range for hidden doors starts at 50, and locked doors starts at 75. The scope
            // of this range determines how likely the door will be hidden or locked.
            // If random number chosen does not fall within either range, then the door will
            // remain unlocked.
            hiddenProbability.Low = 50;
            lockedProbability.Low = 75;

            // As level increases, the odds should increase, up to a point.
            // Levels 1 - 5 have no chance of hidden or locked doors
            var probabilityRange = (levelNumber < 31 ? levelNumber - 6 : 24);
            hiddenProbability.High = hiddenProbability.Low + probabilityRange;
            lockedProbability.High = lockedProbability.Low + probabilityRange;


            // Iterate through each room to find doors and test each one
            foreach (var room in rooms)
            {
                for(int x=room.Left-1; x < room.Right+2; x++)
                {
                    if (floorPlan[x, room.Top-1] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(x, room.Top-1));
                    if (floorPlan[x, room.Bottom+1] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(x, room.Bottom+1));
                }

                for(int y=room.Height-1; y<room.Bottom+2; y++)
                {
                    if (floorPlan[room.Left-1, y] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(room.Left-1, y));
                    if (floorPlan[room.Right+1, y] == FloorTile.Surfaces.OpenDoor) doorList.Add(new Point(room.Right+1, y));
                }
            }

            
            foreach (var door in doorList)
            {
                // Pick random number and determine which range its in to set door tile
                rnd = rand.Next(100);
                if (rnd >= hiddenProbability.Low && rnd <= hiddenProbability.High)
                    floorPlan[door.X,door.Y] = FloorTile.Surfaces.HiddenDoor;
                if (rnd >= lockedProbability.Low && rnd <= lockedProbability.High)
                    floorPlan[door.X, door.Y] = FloorTile.Surfaces.LockedDoor;
            }
        }

        /// <summary>
        /// Locations a space to drop the stairs going down.
        /// </summary>
        static private void PlaceStairsDown()
        {
            int x; int y;
            do
            {
                int roomNumber = rand.Next(rooms.Count);
                x = rand.Next(rooms[roomNumber].Left, rooms[roomNumber].Right);
                y = rand.Next(rooms[roomNumber].Top, rooms[roomNumber].Bottom);
            } while (heroLocation.X == x && heroLocation.Y == y);

            floorPlan[x, y] = FloorTile.Surfaces.StairsDown;
        }
        

        #endregion





        #region Internally accessible methods

        /// <summary>
        /// Used to return a rectangle representing the map coordinates of any room
        /// containing the specified point.
        /// </summary>
        /// <param name="containingPoint">A Point within the room to be returned</param>
        /// <param name="foundRoom">The room containing the given point</param>
        /// <returns>True if room is found, otherwise false</returns>
        static internal bool GetRoomWithPoint(Point containingPoint, out Rectangle foundRoom)
        {
            foreach (var room in rooms)
                if (room.Contains(containingPoint))
                {
                    foundRoom = room;
                    return true;
                }

            foundRoom = new Rectangle();
            return false; 
        }

        static internal int GetNumberOfRooms()
        {
            return rooms.Count;
        }


        /// <summary>
        /// Moves the draw rectangle x,y position in concurance with changed tile dimensions (map zooming)
        /// </summary>
        /// <param name="currentDrawRectangle">Rectangle to edit</param>
        /// <param name="currentSprite">graphic associated with the rectangle</param>
        /// <param name="tileWidth">scaled tile width</param>
        /// <param name="tileHeight">scaled tile height</param>
        static internal Rectangle TranslateRecToTile(Rectangle tileSize, Rectangle currentView, Point mapPos)
        {
            Rectangle currentDrawRectangle = tileSize; // sets width and height
            currentDrawRectangle.X = (mapPos.X - currentView.X) * tileSize.Width;
            currentDrawRectangle.Y = (mapPos.Y - currentView.Y) * tileSize.Height;
            return currentDrawRectangle;
        }
        #endregion
    }
}
