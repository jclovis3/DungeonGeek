﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System;

namespace DungeonGeek
{
    class Hero
    {
        #region Fields

        Random rand = InventoryEffectManager.RandomNumberGenerator;
        
        // graphic and drawing info
        private string spriteFile;
        private Texture2D sprite;
        private Rectangle drawRectangle = new Rectangle();


        // Game data
        private Point location;
        private string heroName = "John Doe";
        private int xpLevel = 1;
        private long xp = 0;
        private int hp; // set to baseHP in the constructor

        // Daily calorie requirement. Excess energy penalizes strength by 1 for
        // every 1000 calories over being full.
        private int energy = GameConstants.FULL_ENERGY; 


        // Base values are starting values and shall be computed with methods
        // for effective values of the same

        private int baseCarryWeight = 135; // All weights are in pounds
        private int baseStrength = 5;
        private int baseHP = 20;
        // NOTE: Armour will be calculated from Inventory items being worn
        // and magican enhancements and curses

        

        #endregion

        #region Properties

        internal Point Location // where here is on map; (0,0) is top left corner
        {
            get { return location; }
            set { location = value; }
        }

        internal string HeroName
        {
            get { return heroName; }
            set { heroName = value; }
        }
        internal int HP
        {
            get { return hp; }
        }

        internal int HP_Max
        {
            get { return baseHP; }
        }
        internal int XPLvl
        {
            get { return xpLevel; }
        }

        internal long XP
        {
            get { return xp; }
        }


        internal int BaseStrength
        {
            get { return baseStrength; }
        }

        internal int Energy
        {
            get { return energy; }
        }

        


        #endregion


        internal Hero()
        {
            Location = new Point(0,0);
            spriteFile = GameConstants.SPRITE_PATH_MISC + "Hero_28x34";
            hp = baseHP;
            // TODO: Create input screen to gather name
            // heroName = Interaction.InputBox("Dust thou have a name?","Who are you","John Doe");
            if (heroName.Length < 1) heroName = "John Doe";
        }


        #region Methods

        #region Game Class Support
        internal void LoadContent(ContentManager contentManager)
        {
            sprite = contentManager.Load<Texture2D>(spriteFile);
            drawRectangle.Width = sprite.Width;
            drawRectangle.Height = sprite.Height;
            
        }

        internal void Update(Rectangle currentView, int tileWidth, int tileHeight)
        {
            // Location is the tile coordinate, not a pixel location. To convert to pixel
            // relative to currentView, need to use tileWidth & tileHeight as pixel dimensions
            // location.X * tileWidth determines adjusted pixel location in drawing area
            // (tileWidth - sprite.Width) / 2 provides amount of margin to add to left edge
            // currentView.X * tileWidth is the offset for when the currentView moves

            
            drawRectangle.X = (int)(
                Location.X * tileWidth +
                (tileWidth - sprite.Width) / 2 -
                currentView.X * tileWidth);
            drawRectangle.Y = (int)(
                Location.Y * tileHeight +
                (tileHeight - sprite.Height) / 2 -
                currentView.Y * tileHeight);
            drawRectangle.Width = tileWidth;
            drawRectangle.Height = tileHeight;
        }

        internal void Draw(SpriteBatch spriteBatch, Rectangle currentDrawRectangle)
        {
            spriteBatch.Draw(sprite, currentDrawRectangle, Color.White); // White is full color with no tinting
        }
        #endregion

        internal bool AttemptPickupItem(InventoryItem item)
        {
            if (item.InventoryWeight < (EffectiveCarryWeight() - Inventory.Weight))
            {
                Inventory.Add(item);
                return true;
            }
            else return false;
        }
        
        private int EffectiveCarryWeight()
        {
            // TODO: Replace carryModifiers with method to screen for
            // modifiers from inventory items and temporary magical effects
            int carryModifiers = 0;
            return baseCarryWeight + EffectiveStrength() * 3 + carryModifiers;
        }

        internal int EffectiveStrength()
        {
            // TODO: Replace strengthModifiers with method to screen for
            // modifiers from inventory items and temporary magical effects
            int strengthModifiers = 0;
            return baseStrength + strengthModifiers;
        }

        /// <summary>
        /// Subtracts hpHit from hitpoints after adjusting for armor rating.
        /// </summary>
        /// <param name="hpHit"></param>
        /// <returns>true if hero survives hit, otherwise false</returns>
        internal bool TakeHit(int hpHit)
        {
            // TODO: Adjust hit by armor rating
            if (--hp <= 0)
            {
                hp = 0;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Poison has a 1 in 4 chance of doing a point of damage
        /// </summary>
        /// <returns></returns>
        internal bool TakePoisonDmg()
        {
            if (rand.Next(4)==0 && --hp <= 0)
            {
                hp = 0;
                return false;
            }
            return true;

        }

        internal void Heal(int healAmt = 1)
        {
            if (hp < baseHP) hp += healAmt;
            if (hp > baseHP) hp = baseHP;
        }

        internal long XpToNext()
        {
            // Based on scale by D&D
            return ((xpLevel + 1) * (xpLevel) / 2) * 1000;
        }
        #endregion
    }
}
