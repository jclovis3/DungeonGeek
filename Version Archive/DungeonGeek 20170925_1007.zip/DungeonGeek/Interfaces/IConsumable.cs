﻿namespace DungeonGeek
{
    interface IConsumable
    {
        string Consume();
    }
}
