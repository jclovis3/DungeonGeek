﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace DungeonGeek
{
    static class GameMenuScreen
    {
        
        public enum ReturnActions { None, New, Load, Instructions, Records, Quit}
        
        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static GameText headerText;
        private static GameText instructionText;
        private static List<GameText> listTextObjects;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static Color selectedFontColor = Color.GreenYellow;
        private static string[] menuList;
        private static string header = "Options:";
        private static int selectedIndex = 0;
        private static int elapsedTime = 0;
        private static int currentDelay = 0;
        private static bool firstLoop = true;
        private static Keys lastKey = Keys.None;



        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            headerText = new GameText(header, gd);
            instructionText = new GameText("Up/Down - Change selection     Enter - Select\nEsc - Return to game", gd);
            listTextObjects = new List<GameText>();
            listTextObjects.Add(new GameText(graphicsDevice));
            listTextObjects[0].Text = "XXXXX"; // Allows for font size measurements to be taken
            menuList = new string[]
            {"New game", "Load autosave", "Keyboard commands","Hall of Records","Quit"};
        }

        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {

            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();


            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            headerText.Y = nextTextTop;
            headerText.ForeColor = headerFontColor;
            headerText.Scale = new Vector2(1.5f, 1.25f);
            headerText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(headerText.Height * headerText.Scale.Y);
            headerText.Draw(spriteBatch);

            underline.X = headerText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(headerText.Width * headerText.Scale.X);
            underline.Height = (int)(headerText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(headerText.Height * 0.25f) + GameConstants.LINE_SPACING;

            // Display list of menu options
            for (int i = 0; i < menuList.Length; i++)
            {
                fontColor = (i == selectedIndex ? selectedFontColor : normalFontColor);
                if (listTextObjects.Count < i + 1) listTextObjects.Add(new GameText(graphicsDevice));
                currentText = listTextObjects[i];
                currentText = new GameText(menuList[i], graphicsDevice);
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }


            // Display current screen instructions
            instructionText.Y = (blackCanvas.Top + blackCanvas.Height - instructionText.Height - GameConstants.LINE_SPACING);
            instructionText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            instructionText.ForeColor = screenInstructionFontColor;
            instructionText.Draw(spriteBatch);

            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key, GameTime gameTime, out ReturnActions action)
        {
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            action = ReturnActions.None;

            if (firstLoop && key != Keys.None) return false; // Forces keys to be released upon entry of first loop
            firstLoop = false;

            // If no key pressed, there should be no more delay in this class
            if (key == Keys.None || key != lastKey) currentDelay = GameConstants.NO_DELAY;


            if (key != Keys.None && elapsedTime > currentDelay)
            {

                elapsedTime = 0;
                

                // When a key is first pressed, the initial delay should be set
                if (key != lastKey) currentDelay = GameConstants.INITIAL_KEY_DELAY;

                // Once the initial delay is over, if the key is still held down, then repeating is allowed
                else currentDelay = GameConstants.HOLD_KEY_DELAY;




                if (key == Keys.Escape)
                {
                    action = ReturnActions.None;
                    firstLoop = true;
                    return true; // Screen closes
                }

                // Up and down keys allow selection to roll from end to end
                else if (key == Keys.Down)
                {
                    if (++selectedIndex > menuList.Length - 1) selectedIndex = 0;
                }
                else if (key == Keys.Up)
                {
                    if (--selectedIndex < 0) selectedIndex = menuList.Length - 1;
                }
                else if (key == Keys.Enter)
                {
                    // {"Save game", "Load game", "Keyboard commands","Quit"};

                    switch (menuList[selectedIndex])
                    {
                        case "New game":
                            action = ReturnActions.New;
                            return CloseWindow();
                        case "Load autosave":
                            // TODO: Implement load game option
                            break;
                        case "Keyboard commands":
                            action = ReturnActions.Instructions;
                            return CloseWindow();
                        case "Hall of Records":
                            action = ReturnActions.Records;
                            return CloseWindow();
                        case "Quit":
                            action = ReturnActions.Quit;
                            return CloseWindow();
                        default:
                            break;
                    }
                }
            }
            lastKey = key;
            return false; // Does not allow screen to exit yet
        }

        /// <summary>
        /// Used to illiminate redundant code in the ProcessPlayerInputs method
        /// </summary>
        /// <returns></returns>
        private static bool CloseWindow()
        {
            firstLoop = true;
            return true;
        }

    }
}
