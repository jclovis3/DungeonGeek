﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DungeonGeek
{
    static class InstructionsScreen
    {


        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static GameText headerText;
        private static GameText windowInstructionText;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string[] gameInstructionList;
        private static GameText[] gameInstructionText;
        private static string header = "Instructions";
        


        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            headerText = new GameText(header, gd);
            windowInstructionText = new GameText("Esc - Exit", gd);

            gameInstructionList = new string[]
            {
                "Arrow Keys / Number Pad (Numlock Off) - General movement (may hold key down)",
                "SHIFT + movement - Run until you find something (door, monster, loot, etc.)",
                "   - Also explores tunnel until the end or first intersection",
                "Move toward locked door or monster to attack / bash it",
                "DEL - Rest one turn (may hold key down)",
                "INS - Search for hidden doors & traps (3x chance to find than movement or resting)",
                "A,S,W,D - Pan camera (normal and map view)",
                "TAB - Pan back to hero position",
                "M - Toggle map view",
                "I - Opens inventory screen",
                "H - Opens message history screen (last 22 messages)",
                "< - Go down stairs",
                "ESC - Exit any open screen, or opens Game Menu",
                "? - Displays this help screen (Duh)"
                // PLANNING: Update instruction list with added features
            };
            gameInstructionText = new GameText[gameInstructionList.Length];
            for (int i = 0; i < gameInstructionList.Length; i++)
                gameInstructionText[i] = new GameText(gameInstructionList[i], gd);

        }

        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {
            // TODO: Refactor Create Method. Instructions.Show() shares many common lines from Inventory.Show()

            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            
            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            headerText.Y = nextTextTop;
            headerText.ForeColor = headerFontColor;
            headerText.Scale = new Vector2(1.5f, 1.25f);
            headerText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(headerText.Height * headerText.Scale.Y);
            headerText.Draw(spriteBatch);

            underline.X = headerText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(headerText.Width * headerText.Scale.X);
            underline.Height = (int)(headerText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(headerText.Height * 0.25f) + GameConstants.LINE_SPACING;


            // Display list of instructions
            for (int i = 0; i < gameInstructionText.Length; i++)
            {
                fontColor = normalFontColor;
                currentText = gameInstructionText[i];
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }

            // Display current screen instructions
            windowInstructionText.Y = (int)(blackCanvas.Top + blackCanvas.Height - windowInstructionText.Height - GameConstants.LINE_SPACING);
            windowInstructionText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            windowInstructionText.ForeColor = screenInstructionFontColor;
            windowInstructionText.Draw(spriteBatch);
            
            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key)
        {
            if (key == Keys.Escape)
            {
                return true;
            }

            return false; // Does not allow inventory menu to exit yet
        }




    }
}
