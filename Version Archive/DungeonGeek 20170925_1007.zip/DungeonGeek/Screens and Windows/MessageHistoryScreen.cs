﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace DungeonGeek
{
    static class MessageHistoryScreen
    {
        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static GameText headerText;
        private static GameText instructionText;
        private static List<GameText> listTextObjects;
        private static Color headerFontColor = Color.MintCream;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string header = "Message History (New to old):";
        

        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            headerText = new GameText(header, gd);
            instructionText = new GameText("Esc - Exit", gd);
            listTextObjects = new List<GameText>();
            listTextObjects.Add(new GameText(graphicsDevice));
            listTextObjects[0].Text = "XXXXX"; // Allows for font size measurements to be taken

        }

        internal static void Show(SpriteBatch spriteBatch, Rectangle viewPortBounds, List<string> messageHistory)
        {
            Color fontColor;

            // The count is reduced when the message history is shown and also when a new map is generated
            // to keep the list size under control.
            if (messageHistory.Count>GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH)
                messageHistory.RemoveRange(0, messageHistory.Count - GameConstants.MESSAGE_HISTORY_RETENTION_LENGTH);

            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();

            
            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show header text with underline
            headerText.Y = nextTextTop;
            headerText.ForeColor = headerFontColor;
            headerText.Scale = new Vector2(1.5f, 1.25f);
            headerText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(headerText.Height * headerText.Scale.Y);
            headerText.Draw(spriteBatch);

            underline.X = headerText.X;
            underline.Y = nextTextTop;
            underline.Width = (int)(headerText.Width * headerText.Scale.X);
            underline.Height = (int)(headerText.Height * GameConstants.UNDERLINE_RATIO);
            spriteBatch.Draw(pixel, underline, headerFontColor);
            nextTextTop += underline.Height + (int)(headerText.Height * 0.25f) + GameConstants.LINE_SPACING;


            for (int i = messageHistory.Count - 1; i >= 0; i--)
            {
                fontColor = normalFontColor;
                while (listTextObjects.Count < i + 1) listTextObjects.Add(new GameText(graphicsDevice));
                currentText = listTextObjects[i];
                currentText.Text = messageHistory[i];
                currentText.X = GameConstants.LIST_LEFT;
                currentText.Y = nextTextTop;
                nextTextTop += currentText.Height + GameConstants.LINE_SPACING;
                currentText.ForeColor = fontColor;
                currentText.Draw(spriteBatch);
            }





            // Display current screen instructions
            instructionText = new GameText("Esc - Exit", new Point(), graphicsDevice);
            instructionText.Y = (int)(blackCanvas.Top + blackCanvas.Height - instructionText.Height - GameConstants.LINE_SPACING);
            instructionText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            instructionText.ForeColor = screenInstructionFontColor;
            instructionText.Draw(spriteBatch);


            spriteBatch.End();

        }

        internal static bool ProcessPlayerInputs(Keys key)
        {
            if (key == Keys.Escape)
            {
                return true;
            }

            return false; // Does not allow history screen to close yet
        }




    }
}
