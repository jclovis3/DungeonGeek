﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Text;

namespace DungeonGeek
{
    static class EnterNameScreen
    {
        


        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static GameText userResponseText;
        private static Color promptColor = Color.Gold;
        private static Color userResponseColor = Color.White;
        private static string prompt;
        private static GameText promptText;
        private static GameText instructionText;
        private static StringBuilder userResponse = new StringBuilder();
        private static KeyboardState keyboardState;
        private static KeyboardState oldKeyboard;
        private static int elapsedTime = 0;
        private static int currentDelay = 0;
        private static bool firstLoop = true;
        private static Keys lastKey = Keys.None;

        


        #endregion

        internal static string Prompt
        {
            set { prompt = value; }
            get { return prompt; }
        }

        internal static string Value
        {
            set { userResponse = new StringBuilder(value); }
            get { return userResponse.ToString(); }

        }

        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            oldKeyboard = Keyboard.GetState();
            userResponseText = new GameText(string.Empty, new Point(), graphicsDevice);
            promptText = new GameText(gd);
            instructionText = new GameText("Enter - Except    Esc - Cancel", gd);

        }

        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();


            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);

            Rectangle underline = new Rectangle();
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Show prompt text
            promptText.Text = prompt;
            promptText.Y = nextTextTop;
            promptText.Width = blackCanvas.Width - GameConstants.HEAD_FOOT_LEFT * 2;
            promptText.ForeColor = promptColor;
            promptText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            nextTextTop += (int)(promptText.Height * 1.5) + GameConstants.LINE_SPACING;
            promptText.Draw(spriteBatch);

            // Show response text
            userResponseText.Text = userResponse.ToString().Length == 0 ? " " : userResponse.ToString();
            userResponseText.ForeColor = userResponseColor;
            userResponseText.X = blackCanvas.X + blackCanvas.Width / 2 - userResponseText.Width / 2;
            userResponseText.Y = nextTextTop;
            nextTextTop += userResponseText.Height + GameConstants.LINE_SPACING;
            userResponseText.Draw(spriteBatch);

            // Draw underline 3/4 width of view until response is wider
            int minLineWidth = viewPort.Width * 3 / 4;
            underline.Width = minLineWidth > userResponseText.Width ? minLineWidth : userResponseText.Width;
            underline.Height = (int)(userResponseText.Height * GameConstants.UNDERLINE_RATIO);
            underline.X = viewPort.Width / 2 - underline.Width / 2;
            underline.Y = nextTextTop;
            spriteBatch.Draw(pixel, underline, promptColor);


            // Display current screen instructions

            instructionText.Y = (int)(blackCanvas.Top + blackCanvas.Height - instructionText.Height - GameConstants.LINE_SPACING);
            instructionText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            instructionText.ForeColor = userResponseColor;
            instructionText.Draw(spriteBatch);

            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key, GameTime gameTime, bool resetTiming, out string response)
        {
            // Handle own delay control
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;
            response = string.Empty;
            if (resetTiming) firstLoop = true;
            if (firstLoop && key != Keys.None) return false; // Forces keys to be released upon entry of first loop
            firstLoop = false;

            // If no key being held (last key was released), there should be no more delay
            if (key == Keys.None || lastKey != key)
                currentDelay = GameConstants.NO_DELAY;

            // After the delay has elapsed, process the key if pressed
            if (key != Keys.None && elapsedTime > currentDelay)
            {
                elapsedTime = 0;



                // When a key is first pressed, the initial delay should be set
                if (key != lastKey)
                    currentDelay = GameConstants.INITIAL_KEY_DELAY;

                // Once the initial delay is over, if the key is still held down, then repeating is allowed
                else
                    currentDelay = GameConstants.HOLD_KEY_DELAY;

                switch (key)
                {
                    case Keys.Escape: return true;
                    case Keys.Enter:
                        {
                            response = userResponse.ToString();
                            return true; // Allow window to close
                        }
                    case Keys.Back:
                        {
                            if (userResponse.Length > 0)
                                userResponse.Remove(userResponse.Length - 1, 1);
                            break;
                        }
                    default:
                        {
                            // Use the XNA Keyboard Helper to get typed input
                            keyboardState = Keyboard.GetState();
                            char newKey;

                            if (XnaKeyboardHelper.TryConvertKeyboardInput(keyboardState, oldKeyboard, out newKey))
                            {
                                // Prevent text entry from being wider than allowed
                                userResponseText.Text = userResponse.ToString() + newKey + GameConstants.RESERVED_FOR_OBITUARY_TEXT;
                                if (userResponseText.Width <= GameConstants.HERO_NAME_MAX_WIDTH)
                                    userResponse.Append(newKey);
                            }
                            oldKeyboard = keyboardState;
                            break;
                        }
                }

            }
            lastKey = key;
            return false; // Does not allow window to close yet
        }



    }
}
