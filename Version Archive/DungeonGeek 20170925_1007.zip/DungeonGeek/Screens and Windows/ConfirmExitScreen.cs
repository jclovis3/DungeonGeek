﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace DungeonGeek
{
    static class ConfirmExitScreen
    {



        #region Fields
        private static GraphicsDevice graphicsDevice;
        private static Viewport viewPort;
        private static Texture2D pixel;
        private static GameText currentText;
        private static GameText promptText;
        private static GameText instructionText;
        private static Color screenInstructionFontColor = Color.Gold;
        private static Color normalFontColor = Color.White;
        private static string prompt = "Are you sure? Unsaved data will be fed to the rats.";
        private static string purpose = string.Empty;

        #endregion

        #region Properties
        internal static string Purpose
        {
            get { return purpose; }
            set { purpose = value; }
        }

        #endregion


        internal static void Initialize(GraphicsDevice gd)
        {
            viewPort = new Viewport();
            graphicsDevice = gd;
            Color[] colorData = { Color.White };
            pixel = new Texture2D(graphicsDevice, 1, 1);
            pixel.SetData(colorData);
            promptText = new GameText(prompt,gd);
            instructionText = new GameText("Y - Exit      N - Return to game", new Point(), gd);



        }

        internal static void Draw(SpriteBatch spriteBatch, Rectangle viewPortBounds)
        {
            
            Color fontColor;
            viewPort.Bounds = viewPortBounds;
            graphicsDevice.Viewport = viewPort;

            spriteBatch.Begin();


            // Draw black canvas with frame over viewport
            Rectangle frame = new Rectangle(0, 0, viewPortBounds.Width, viewPortBounds.Height);
            Rectangle blackCanvas = new Rectangle(2, 2, frame.Width - 4, frame.Height - 4);
            spriteBatch.Draw(pixel, frame, Color.White);
            spriteBatch.Draw(pixel, blackCanvas, Color.Black);
            int nextTextTop = blackCanvas.Top + GameConstants.TOP_MARGIN;

            // Display prompt
            
            fontColor = normalFontColor;
            promptText.X = GameConstants.LIST_LEFT;
            promptText.Y = nextTextTop;
            nextTextTop += promptText.Height + GameConstants.LINE_SPACING;
            promptText.ForeColor = fontColor;
            promptText.Draw(spriteBatch);


            // Display current screen instructions
            instructionText.Y = (blackCanvas.Top + blackCanvas.Height - instructionText.Height - GameConstants.LINE_SPACING);
            instructionText.X = blackCanvas.Left + GameConstants.HEAD_FOOT_LEFT;
            instructionText.ForeColor = screenInstructionFontColor;
            instructionText.Draw(spriteBatch);

            spriteBatch.End();
        }

        internal static bool ProcessPlayerInputs(Keys key, out bool ConfirmQuit)
        {
            ConfirmQuit = false;
            if (key == Keys.Y)
            {
                ConfirmQuit = true;
                return true; // Screen closes
            }
            else if(key == Keys.N)
            { return true; }

            return false; // Does not allow screen to exit yet
        }

    }
}
